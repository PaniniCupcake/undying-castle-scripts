﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Skull_rise : MonoBehaviour
{
    public GameObject text;
    private bool rise;
    public bool stuff_done;
    public int count;
    public int start_phase = 1;
    private void Start()
    {
        transform.position = new Vector3(0, -12.75f, 0);
            FindObjectOfType<Log>().boss = true;
            FindObjectOfType<Log>().scene = "Angel boss";
    }
    void FixedUpdate()
    {
        if (rise)
        {
            if (transform.position.y < 1.55)//Checks where the boss is
            {
                transform.position += new Vector3(0, 0.1f, 0); //Moves the boss up if they are below the target position
                GameObject player = GameObject.Find("Player");
                Move move = player.GetComponent<Move>();
                move.allow_movement = false;
                move.allow_attack = false; //Prevents the player from moving or attacking while the startup is happening
            }
            else if(!stuff_done)
            {
                GameObject mass = GameObject.Find("Mass_rock_destroyer"); //Creates an object to destroy all the tiles with the player not on it
                GameObject rise_lava = GameObject.Find("Rise_lava"); //Creates a foreground object that obscures the boss while it rises
                if (mass != null)
                {
                    Destroy(mass);//Destroys the lava destroyer 
                }
                if (rise_lava != null)
                {
                    Destroy(rise_lava);
                }
                GameObject ribcage = GameObject.Find("Ribcage_hitbox");
                gameObject.tag = "Rock_destroying";
                ribcage.tag = "Rock_destroying";
                stuff_done = true; //Makes this statement not be repeated
            }
        }
        GameObject text_stuff = GameObject.FindWithTag("Text");
        if (stuff_done) //Checks whether to create second speech box
        {
            if(count == 50)
            {
                Instantiate(text, new Vector3(450.99f, 132.44f, 0), Quaternion.identity); //Creates the second text box
            }
            if(count <= 50)
            {
                count++;//Makes the script wait a few frames before creating the next text box
            }
        }
        else
        {
            if (text_stuff == null)
            {
                rise = true;
                Stalled_appear rise_lava = FindObjectOfType<Stalled_appear>(); 
                rise_lava.counting = true;//Allows the obscuring gameobject to start being destroyed once the text is gone
            }
        }
        if (stuff_done && text_stuff == null)
        {
            if (count > 100)
            { 
                Angel_attack_pattern attacks = gameObject.GetComponent<Angel_attack_pattern>();
                attacks.attack_phase = start_phase;
                Destroy(this);
            }//Starts the boss fight and destroys this script after a short period after the second text file is destroyed
            count++;
        }
    }
}
