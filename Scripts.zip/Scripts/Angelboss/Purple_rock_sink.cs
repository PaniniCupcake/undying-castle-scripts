﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Purple_rock_sink : MonoBehaviour
{
    public GameObject lava;
    public GameObject perma_lava;
    public int dont_sink;
    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player")) //Checks if the player has stepped off the tile
        {
            Instantiate(lava, transform.position, Quaternion.identity); //Makes the tile sink and replaces it with an inacessible one
            Destroy(gameObject);
        }
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if(other.CompareTag("Rock_destroying"))
        {//Checks if something rock destroying is on the tile
            Instantiate(perma_lava, transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
        if(other.CompareTag("Player"))
        {
            dont_sink = 1; //Causes the tile to not sink if the player is on it
        }
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Mass_rock_destroying") && dont_sink == 0)
        {//Makes sure that perma sink isn't triggered before the script has had a chance to check if the player is on it
            dont_sink = 2; //Make
        }
        if (other.CompareTag("Player"))
        {
            dont_sink = 1;//Causes the tile to not sink if the player is on it
        }
    }
    private void FixedUpdate()
    {
        if(dont_sink == 2)
        { //Instantiates an inacessible tile that only starts to resurface when the object is no longer on it
            var mass_lava = Instantiate(perma_lava, transform.position, Quaternion.identity);
            Perma_lava_destroy lava_time = mass_lava.GetComponent<Perma_lava_destroy>();
            lava_time.sunk_frames = 50; //Makes the tile resurface 50 frames after the rock destroying object has left it
            Destroy(gameObject);
        }
        dont_sink = 0;
    }
}
