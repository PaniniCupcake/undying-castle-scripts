﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mini_lava : MonoBehaviour
{
    private int count;
    public GameObject rock;
    public Animator animator;
    public int sunk_frames = 150;
    void FixedUpdate()
    {
            count++;
            if (count == sunk_frames - 27) //Makes it so that the tile appears to resurface before it becomes accesible
            {
                animator.SetBool("Rising", true);
            }
            if (count == sunk_frames)
            {
                Instantiate(rock, transform.position, Quaternion.identity); //Replaces the inacessible tile with an accesible one
                Destroy(gameObject);
            }
    }
}
