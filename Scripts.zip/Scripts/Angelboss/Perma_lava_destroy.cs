﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Perma_lava_destroy : MonoBehaviour
{
    private int count;
    public GameObject rock;
    public Animator animator;
    private bool untouched;
    private bool no = false;
    public int sunk_frames = 150;
    void FixedUpdate()
    {
        if (untouched)
        {
            count++;
            if (count == sunk_frames - 27)
            {
                animator.SetBool("Rising", true);//Makes it so that the tile appears to resurface before it becomes accesible
            }
            if (count == sunk_frames)//Resurfaces the tile when enough frames have passed after the rock destroying object has left it
            {
                Instantiate(rock, transform.position, Quaternion.identity);//Replaces the inacessible tile with an accesible one
                Destroy(gameObject);
            }
        }
        else
        {
            count = 0; //Resets the count to 0 if the tile has been touched by a rock destroying object again
        }
        GameObject skull = GameObject.Find("Skull");
        Angel_attack_pattern transition = skull.GetComponent<Angel_attack_pattern>();
        sunk_frames = transition.current_lava_frames; //Causes the tile to resurface at a specific time if the boss is moving onto the next phase
        if(transition.transitioning && !no)
        {
            count = 0;
            sunk_frames = 50; 
            no = true; //Makes it so that the script no longer checks if a rock destroying object is on it
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (!no) //Checks if the boss is moving onto a new phase
        {
            untouched = true; //Tells the script that the tile will resurface 
        }
    }
    private void OnTriggerStay2D(Collider2D other)
    {
        if (!no&&(other.CompareTag("Player") || other.CompareTag("Rock_destroying")|| other.CompareTag("Mass_rock_destroying")))
        {//Checks if a rock destroying object is still longer on the tile 
            untouched = false; //Tells the script that the tile is still not resurfacing
            animator.SetBool("Rising", false); //Lets the animator know the tile is still not resurfacing
        }
    }
}