﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Angel_attack_pattern : MonoBehaviour
{
    public int attack_phase;
    public Transform left_hand;
    public Transform right_hand;
    public Transform left_humerus;
    public Transform right_humerus;
    public Transform ribcage;
    public int count;
    public Rigidbody2D rb;
    public int animation_timer;
    public bool transitioning;
    public int current_lava_frames = 150;
    void FixedUpdate()
    {
        Animate();
        if (attack_phase == 1)
        {
            if(count == 0 && left_hand.position.x > -3) //Checks where the parts of the body are and moves them into their next positions
            {
                left_hand.transform.position -= new Vector3(0.1f, 0, 0);
                right_hand.transform.position += new Vector3(0.1f, 0, 0); //Moves the right hand symetrically since they move the same way
            }
            else if(count == 0)
            {
                count = 1; //Moves onto the next part of the movement
            }
            if (count == 1 && left_hand.position.y > -4.08)
            {
                left_hand.transform.position -= new Vector3(0, 0.05f, 0);
                right_hand.transform.position -= new Vector3(0, 0.05f, 0);
            }
            else if (count == 1)
            {
                count = 2;
            }
            if(count == 2 && left_hand.position.y < -2.42)
            {
                left_hand.transform.position += new Vector3(0, 0.05f, 0);
                right_hand.transform.position += new Vector3(0, 0.05f, 0);
            }
            else if (count == 2)
            {
                count = 3;
            }
            if (count == 3 && left_hand.position.x < -2.24)
            {
                left_hand.transform.position += new Vector3(0.1f, 0, 0);
                right_hand.transform.position -= new Vector3(0.1f, 0, 0);
            }
            else if (count == 3)
            {
                count = 4;
            }
            if (count == 4 && left_hand.position.y > -4.84)
            {
                left_hand.transform.position -= new Vector3(0, 0.05f, 0);
                right_hand.transform.position -= new Vector3(0,0.05f,0);
            }
            else if (count == 4)
            {
                count = 5;
            }
            if (count == 5 && left_hand.position.y < -2.42)
            {
                left_hand.transform.position += new Vector3(0, 0.05f, 0);
                right_hand.transform.position += new Vector3(0, 0.05f, 0);
            }
            else if (count == 5)
            {
                count = 6;
            }
            if (count == 6 && left_hand.position.x < -1.48)
            {
                left_hand.transform.position += new Vector3(0.1f, 0, 0);
                right_hand.transform.position -= new Vector3(0.1f, 0, 0);
            }
            else if (count == 6)
            {
                count = 7;
            }
            if (count == 7 && left_hand.position.y > -4.84)
            {
                left_hand.transform.position -= new Vector3(0, 0.05f, 0);
                right_hand.transform.position -= new Vector3(0, 0.05f, 0);
            }
            else if (count == 7)
            {
                count = 8;
            }
            if (count == 8 && left_hand.position.y < -2.42)
            {
                left_hand.transform.position += new Vector3(0, 0.05f, 0);
                right_hand.transform.position += new Vector3(0, 0.05f, 0);
            }
            else if (count == 8)
            {
                count = 9;
            }
            if (count == 9 && left_hand.position.x < -0.72)
            {
                left_hand.transform.position += new Vector3(0.1f, 0, 0);
                right_hand.transform.position -= new Vector3(0.1f, 0, 0);
            }
            else if (count == 9)
            {
                count = 10;
            }
            if (count == 10 && left_hand.position.y > -4.84)
            {
                left_hand.transform.position -= new Vector3(0, 0.05f, 0);
                right_hand.transform.position -= new Vector3(0, 0.05f, 0);
            }
            else if (count == 10)
            {
                count = 11;
            }
            if(count == 11 && left_hand.position.y < -2.42)
            {
                left_hand.transform.position += new Vector3(0, 0.05f, 0);
                right_hand.transform.position += new Vector3(0, 0.05f, 0);
            }
            else if(count == 11)
            {
                count = 12;
            }
            if (count == 12 && left_hand.position.x > -2.56)
            {
                left_hand.transform.position -= new Vector3(0.1f, 0, 0);
                right_hand.transform.position += new Vector3(0.1f, 0, 0);
            }
            else if(count == 12)
            {
                transitioning = true;
            }
        }
        if (transitioning)
        {
            Transition();
        }
    }
    private void Animate() //Moves the bones of the boss in a repeating pattern
    {
        if (animation_timer == 20)
        {
            left_humerus.position += new Vector3(0, 0.02f, 0);
        }
        if (animation_timer == 40)
        {
            right_humerus.position += new Vector3(0, 0.02f, 0);
        }
        if (animation_timer == 60)
        {
            ribcage.position += new Vector3(0, 0.02f, 0);
        }
        if (animation_timer == 80)
        {
            right_humerus.position -= new Vector3(0, 0.02f, 0);
        }
        if (animation_timer == 100)
        {
            left_humerus.position -= new Vector3(0, 0.02f, 0);
        }
        if (animation_timer == 120)
        {
            ribcage.position -= new Vector3(0, 0.02f, 0);
            animation_timer = 0;
        }
        animation_timer++; //Allows movement onto the next stage of the animation
    }
    private void Transition()
    {
        attack_phase++;
    }
}
