﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Keybinds : MonoBehaviour
{
    public List<string> buttons = new List<string>();
    private void Awake()
    {
        buttons.Add("w"); 
        buttons.Add("s");
        buttons.Add("a");
        buttons.Add("d");
        buttons.Add("e"); // Interact
        buttons.Add("escape");
        buttons.Add("space"); // attack
        buttons.Add("left shift");
        buttons.Add("space"); //Restart puzzle
        buttons.Add("e"); //Select
        DontDestroyOnLoad(gameObject);
    }
}
