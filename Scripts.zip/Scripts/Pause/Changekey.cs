﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Changekey : MonoBehaviour
{
    public List<string> buttons = new List<string>();
    public bool set_key;
    public int cooldown;
    private string select;
    public int menu_button;
    public Text my_text;
    public string storage;
    private void Start()
    {
        GetComponent<Changekey>().enabled = false;
    }
    private void Update()
    {
        cooldown = FindObjectOfType<Pause>().cooldown;
        buttons = FindObjectOfType<Pause>().buttons2;
        menu_button = FindObjectOfType<Pause>().menu_button;
        storage = FindObjectOfType<Pause>().storage;
    }
    void OnGUI()
    {
        set_key = true;
        if (set_key && cooldown == 0)
        {
            if (Input.GetKey("left shift"))
            {
                set_key = false;
                buttons[menu_button] = "left shift";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("right shift"))
            {
                set_key = false;
                buttons[menu_button] = "right shift";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("left ctrl"))
            {
                set_key = false;
                buttons[menu_button] = "left ctrl";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("right ctrl"))
            {
                set_key = false;
                buttons[menu_button] = "right ctrl";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("left alt"))
            {
                set_key = false;
                buttons[menu_button] = "left alt";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("right alt"))
            {
                set_key = false;
                buttons[menu_button] = "right alt";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("left cmd"))
            {
                set_key = false;
                buttons[menu_button] = "left cmd";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("right cmd"))
            {
                set_key = false;
                buttons[menu_button] = "right cmd";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("up"))
            {
                set_key = false;
                buttons[menu_button] = "up";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("down"))
            {
                set_key = false;
                buttons[menu_button] = "down";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("left"))
            {
                set_key = false;
                buttons[menu_button] = "left";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("right"))
            {
                set_key = false;
                buttons[menu_button] = "right";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("-"))
            {
                set_key = false;
                buttons[menu_button] = "-";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("="))
            {
                set_key = false;
                buttons[menu_button] = "=";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("`"))
            {
                set_key = false;
                buttons[menu_button] = "`";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("\\"))
            {
                set_key = false;
                buttons[menu_button] = "\\";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("/"))
            {
                set_key = false;
                buttons[menu_button] = "/";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("["))
            {
                set_key = false;
                buttons[menu_button] = "[";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("]"))
            {
                set_key = false;
                buttons[menu_button] = "]";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey(";"))
            {
                set_key = false;
                buttons[menu_button] = ";";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("'"))
            {
                set_key = false;
                buttons[menu_button] = "'";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey(","))
            {
                set_key = false;
                buttons[menu_button] = ",";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("."))
            {
                set_key = false;
                buttons[menu_button] = ".";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("#"))
            {
                set_key = false;
                buttons[menu_button] = "#";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("[*]"))
            {
                set_key = false;
                buttons[menu_button] = "[*]";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("[/]"))
            {
                set_key = false;
                buttons[menu_button] = "[/]";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("[-]"))
            {
                set_key = false;
                buttons[menu_button] = "[-]";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else if (Input.GetKey("[+]"))
            {
                set_key = false;
                buttons[menu_button] = "[+]";
                my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
            }
            else
            {
                Event key = Event.current;
                if (key.isKey)
                {
                    select = key.keyCode.ToString().ToLower();
                    if (select != "none" && select != "")
                    {
                        set_key = false;
                        if (menu_button == 0 && buttons[1] == select)
                        {
                            buttons[1] = storage;
                        }
                        if (menu_button == 1 && buttons[0] == select)
                        {
                            buttons[0] = storage;
                        }
                        if (menu_button == 2 && buttons[3] == select)
                        {
                            buttons[3] = storage;
                        }
                        if (menu_button == 3 && buttons[2] == select)
                        {
                            buttons[2] = storage;
                        }
                        if (menu_button == 0 && buttons[9] == select)
                        {
                            buttons[9] = storage;
                        }
                        if (menu_button == 1 && buttons[9] == select)
                        {
                            buttons[9] = storage;
                        }
                        if (menu_button == 9 && buttons[0] == select)
                        {
                            buttons[0] = storage;
                        }
                        if (menu_button == 9 && buttons[1] == select)
                        {
                            buttons[1] = storage;
                        }
                        if(select == buttons[5])
                        {
                            buttons[5] = storage;
                        }
                        buttons[menu_button] = select;
                        my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
                    }
                }
            }
            if (set_key == false)
            {
                FindObjectOfType<Keybinds>().buttons = buttons;
                FindObjectOfType<Pause>().set_key = false;
                FindObjectOfType<Pause>().cooldown = 25;
                FindObjectOfType<Pause>().buttons2 = buttons;
                Log log = FindObjectOfType<Log>();
                Keybinds keybinds = FindObjectOfType<Keybinds>();
                Save_system.Save(log, keybinds, true);
                if (FindObjectOfType<Start_menu_pointer>() != null)
                {
                    FindObjectOfType<Start_menu_pointer>().buttons = buttons;
                }
                if (FindObjectOfType<Move>() != null)
                {
                    FindObjectOfType<Move>().buttons = buttons;
                }
                if (FindObjectOfType<MultiTextImporter>() != null)
                {
                    FindObjectOfType<MultiTextImporter>().buttons = buttons;
                }
                if (FindObjectOfType<Text_importer>() != null)
                {
                    FindObjectOfType<Text_importer>().buttons = buttons;
                }
                if (FindObjectOfType<Gameover_menu>() != null)
                {
                    FindObjectOfType<Gameover_menu>().buttons = buttons;
                }
                if (FindObjectOfType<Scene_selector>() != null)
                {
                    FindObjectOfType<Scene_selector>().buttons = buttons;
                }
                if (FindObjectOfType<Player_stalactite_move>() != null)
                {
                    FindObjectOfType<Player_stalactite_move>().buttons = buttons;
                }
                if (FindObjectOfType<Player_chess_move>() != null)
                {
                    FindObjectOfType<Player_chess_move>().buttons = buttons;
                }
                if (FindObjectOfType<Player_spikes_move>() != null)
                {
                    FindObjectOfType<Player_spikes_move>().buttons = buttons;
                }
                if (FindObjectOfType<Player_lava_move>() != null)
                {
                    FindObjectOfType<Player_lava_move>().buttons = buttons;
                }
                if (FindObjectOfType<Player_patrol_move>() != null)
                {
                    FindObjectOfType<Player_patrol_move>().buttons = buttons;
                }
                if (FindObjectOfType<Player_floating_ground_move>() != null)
                {
                    FindObjectOfType<Player_floating_ground_move>().buttons = buttons;
                }
                if (FindObjectOfType<Puzzle_arrow_animate_4>() != null)
                {
                    FindObjectOfType<Puzzle_arrow_animate_4>().buttons = buttons;
                }
                if (FindObjectOfType<Puzzle_arrow_animate_9>() != null)
                {
                    FindObjectOfType<Puzzle_arrow_animate_9>().buttons = buttons;
                }
                if (FindObjectOfType<Pause_menu>() != null)
                {
                    FindObjectOfType<Pause_menu>().buttons = buttons;
                }
                if (FindObjectOfType<Interact>() != null)
                {
                    FindObjectOfType<Interact>().buttons = buttons;
                }
                if (FindObjectOfType<Book_pedestal>() != null)
                {
                    FindObjectOfType<Book_pedestal>().buttons = buttons;
                }
                if (FindObjectOfType<Powerup>() != null)
                {
                    FindObjectOfType<Powerup>().buttons = buttons;
                }
                GetComponent<Changekey>().enabled = false;
            }
        }
    }
}
