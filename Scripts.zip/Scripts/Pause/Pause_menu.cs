﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pause_menu : MonoBehaviour
{
    public bool menu_exists = false;
    public List<string> buttons = new List<string>();
    public GameObject pause_menu;
    public bool pause;
    private void Start()
    {
        buttons = FindObjectOfType<Keybinds>().buttons;
    }
    void Update()
    {
        if (Input.GetKeyDown(buttons[5]) || pause) //Pauses when the pause button is pressed, or an external script triggers the pause
        {
            if (menu_exists == false)//Checks whether the pause menu already exists
            {
                pause = false;
                Time.timeScale = 0;
                Time.fixedDeltaTime = 0; //Freezes time
                if(FindObjectOfType<Move>()!= null)
                {
                    FindObjectOfType<Move>().enabled = false;
                }
                if (FindObjectOfType<MultiTextImporter>() != null)
                {
                    FindObjectOfType<MultiTextImporter>().enabled = false;
                }
                if (FindObjectOfType<Start_menu_pointer>() != null)
                {
                    FindObjectOfType<Start_menu_pointer>().enabled = false;
                }
                if (FindObjectOfType<Scene_selector>() != null)
                {
                    FindObjectOfType<Scene_selector>().enabled = false;
                }
                if (FindObjectOfType<Text_importer>() != null)
                {
                    FindObjectOfType<Text_importer>().enabled = false;
                }
                if (FindObjectOfType<Powerup>() != null)
                {
                    FindObjectOfType<Powerup>().enabled = false;
                }
                if (FindObjectOfType<Interact>() != null)
                {
                    FindObjectOfType<Interact>().enabled = false;
                }
                if (FindObjectOfType<Book_pedestal>() != null)
                {
                    FindObjectOfType<Book_pedestal>().enabled = false;
                }
                if (FindObjectOfType<Player_chess_move>() != null)
                {
                    FindObjectOfType<Player_chess_move>().enabled = false;
                }
                if (FindObjectOfType<Player_floating_ground_move>() != null)
                {
                    FindObjectOfType<Player_floating_ground_move>().enabled = false;
                }
                if (FindObjectOfType<Player_lava_move>() != null)
                {
                    FindObjectOfType<Player_lava_move>().enabled = false;
                }
                if (FindObjectOfType<Player_patrol_move>() != null)
                {
                    FindObjectOfType<Player_patrol_move>().enabled = false;
                }
                if (FindObjectOfType<Player_spikes_move>() != null)
                {
                    FindObjectOfType<Player_spikes_move>().enabled = false;
                }
                if (FindObjectOfType<Player_stalactite_move>() != null)
                {
                    FindObjectOfType<Player_stalactite_move>().enabled = false;
                }
                if (FindObjectOfType<Puzzle_arrow_animate_4>() != null)
                {
                    FindObjectOfType<Puzzle_arrow_animate_4>().enabled = false;
                }
                if (FindObjectOfType<Puzzle_arrow_animate_9>() != null)
                {
                    FindObjectOfType<Puzzle_arrow_animate_9>().enabled = false;
                }
                menu_exists = true;
                float camera_size = FindObjectOfType<Camera>().orthographicSize;
                Instantiate(pause_menu, new Vector3(FindObjectOfType<Camera>().transform.position.x, FindObjectOfType<Camera>().transform.position.y, 0), Quaternion.Euler(0,180,0)).transform.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f) * camera_size;
            }//Makes the size of the menu scale with the size of the camera
        }
    }
}
