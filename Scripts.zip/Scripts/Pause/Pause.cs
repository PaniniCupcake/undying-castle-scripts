﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
public class Pause : MonoBehaviour
{
    public int menu_button = 0;
    public int cooldown = 25;
    public Transform pointer;
    public Transform book;
    public float size;
    public bool set_key;
    private string filler_string;
    public List<string> buttons = new List<string>();
    public List<string> buttons2 = new List<string>();
    public bool pause_menu;
    public bool options_menu;
    public bool keybinds_menu;
    public Text my_text;
    public Text title;
    public float start_pos;
    public string storage;
    public int count;
    private int i;
    private bool selected;
    private int startup = 50;
    private int turning = 45;
    private float camera_size;
    private void Start()
    {
        start_pos = pointer.transform.position.y;
        buttons2 = FindObjectOfType<Keybinds>().buttons; //Buttons is an array for temporary use when changing binds
        for (i = 0; i < 10; i++)
        {
            buttons.Add(buttons2[i]);
        }
        camera_size = FindObjectOfType<Camera>().orthographicSize;
        book.position += new Vector3(0, 3f, 0) * camera_size;
        size = camera_size / 5;
    }
    private void OnEnable()
    {
        if(FindObjectOfType<Keybinds>() != null)
        {
            buttons2 = FindObjectOfType<Keybinds>().buttons;
        }
    }
    void Update()
    {
        if (startup > 0)
        {
            book.position -= new Vector3(0, 0.06f, 0) * camera_size;
            startup--;
        }
        else if(startup < 0)
        {
            book.position += new Vector3(0, 0.06f, 0) * camera_size;
            if(startup == -1)
            {
                if (FindObjectOfType<Move>() != null)
                {
                    FindObjectOfType<Move>().enabled = true;
                }
                if (FindObjectOfType<MultiTextImporter>() != null)
                {
                    FindObjectOfType<MultiTextImporter>().enabled = true;
                }
                if (FindObjectOfType<Start_menu_pointer>() != null)
                {
                    FindObjectOfType<Start_menu_pointer>().enabled = true;
                }
                if (FindObjectOfType<Scene_selector>() != null)
                {
                    FindObjectOfType<Scene_selector>().enabled = true;
                }
                if (FindObjectOfType<Text_importer>() != null)
                {
                    FindObjectOfType<Text_importer>().enabled = true;
                }
                if (FindObjectOfType<Powerup>() != null)
                {
                    FindObjectOfType<Powerup>().enabled = true;
                }
                if (FindObjectOfType<Interact>() != null)
                {
                    FindObjectOfType<Interact>().enabled = true;
                }
                if (FindObjectOfType<Book_pedestal>() != null)
                {
                    FindObjectOfType<Book_pedestal>().enabled = true;
                }
                if (FindObjectOfType<Player_chess_move>() != null)
                {
                    FindObjectOfType<Player_chess_move>().enabled = true;
                }
                if (FindObjectOfType<Player_floating_ground_move>() != null)
                {
                    FindObjectOfType<Player_floating_ground_move>().enabled = true;
                }
                if (FindObjectOfType<Player_lava_move>() != null)
                {
                    FindObjectOfType<Player_lava_move>().enabled = true;
                }
                if (FindObjectOfType<Player_patrol_move>() != null)
                {
                    FindObjectOfType<Player_patrol_move>().enabled = true;
                }
                if (FindObjectOfType<Player_spikes_move>() != null)
                {
                    FindObjectOfType<Player_spikes_move>().enabled = true;
                }
                if (FindObjectOfType<Player_stalactite_move>() != null)
                {
                    FindObjectOfType<Player_stalactite_move>().enabled = true;
                }
                if (FindObjectOfType<Puzzle_arrow_animate_4>() != null)
                {
                    FindObjectOfType<Puzzle_arrow_animate_4>().enabled = true;
                }
                if (FindObjectOfType<Puzzle_arrow_animate_9>() != null)
                {
                    FindObjectOfType<Puzzle_arrow_animate_9>().enabled = true;
                }
                Time.timeScale = 1;
                Time.fixedDeltaTime = 0.02f;
                FindObjectOfType<Pause_menu>().menu_exists = false;
                Destroy(book.gameObject);
            }
            startup++;
        }
        else if (turning > 0)
        {
            if (turning == 45)
            {
                pointer.position = new Vector3(pointer.position.x, start_pos, 0);
                if (keybinds_menu)
                {
                    title.text = "KEYBINDS";
                    my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9];
                }
                else if (options_menu)
                {
                    title.text = "OPTIONS";
                    my_text.text = "Keybinds\n\n\nSounds & Music\n\n\nReset settings\n\n\nBack";
                }
                else
                {
                    title.text = "TIME PAUSED";
                    my_text.text = "Resume\n\n\nOptions\n\n\nMain menu\n\n\nQuit";
                }
            }
            book.transform.Rotate(0, 4, 0);
            turning--;
        }
        else
        {
            if (cooldown == 0 && set_key == false)
            {
                for (i = 0; i < 10; i++)
                {
                    buttons[i] = buttons2[i]; //Updates the main buttons with the updated temporary ones
                }
                if (Input.GetKeyDown(buttons2[5]))
                {
                    startup = -51;
                }
                if (pause_menu)//Determines which menu the player is currently in
                {
                    if (Input.GetKey(buttons2[0]))//Navigates through the menu
                    {
                        if (menu_button == 0)
                        {
                            menu_button = 3;
                            pointer.position += new Vector3(0, size * -4.05f, 0);
                        }
                        else
                        {
                            pointer.position += new Vector3(0, size * 1.35f, 0);
                            menu_button--;
                        }
                        cooldown = 15;
                    }
                    else if (Input.GetKey(buttons2[1]))
                    {
                        if (menu_button == 3)
                        {
                            pointer.position += new Vector3(0, size * 4.05f, 0);
                            menu_button = 0;
                        }
                        else
                        {
                            pointer.position += new Vector3(0, size * -1.35f, 0);
                            menu_button++;
                        }
                        cooldown = 15;
                    }
                    if (Input.GetKeyDown(buttons2[9]))
                    {
                        if (menu_button == 0)
                        {//Resumes the game, destroying the menu and unpausing time
                            startup = -51;
                        }
                        if (menu_button == 1)
                        {//Loads the options menu
                            pause_menu = false;
                            options_menu = true;
                            turning = 90;
                            menu_button = 0;
                        }
                        if (menu_button == 2)
                        {//Reloads the start menu
                            SceneManager.LoadScene("Start menu");
                            Time.timeScale = 1;
                            Time.fixedDeltaTime = 0.02f;
                            FindObjectOfType<Pause_menu>().menu_exists = false;
                        }
                        if (menu_button == 3)
                        {//Closes the game
                            Application.Quit();
                            Time.timeScale = 1;
                            Time.fixedDeltaTime = 0.02f;
                            FindObjectOfType<Pause_menu>().menu_exists = false;
                        }
                        cooldown = 25;
                    }
                }
                else if (options_menu)
                {
                    if (Input.GetKeyDown(buttons2[0]))
                    {
                        if (menu_button == 0)
                        {
                            menu_button = 3;
                            pointer.position += new Vector3(0, size * -4.05f, 0);
                        }
                        else
                        {
                            pointer.position += new Vector3(0, size * 1.35f, 0);
                            menu_button--;
                        }
                        cooldown = 15;
                    }
                    else if (Input.GetKey(buttons2[1]))
                    {
                        if (menu_button == 3)
                        {
                            pointer.position += new Vector3(0, size * 4.05f, 0);
                            menu_button = 0;
                        }
                        else
                        {
                            pointer.position += new Vector3(0, size * -1.35f, 0);
                            menu_button++;
                        }
                        cooldown = 15;
                    }
                    if (Input.GetKey(buttons2[9]))
                    {
                        if (menu_button == 0)
                        {
                            options_menu = false;
                            turning = 90;
                            keybinds_menu = true;
                        }//Loads the keybinds menu, displaying what the current keybinds are
                        if (menu_button == 1)
                        {
                            // Music has not yet been properly implemented
                        }
                        if (menu_button == 2)
                        {//Resets the keybinds
                            buttons2.Clear();
                            buttons2.Add("w");
                            buttons2.Add("s");
                            buttons2.Add("a");
                            buttons2.Add("d");
                            buttons2.Add("e");
                            buttons2.Add("escape");
                            buttons2.Add("space");
                            buttons2.Add("left shift");
                            buttons2.Add("space");
                            buttons2.Add("e");
                            for (i = 0; i < 10; i++)
                            {
                                buttons[i] = buttons2[i];
                            }
                            Log log = FindObjectOfType<Log>();
                            Keybinds keybinds = FindObjectOfType<Keybinds>();
                            keybinds.buttons = buttons;
                            Save_system.Save(log, keybinds, true);
                            my_text.text = "Keybinds\n\n\nSounds & Music\n\n\nSettings reset\n\n\nBack";
                        }
                        if (menu_button == 3)
                        {
                            pause_menu = true;
                            options_menu = false;
                            turning = 90;
                            menu_button = 0;
                        }
                        cooldown = 25;
                    }
                }
                else if (keybinds_menu)
                {
                    if (Input.GetKey(buttons2[0]))
                    {
                        if (menu_button == 0)
                        {
                            menu_button = 10;
                            pointer.position += new Vector3(0, size * -4.05f, 0) + new Vector3(0, size * -1.35f, 0) / 3;
                        }
                        else
                        {
                            pointer.position += new Vector3(0, size * 1.35f, 0) / 3;
                            menu_button--;
                        }
                        cooldown = 15;
                    }
                    else if (Input.GetKey(buttons2[1]))
                    {
                        if (menu_button == 10)
                        {
                            pointer.position += new Vector3(0, size * 4.05f, 0) + new Vector3(0, size * 1.35f, 0) / 3;
                            menu_button = 0;
                        }
                        else
                        {
                            pointer.position += new Vector3(0, size * -1.35f, 0) / 3;
                            menu_button++;
                        }
                        cooldown = 15;
                    }
                    if (Input.GetKeyDown(buttons2[9]))
                    {
                        if (menu_button == 10)
                        {
                            options_menu = true;
                            keybinds_menu = false;
                            menu_button = 0;
                            turning = 90;
                        }
                        else
                        {
                            storage = buttons[menu_button];
                            buttons[menu_button] = "";
                            set_key = true;
                            GetComponent<Changekey>().enabled = true;
                        }
                        cooldown = 25;
                    }
                }
            }
            if (cooldown > 0)
            {
                cooldown--;
            }
            if (keybinds_menu)
            {
                if (count == 10)
                {
                    count = 0;
                    selected = true;
                    for (i = 0; i < 10; i++)
                    {
                        if (buttons[i] == "")
                        {
                            buttons[i] = "_";
                            selected = false;
                        }
                        else if (buttons[i] == "_")
                        {
                            buttons[i] = "";
                            selected = false;
                        }
                    }
                    if (!selected)
                    {
                        my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
                    }
                    else
                    {
                        buttons = buttons2;
                        my_text.text = "Move up: " + buttons[0] + "\nMove down: " + buttons[1] + "\nMove left: " + buttons[2] + "\nMove right: " + buttons[3] + "\nInteract: " + buttons[4] + "\nPause: " + buttons[5] + "\nAttack: " + buttons[6] + "\nRun: " + buttons[7] + "\nRedo pzl: " + buttons[8] + "\nSelect: " + buttons[9] + "\nBack";
                    }
                }
                count++;
            }
        }
    }
}
