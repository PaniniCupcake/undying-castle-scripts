﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cannon_shadow : MonoBehaviour {
    public float height;
    public int direction;
    public GameObject cannonball;
    public GameObject explosion;
    private float acceleration;
    private void OnEnable()
    {
        cannonball = Object_spawn("Cannonball", new Vector3(transform.position.x, transform.position.y + height, 0), Quaternion.identity);
        acceleration = 0;
    }
    void FixedUpdate () {
        acceleration += 0.001f;
        height -= acceleration;
        if (Mathf.Abs(transform.position.x) >= 9.1)
        {
            gameObject.SetActive(false); 
        }
        if (transform.position.y <= -12.34f)
        {
            gameObject.SetActive(false);
        }
        if (direction == 1)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y - 0.05f, 0);
        }
        if (direction == 2)
        {
            transform.position = new Vector3(transform.position.x + 0.05f, transform.position.y, 0);
        }
        if (direction == 3)
        {
            transform.position = new Vector3(transform.position.x - 0.05f, transform.position.y, 0);
        }
        if (height <= 0)
        {
            gameObject.SetActive(false);
        }
    }
    private GameObject Object_spawn(string name, Vector3 position, Quaternion rotation)
    {
        GameObject attack = Pool.SharedInstance.GetPooledObject(name + "(Clone)");
        if (attack != null)
        {
            Cannonball_fire cannonball_direction = attack.GetComponent<Cannonball_fire>();
            cannonball_direction.direction = direction;
            cannonball_direction.height = height;
            attack.transform.position = position;
            attack.transform.rotation = rotation;
            attack.SetActive(true);
            return attack;
        }
        else
        {
            return null;
        }
    }
}
