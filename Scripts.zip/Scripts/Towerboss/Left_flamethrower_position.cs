﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Left_flamethrower_position : MonoBehaviour {
    public Transform tower_position;
    public Transform player_position;
    private Vector3 position;
    public bool destroyed;
    private int count = 0;
    public Animator animator;
    void Start()
    {
    }
    void Update()
    {
        position = tower_position.position + new Vector3(-2.08f, -2.9f, 0);
        transform.position = position;
            if (player_position.position.y > transform.position.y)
            {
                GetComponent<SpriteRenderer>().sortingOrder = 7;
            }
            else if (player_position.position.y < transform.position.y)
            {
                GetComponent<SpriteRenderer>().sortingOrder = 5;
            }
        else { count++; }
        if (destroyed)
        {
            animator.SetBool("Destroyed", true);
        }
    }
}
