﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spikes_disappear : MonoBehaviour {
    public int count = 0;
    private void OnEnable()
    {
        Spikes_damage damaging = gameObject.GetComponent<Spikes_damage>();
        damaging.spiking = false;
        count = 0;
    }
    void FixedUpdate () {
        if(count == 50)
        {
            Spikes_damage damaging = gameObject.GetComponent<Spikes_damage>();
            damaging.spiking = true;
        }
		if(count == 100)
        {
            gameObject.SetActive(false);
        }
        count++;
	}
}
