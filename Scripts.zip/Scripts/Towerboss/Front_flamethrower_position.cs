﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Front_flamethrower_position : MonoBehaviour {
    public Transform tower_position;
    private Vector3 position;
    private int count = 0;
    public Transform player_position;
    public bool destroyed = false;
    public Animator animator;
	void Update () {
        position = tower_position.position + new Vector3(0, -3.501f, 0);
        transform.position = position;
        if(count == 1725)
        {
            if (player_position.position.y > transform.position.y)
            {
                GetComponent<SpriteRenderer>().sortingOrder = 8;
            }
            else if (player_position.position.y < transform.position.y)
            {
                GetComponent<SpriteRenderer>().sortingOrder = 5;
            }
        }
        else if(count < 1725)
        {
            count++;
        }
        if (destroyed)
        {
            animator.SetBool("Destroyed", true);
        }
    }
}
