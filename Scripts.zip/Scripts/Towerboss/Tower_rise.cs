﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tower_rise : MonoBehaviour
{
    public Transform rising;
    public Transform player_position;
    private int count = -1;
    private Vector3 pos;
    public bool rise = false;
    public bool insta_begin;
    public int start_phase;
    void Start()
    {
        pos = rising.position;
        FindObjectOfType<Log>().boss = true;
        if(FindObjectOfType<Log>().current_boss == 4 && FindObjectOfType<Log>().boss_checkpoints[0][0]==1)
        {
            insta_begin = true;
        }
    }
    void FixedUpdate()
    {
        if (!rise)
        {
            Text_importer text_stuff = FindObjectOfType<Text_importer>();
            if (text_stuff == null)
            {
                rise = true;
            }
        }
        if (!insta_begin)
        {
            if (rise)
            {
                if (count == -1)
                {
                    GameObject player = GameObject.Find("Player");
                    Move move = player.GetComponent<Move>();
                    move.allow_movement = false;
                    move.allow_attack = false;
                    GameObject.Find("Boss_frame").GetComponent<move_amount>().enabled = true;
                    GameObject.Find("Candle_holder").GetComponent<move_amount>().enabled = true;
                    GameObject.Find("Powerups").GetComponent<move_amount>().enabled = true;
                    GameObject elevator = GameObject.Find("Elevator");
                    RISE elevator_rising = elevator.GetComponent<RISE>();
                    elevator_rising.rise = true;
                    count++;
                    GameObject lhatch = GameObject.Find("Left_door");
                    Left_hatch_open lhatchscript = lhatch.GetComponent<Left_hatch_open>();
                    lhatchscript.open = true;
                    GameObject rhatch = GameObject.Find("Right_door");
                    Right_hatch_open rhatchscript = rhatch.GetComponent<Right_hatch_open>();
                    rhatchscript.open = true;
                }
                if (count < 1725)
                {
                    pos += new Vector3(0, 0.01f, 0);
                    transform.position = pos;
                    GameObject player = GameObject.Find("Player");
                    count++;
                }
                else if (count == 1725)
                {
                    FindObjectOfType<Boss_text>().Next_paragraph();
                    GameObject.Find("Boss_frame").GetComponent<move_amount>().enabled = false;
                    GameObject.Find("Candle_holder").GetComponent<move_amount>().enabled = false;
                    FindObjectOfType<Attack_warnings>().count = 62;
                    FindObjectOfType<Side_boss_bar>().count = 59;
                    FindObjectOfType<Attack_warnings>().accel = 0.1f;
                    FindObjectOfType<Side_boss_bar>().accel = 0.1f;
                    GameObject walls = GameObject.Find("Test_walls");
                    Destroy(walls);
                    GameObject ground = GameObject.Find("Lower_ground");
                    ground.GetComponent<SpriteRenderer>().sortingLayerName = "Background";
                    GameObject shaft = GameObject.Find("Shaft");
                    Tower_attack_pattern attacking = gameObject.GetComponent<Tower_attack_pattern>();
                    attacking.attack_phase = start_phase;
                    attacking.interval = true;
                    attacking.interval_menu.active = true;
                    GameObject player = GameObject.Find("Player");
                    Destroy(shaft);
                    count++;
                    Destroy(this);
                }
            }
        }
        else
        {
            if (count == -1)
            {
                GameObject.Find("Boss_frame").transform.position = new Vector3(0, 12.13f, 0);
                GameObject.Find("Candle_holder").transform.position = new Vector3(-23.55f, -9.83f, 0);
                GameObject.Find("Powerups").transform.position = new Vector3(44.5f, -7.33f, 0);
                transform.position = new Vector3(0, -0.35f, 0);
                GameObject elevator = GameObject.Find("Elevator");
                RISE elevator_rising = elevator.GetComponent<RISE>();
                elevator_rising.rise = false;
                elevator_rising.animator.SetBool("Rising", false);
                elevator.transform.position += new Vector3(0, 17.25f, 0);
                GameObject ground = GameObject.Find("Lower_ground");
                ground.GetComponent<SpriteRenderer>().sortingLayerName = "Background";
                GameObject shaft = GameObject.Find("Shaft");
                Destroy(shaft);
                GameObject walls = GameObject.Find("Test_walls");
                Destroy(walls);

                count = 1;
            }
            else
            {
                if (player_position.position.y > transform.position.y - 1.5)
                {
                    GetComponent<SpriteRenderer>().sortingOrder = 7;
                }
                else if (player_position.position.y < transform.position.y - 1.5)
                {
                    GetComponent<SpriteRenderer>().sortingOrder = 4;
                }
            }
            if (rise)
            {
                FindObjectOfType<Boss_text>().Next_paragraph();
                Tower_attack_pattern attacking = gameObject.GetComponent<Tower_attack_pattern>();
                attacking.attack_phase = start_phase;
                attacking.interval = true;
                attacking.interval_menu.active = true;
                GameObject player = GameObject.Find("Player");
                Move move = player.GetComponent<Move>();
                move.allow_movement = false;
                move.allow_attack = false;
                FindObjectOfType<Attack_warnings>().count = 62;
                FindObjectOfType<Side_boss_bar>().count = 59;
                FindObjectOfType<Attack_warnings>().accel = 0.1f;
                FindObjectOfType<Side_boss_bar>().accel = 0.1f;
                Destroy(this);
            }
        }
    }
}