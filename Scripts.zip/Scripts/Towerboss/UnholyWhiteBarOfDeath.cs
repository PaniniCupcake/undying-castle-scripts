﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnholyWhiteBarOfDeath : MonoBehaviour {
    public int direction;
    public GameObject NEWBAR;
    public int count = 0;
    private void Start()
    {
        if (transform.position.x < 40 && transform.position.x > -40)
        {
            Instantiate(NEWBAR, transform.position + new Vector3(0.04f * direction, 0, 0), Quaternion.identity);
        }
    }
    private void Update()
    {
        if(count == 200)
        {
            Destroy(gameObject);
        }
        count++;
    }
}
