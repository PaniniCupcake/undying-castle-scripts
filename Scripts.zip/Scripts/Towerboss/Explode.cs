﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explode : MonoBehaviour
{
    private int count = 0;
    private void OnEnable()
    {
        count = 0;
    }
    void FixedUpdate()
    {
        if (count == 75)
        {
            Object_spawn("Explosion_shadow", transform.position, transform.rotation);
            gameObject.SetActive(false);
        }
        count++;
        GetComponent<SpriteRenderer>().sortingOrder = Mathf.RoundToInt(-transform.position.y * 10000 + 1000000);
    }
    private GameObject Object_spawn(string name, Vector3 position, Quaternion rotation)
    {
        GameObject attack = Pool.SharedInstance.GetPooledObject(name + "(Clone)");
        if (attack != null)
        {
            attack.transform.position = position;
            attack.transform.rotation = rotation;
            attack.SetActive(true);
            return attack;
        }
        else
        {
            return null;
        }
    }
}

