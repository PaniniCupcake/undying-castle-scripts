﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Left_hatch_open : MonoBehaviour {
    public Transform hatch_left;
    private double count;
    private Vector3 pos;
    public bool open;

    void Start () {
        pos = hatch_left.position;
	}
    void FixedUpdate() {
        if (open)
        {
            GetComponent<SpriteRenderer>().color = new Color(0.85f, 0.85f, 0.85f, 1);
            if (count < 1000)
            {
                pos += new Vector3(-0.005f, 0, 0);
                transform.position = pos;
                count += 1;
            }
            else
            {
                Destroy(gameObject);
            }
        }
    }
}
