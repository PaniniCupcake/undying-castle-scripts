﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fire_shell : MonoBehaviour {
    private int count=0;
    private Vector3 pos;
    public Transform tower;
    public Transform target;
    public GameObject Explosion;
    public GameObject Explosion2;
    public GameObject shadow;
    public int height = 125;
    void OnEnable () {
        tower = FindObjectOfType<Tower_attack_pattern>().transform;
        pos = tower.position + new Vector3(0,3.45f,0);
        height = 125;
        count = 0;
    }
    void FixedUpdate() {
            if (count < 250)
            {
                pos += new Vector3(0, 0.2f, 0);
                transform.position = pos;
            }
            else if (count == 250)
            {
                target = FindObjectOfType<Move>().transform;
                pos = target.position + new Vector3(0.0312f + FindObjectOfType<Move>().rb.velocity.x * 1.5f+ 0.018f, 25-0.4f + FindObjectOfType<Move>().rb.velocity.y * 1.5f, 0);
                transform.Rotate(180, 0, 0);
            Object_spawn("Shell_shadow",target.position + new Vector3(0.0312f + FindObjectOfType<Move>().rb.velocity.x *1.5f + 0.018f,-0.4f + FindObjectOfType<Move>().rb.velocity.y * 1.5f, 0), Quaternion.identity);
            }
            else if (count < 314)
            {
                pos += new Vector3(0, -0.4f, 0);
                transform.position = pos;
                if(target.position.y > transform.position.y && count<371 )
                {
                    GetComponent<SpriteRenderer>().sortingOrder = 7;
                }
                else if(target.position.y < transform.position.y && count > 371)
                {
                    GetComponent<SpriteRenderer>().sortingOrder = 5;
                }
            }
            else {
            Object_spawn("Explosion_low", new Vector3(transform.position.x + 0.02f, transform.position.y + 0.5f, 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
            gameObject.SetActive(false);
        }   
        count++;
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox")&&(count==313))
        {
            Object_spawn("Explosion_high", new Vector3(transform.position.x + 0.02f, transform.position.y + 0.5f, 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
            gameObject.SetActive(false);
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
        }
    }
    private GameObject Object_spawn(string name, Vector3 position, Quaternion rotation)
    {
        GameObject attack = Pool.SharedInstance.GetPooledObject(name + "(Clone)");
        if (attack != null)
        {
            attack.transform.position = position;
            attack.transform.rotation = rotation;
            attack.SetActive(true);
            return attack;
        }
        else
        {
            return null;
        }
    }
}

