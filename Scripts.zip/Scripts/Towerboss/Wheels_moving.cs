﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wheels_moving : MonoBehaviour {
    public bool wheels_turning;
    public bool wheels_fast_turning;
    public Animator animator;
	void Update () {
        if (wheels_turning)
        {
            animator.SetBool("Turning", true);
        }
        else
        {
            animator.SetBool("Turning", false);
        }
        if(wheels_fast_turning)
        {
            animator.SetBool("Fast_turning", true);
        }
        else
        {
            animator.SetBool("Fast_turning", false);
        }
        if(wheels_turning||wheels_fast_turning)
        {
            gameObject.tag = "Base_damaging";
        }
        else
        {
            gameObject.tag = "Untagged";
        }
	}
}
