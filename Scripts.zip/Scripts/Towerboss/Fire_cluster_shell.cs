﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fire_cluster_shell : MonoBehaviour {
    private int count = 0;
    private Vector3 pos;
    public GameObject shell;
    private void OnEnable()
    {
        count = 0;
    }
    void FixedUpdate () {
        if (count < 250)
        {
            transform.position += new Vector3(0, 0.2f, 0);
        }
        else if (count == 250)
        {
            var shell1 = Object_spawn("Falling_shell", transform.position, Quaternion.identity);
            Shell_descend descend_offset_1 = shell1.GetComponent <Shell_descend>();
            descend_offset_1.y_dif = 0.75f;
            var shell2 = Object_spawn("Falling_shell", transform.position, Quaternion.identity);
            Shell_descend descend_offset_2 = shell2.GetComponent<Shell_descend>();
            descend_offset_2.x_dif = 0.75f;
            var shell3 = Object_spawn("Falling_shell", transform.position, Quaternion.identity);
            Shell_descend descend_offset_3 = shell3.GetComponent<Shell_descend>();
            descend_offset_3.y_dif = -0.75f;
            var shell4 = Object_spawn("Falling_shell", transform.position, Quaternion.identity);
            Shell_descend descend_offset_4 = shell4.GetComponent<Shell_descend>();
            descend_offset_4.x_dif = -0.75f;
            gameObject.SetActive(false);
        }
        count++;
    }
    private GameObject Object_spawn(string name, Vector3 position, Quaternion rotation)
    {
        GameObject attack = Pool.SharedInstance.GetPooledObject(name + "(Clone)");
        if (attack != null)
        {
            attack.transform.position = position;
            attack.transform.rotation = rotation;
            attack.SetActive(true);
            return attack;
        }
        else
        {
            return null;
        }
    }
}
