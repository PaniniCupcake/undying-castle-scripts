﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cannonball_fire : MonoBehaviour {
    public Transform shadow_pos;
    public int direction;
    public float height;
    public float acceleration = 0;
    private void OnEnable()
    {
        acceleration = 0;
    }
    void FixedUpdate () {
        if (Mathf.Abs(transform.position.x) >= 9.1)
        {
            Object_spawn("Explosion_low", transform.position, Quaternion.identity);
            gameObject.SetActive(false);
        }
        if (transform.position.y <= -12.34)
        {
            Object_spawn("Explosion_low", transform.position, Quaternion.identity);
            gameObject.SetActive(false);
        }
        acceleration += 0.001f;
        height -= acceleration;
        if(direction == 1)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y - 0.05f - acceleration, 0);
            GetComponent<SpriteRenderer>().sortingOrder = 20;
        }
        if(direction == 2)
        {
            transform.position = new Vector3(transform.position.x + 0.05f, transform.position.y - acceleration, 0);
            GetComponent<SpriteRenderer>().sortingOrder = 2;
        }
        if(direction == 3)
        {
            transform.position = new Vector3(transform.position.x - 0.05f, transform.position.y - acceleration, 0);
            GetComponent<SpriteRenderer>().sortingOrder = 2;
        }
        if(height <= 0)
        {
            Object_spawn("Explosion_low", new Vector3(transform.position.x + 0.02f, transform.position.y + 0.5f, 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
            gameObject.SetActive(false);
        }
        if (height < 4 && GetComponent<SpriteRenderer>().sortingOrder != 20)
        {
            GetComponent<SpriteRenderer>().sortingOrder = 20;
        }
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox") && height>=0.4f && height<=0.66f)
        {
            Object_spawn("Explosion_high", new Vector3(transform.position.x + 0.02f, transform.position.y + 0.5f, 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
            gameObject.SetActive(false);
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
        }
    }
    private GameObject Object_spawn(string name, Vector3 position, Quaternion rotation)
    {
        GameObject attack = Pool.SharedInstance.GetPooledObject(name + "(Clone)");
        if (attack != null)
        {
            attack.transform.position = position;
            attack.transform.rotation = rotation;
            attack.SetActive(true);
            return attack;
        }
        else
        {
            return null;
        }
    }
}
