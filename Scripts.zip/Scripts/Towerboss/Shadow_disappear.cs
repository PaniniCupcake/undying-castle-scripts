﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shadow_disappear : MonoBehaviour {
    private int count;
    private void OnEnable()
    {
        count = 0;
    }
    void FixedUpdate () {
        count++;
		if(count == 62)
        {
            gameObject.SetActive(false);
        }
	}
}
