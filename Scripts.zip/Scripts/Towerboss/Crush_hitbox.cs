﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Crush_hitbox : MonoBehaviour
{
    private int count = 0;
    private void OnEnable()
    {
        transform.localScale = new Vector3(0.1f, 0.1f, 0);
        count = 0;
    }
    private void FixedUpdate()
    {
        if (count <= 7)
        {
            transform.localScale += new Vector3(0.11f, 0.11f, 0);
        }
        if (count == 10)
        {
            gameObject.SetActive(false);
        }
        count++;
    }
}