﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tower_explode : MonoBehaviour {
    public int count = 0;
    private void OnEnable()
    {
        count = 0;
    }
    void FixedUpdate () {
        count++;
        if(count == 15)
        {
            gameObject.SetActive(false);
        }
	}
}
