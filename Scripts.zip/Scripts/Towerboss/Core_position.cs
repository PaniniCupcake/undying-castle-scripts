﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Core_position : MonoBehaviour {
    public Transform player_pos;
	void Update () {
        transform.position = player_pos.position;
	}
}
