﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Left_flamethrower_fire_position : MonoBehaviour {
    public Transform tower_position;
    private Vector3 position;
    void Update()
    {
            position = tower_position.position + new Vector3(-3.44f, -2.9f, 0);
            transform.position = position;
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
        }
    }
}