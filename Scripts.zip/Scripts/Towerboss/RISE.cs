﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RISE : MonoBehaviour {
    public Transform rising;
    private int count;
    private Vector3 pos;
    public Animator animator;
    public bool rise;
    void Start()
    {
        pos = rising.position;
    }
    void FixedUpdate()
    {
        if (rise)
        {
            if (count < 1725)
            {
                pos += new Vector3(0, 0.01f, 0);
                transform.position = pos;
                count++;
            }
            if (count == 1725)
            {
                animator.SetBool("Rising", false);
                Destroy(this);
            }
        }
    }
}