﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Tower_attack_pattern : MonoBehaviour
{
    public int count = 0;
    private float x_dif;
    private float y_dif;
    public double y_pos;
    public double x_pos;
    public bool crush_attack = false;
    public int crush = 51;
    public int damage_taken = 0;
    public GameObject straight_front_laser;
    public GameObject straight_right_laser;
    public GameObject straight_left_laser;
    public GameObject fire;
    public Transform player_pos;
    public int attack_phase;
    public Rigidbody2D rb;
    public bool transitioning = false;
    public int cannons_firing = 0;
    public int laser_firing = 0;
    public int left_right;
    public int up_down;
    public GameObject whitebar;
    public GameObject whitebar2;
    public GameObject textbox;
    public Animator animator;
    public GameObject explode_shadow;
    public Attack_warnings warnings;
    public Side_boss_bar side_bar;
    private float i;
    public bool interval;
    public Powerup interval_menu;
    public Weakness_shower weakness;
    public Boss_text b_text;
    public void Start()
    {
        int j = new int();
        Log log = FindObjectOfType<Log>();
        if(log.current_boss == 4)
        {
            Destroy(FindObjectOfType<Position_checker>().gameObject);
            if (log.boss_checkpoints[1][0] == 1)
            {
                b_text.index = 11;
                FindObjectOfType<Tower_rise>().start_phase = 18;
                warnings.attack_phase = 12;
                side_bar.phase = 11;
                side_bar.GetComponent<SpriteRenderer>().sprite = side_bar.frames[10];
                Boss_bar boss = FindObjectOfType<Boss_bar>();
                for (j = 0; j < 55; j++)
                {
                    Destroy(boss.bars[j]);
                }
                boss.current_bar = 55;
                FindObjectOfType<Player_health>().Irresistable_damage(10 - log.boss_checkpoints[1][1]);
                for (j = 0; j < 5 - log.boss_checkpoints[1][2]; j++)
                {
                    Destroy(interval_menu.swords[interval_menu.swords.Count - 1]);
                    interval_menu.swords.Remove(interval_menu.swords[interval_menu.swords.Count - 1]);
                }
                for (j = 0; j < 5 - log.boss_checkpoints[1][3]; j++)
                {
                    Destroy(interval_menu.hearts[interval_menu.hearts.Count - 1]);
                    interval_menu.hearts.Remove(interval_menu.hearts[interval_menu.hearts.Count - 1]);
                }
                for (j = 0; j < 5 - log.boss_checkpoints[1][4]; j++)
                {
                    Destroy(interval_menu.caps[interval_menu.caps.Count - 1]);
                    interval_menu.caps.Remove(interval_menu.caps[interval_menu.caps.Count - 1]);
                }
                if (log.boss_checkpoints[1][5] == 1)
                {
                    FindObjectOfType<Left_flamethrower_position>().destroyed = true;
                    Destroy(FindObjectOfType<Left_flamethrower_hitbox>().gameObject);
                }
                if (log.boss_checkpoints[1][6] == 1)
                {
                    FindObjectOfType<Front_flamethrower_position>().destroyed = true;
                    Destroy(FindObjectOfType<Front_flamethrower_hitbox>().gameObject);
                }
                if (log.boss_checkpoints[1][7] == 1)
                {
                    FindObjectOfType<Right_flamethrower_position>().destroyed = true;
                    Destroy(FindObjectOfType<Right_flamethrower_hitbox>().gameObject);
                }
            }
            else if (log.boss_checkpoints[0][0] == 1)
            {
                Destroy(FindObjectOfType<Position_checker>().gameObject);
                b_text.index = 7;
                FindObjectOfType<Tower_rise>().start_phase = 8;
                warnings.attack_phase = 8;
                for (j = 0; j < 125; j++)
                {
                    side_bar.bars[j].GetComponent<SpriteRenderer>().sprite = side_bar.red_bar;
                }
                side_bar.phase = 7;
                side_bar.GetComponent<SpriteRenderer>().sprite = side_bar.frames[7];
                Boss_bar boss = FindObjectOfType<Boss_bar>();
                for (j = 0; j < 27; j++)
                {
                    Destroy(boss.bars[j]);
                }
                boss.current_bar = 27;
                FindObjectOfType<Player_health>().Irresistable_damage(10 - log.boss_checkpoints[0][1]);
                for (j = 0; j < 5 - log.boss_checkpoints[0][2]; j++)
                {
                    Destroy(interval_menu.swords[interval_menu.swords.Count - 1]);
                    interval_menu.swords.Remove(interval_menu.swords[interval_menu.swords.Count - 1]);
                }
                for (j = 0; j < 5 - log.boss_checkpoints[0][3]; j++)
                {
                    Destroy(interval_menu.hearts[interval_menu.hearts.Count - 1]);
                    interval_menu.hearts.Remove(interval_menu.hearts[interval_menu.hearts.Count - 1]);
                }
                for (j = 0; j < 5 - log.boss_checkpoints[0][4]; j++)
                {
                    Destroy(interval_menu.caps[interval_menu.caps.Count - 1]);
                    interval_menu.caps.Remove(interval_menu.caps[interval_menu.caps.Count - 1]);
                }
                for(j = 0; j < 8; j++)
                {
                    log.boss_checkpoints[1][j] = 0;
                }
                weakness.Display_weakness();
            }
        }
        else
        {
            for (j = 0; j < 8; j++)
            {
                log.boss_checkpoints[0][j] = 0;
                log.boss_checkpoints[1][j] = 0;
            }
            log.current_boss = 4;
        }
    }
    void FixedUpdate()
    {
        x_pos = transform.position.x;
        y_pos = transform.position.y;
        Wheels_moving wheels = FindObjectOfType<Wheels_moving>();
        GameObject player_position = GameObject.Find("Player");
        if (player_position.transform.position.y > transform.position.y - 1.5)
        {
            GetComponent<SpriteRenderer>().sortingOrder = 7;
        }
        else if (player_position.transform.position.y < transform.position.y - 1.5)
        {
            GetComponent<SpriteRenderer>().sortingOrder = 4;
        }
        if (wheels.wheels_turning || wheels.wheels_fast_turning)
        {
            gameObject.tag = "Base_damaging";
        }
        else
        {
            gameObject.tag = "Untagged";
        }
        if (!transitioning && !interval)
        {
            if (attack_phase == 1)
            {
                if (count == 0)
                {
                    crush_attack = true;
                    wheels.wheels_turning = true;
                    animator.SetBool("Shaking", true);
                }
                if (count == 300)
                {
                    animator.SetBool("Shaking", false);
                }
                if (count % 50 == 0 && count != 1200 && count >= 300)
                {
                    x_dif = player_pos.position.x - transform.position.x;
                    y_dif = player_pos.position.y - (transform.position.y - 2.9f);
                    if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                    {
                        rb.velocity = new Vector3(x_dif / (Mathf.Abs(y_dif / 2)), y_dif / (Mathf.Abs(y_dif) / 2), 0.0f);
                    }
                    else
                    {
                        rb.velocity = new Vector3(x_dif / (Mathf.Abs(x_dif) / 2), y_dif / (Mathf.Abs(x_dif) / 2), 0.0f);
                    }
                }
                if (count == 1500)
                {
                    transitioning = true;
                }
                else
                {
                    count++;
                    if (count >= 300)
                    {
                        side_bar.Sectionally_move(1200, count - 300);
                    }
                }
            }
            if (attack_phase == 2)
            {
                if (count % 26 == 13)
                {
                    Object_spawn("Cluster_shell", new Vector3(transform.position.x, transform.position.y + 3.501f, 0), Quaternion.identity);
                }
                if (count == 1500)
                {
                    transitioning = true;
                }
                else
                {
                    count++;
                    side_bar.Sectionally_move(1500, count);
                }
            }
            if (attack_phase == 3)
            {
                if (transform.position.x < -1.49 && transform.position.y < -4.92 && transform.position.x > -1.51 && transform.position.y > -4.94 && cannons_firing == 0)
                {
                    transform.position = new Vector3(-1.5f, -4.93f, 0);
                    rb.velocity = new Vector3(0, 0, 0);
                    cannons_firing = 1;
                }
                if (transform.position.x != -1.5 && transform.position.y != -4.93 && cannons_firing == 0)
                {
                    rb.velocity = new Vector3(-1.5f, -4.58f, 0);
                    wheels.wheels_turning = true;
                }
                if (cannons_firing == 2)
                {
                    transitioning = true;
                }
                if (cannons_firing == 1)
                {
                    if (count == 0)
                    {
                        Object_spawn("Right_fire", new Vector3(99, 99, 0), Quaternion.identity);
                        Object_spawn("Left_fire", new Vector3(99, 99, 0), Quaternion.Euler(0, 0, 180));
                        Object_spawn("Front_fire", new Vector3(99, 99, 0), Quaternion.Euler(0, 0, 270));
                    }
                    if (transform.position.y < 7.1 && transform.position.x <= -1.49)
                    {
                        rb.velocity = new Vector3(0, 1f, 0);
                    }
                    if (transform.position.y >= 7.1 && transform.position.x <= -1.5)
                    {
                        transform.position = new Vector3(-1.4999f, 7.101f, 0);
                        rb.velocity = new Vector3(1f, 0, 0);
                        side_bar.Sectionally_move(3, 0);
                    }
                    if (transform.position.y >= 7.1 && transform.position.x >= 1.5)
                    {
                        transform.position = new Vector3(1.5f, 7.0999f, 0);
                        rb.velocity = new Vector3(0, -1f, 0);
                        side_bar.Sectionally_move(3, 1);
                    }
                    if (transform.position.y <= -5.11 && transform.position.x >= 1.49)
                    {
                        side_bar.Sectionally_move(3, 2);
                        cannons_firing = 2;
                    }
                    Cannonfire();
                    count++;
                }
            }
            if (attack_phase == 4)
            {
                if (count == 0)
                {
                    wheels.wheels_turning = true;
                    Object_spawn("Right_fire", new Vector3(99, 99, 0), Quaternion.identity);
                    Object_spawn("Left_fire", new Vector3(99, 99, 0), Quaternion.Euler(0, 0, 180));
                    Object_spawn("Front_fire", new Vector3(99, 99, 0), Quaternion.Euler(0, 0, 270));
                    crush_attack = true;
                }
                if (count % 50 == 0 && count != 1200)
                {
                    x_dif = player_pos.position.x - transform.position.x;
                    y_dif = player_pos.position.y - (transform.position.y - 2.9f);
                    if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                    {
                        rb.velocity = new Vector3(x_dif / Mathf.Abs(y_dif / 2), y_dif / (Mathf.Abs(y_dif) / 2), 0.0f);
                    }
                    else
                    {
                        rb.velocity = new Vector3(x_dif / (Mathf.Abs(x_dif) / 2), y_dif / (Mathf.Abs(x_dif) / 2), 0.0f);
                    }
                }
                if (count == 1200)
                {
                    transitioning = true;
                }
                else
                {
                    count++;
                    side_bar.Sectionally_move(1200, count);
                }
            }
            if (attack_phase == 5)
            {
                if (count % 26 == 0)
                {
                    Object_spawn("Shell", new Vector3(transform.position.x, transform.position.y + 3.501f, 0), Quaternion.identity);
                }
                if (count == 1500)
                {
                    transitioning = true;
                }
                else
                {
                    side_bar.Sectionally_move(1500, count);
                    count++;
                }
            }
            if (attack_phase == 6)
            {
                if (count == 0)
                {
                    wheels.wheels_fast_turning = true;
                    crush_attack = true;
                    animator.SetBool("Shaking", true);
                }
                if (count == 200)
                {
                    animator.SetBool("Shaking", false);
                }
                if (count % 200 == 0 && count != 1200 && count != 0)
                {
                    x_dif = player_pos.position.x - transform.position.x;
                    y_dif = player_pos.position.y - (transform.position.y - 2.9f);
                    if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                    {
                        rb.velocity = new Vector3(x_dif / (Mathf.Abs(y_dif / 7)), y_dif / (Mathf.Abs(y_dif) / 7), 0.0f);
                    }
                    else
                    {
                        rb.velocity = new Vector3(x_dif / (Mathf.Abs(x_dif) / 7), y_dif / (Mathf.Abs(x_dif) / 7), 0.0f);
                    }
                }
                if (count == 1100)
                {
                    for (i = -7.56f; i <= 8.64f; i += 2.16f)
                    {
                        Object_spawn("Grey_spike_tile", new Vector3(i, 5.4f, 0), Quaternion.identity);
                        Object_spawn("Red_spike_tile", new Vector3(i, 4.32f, 0), Quaternion.identity);
                        Object_spawn("Red_spike_tile", new Vector3(i, -10.8f, 0), Quaternion.identity);
                        Object_spawn("Grey_spike_tile", new Vector3(i, -11.88f, 0), Quaternion.identity);
                    }
                    for (i = -8.64f; i <= 8.64f; i += 2.16f)
                    {
                        Object_spawn("Red_spike_tile", new Vector3(i, 5.4f, 0), Quaternion.identity);
                        Object_spawn("Grey_spike_tile", new Vector3(i, 4.32f, 0), Quaternion.identity);
                        Object_spawn("Grey_spike_tile", new Vector3(i, -10.8f, 0), Quaternion.identity);
                        Object_spawn("Red_spike_tile", new Vector3(i, -11.88f, 0), Quaternion.identity);
                    }
                }
                if (count == 1200)
                {
                    transitioning = true;
                }
                else
                {
                    if (count >= 200)
                    {
                        side_bar.Sectionally_move(1000, count - 200);
                    }
                    count++;
                }
            }
            if (attack_phase == 7)
            {
                if (laser_firing == 0)
                {
                    Instantiate(straight_front_laser, new Vector3(99, 99, 99), Quaternion.identity);
                    laser_firing = 1;
                    Object_spawn("Right_fire", new Vector3(99, 99, 0), Quaternion.identity);
                    Object_spawn("Left_fire", new Vector3(99, 99, 0), Quaternion.Euler(0, 0, 180));
                    for (i = -8.64f; i <= 8.64f; i += 1.08f)
                    {
                        Object_spawn("Spikes", new Vector3(i, 5.4f, 0), Quaternion.identity);
                        Object_spawn("Spikes", new Vector3(i, 4.32f, 0), Quaternion.identity);
                        Object_spawn("Spikes", new Vector3(i, -10.8f, 0), Quaternion.identity);
                        Object_spawn("Spikes", new Vector3(i, -11.88f, 0), Quaternion.identity);
                    }
                }
                if (player_pos.position.x > transform.position.x && left_right == 0)
                {
                    left_right = 1;
                }
                if (player_pos.position.x <= transform.position.x && left_right == 0)
                {
                    left_right = 2;
                }
                if (transform.position.x < -1.49 && transform.position.y < -4.92 && transform.position.x > -1.51 && transform.position.y > -4.94 && left_right == 2)
                {
                    transform.position = new Vector3(-1.5f, -4.93f, 0);
                    rb.velocity = new Vector3(0, 0, 0);
                    left_right = 4;
                }
                if (transform.position.x != -1.5 && transform.position.y != -5.1 && left_right == 2)
                {
                    rb.velocity = new Vector3(-1.5f, -4.58f, 0);
                    wheels.wheels_turning = true;
                }
                if (transform.position.x > 1.49 && transform.position.y < -4.92 && transform.position.x < 1.51 && transform.position.y > -4.94 && left_right == 1)
                {
                    transform.position = new Vector3(1.5f, -4.93f, 0);
                    rb.velocity = new Vector3(0, 0, 0);
                    left_right = 3;
                }
                if (transform.position.x != -1.5 && transform.position.y != -4.93 && left_right == 1)
                {
                    rb.velocity = new Vector3(1.5f, -4.58f, 0);
                    wheels.wheels_turning = true;
                }
                if (left_right == 4)
                {
                    Cannonfire();
                    count++;
                    if (up_down % 2 == 0)
                    {
                        rb.velocity = new Vector3(-1.5f - transform.position.x, 1, 0);
                        if (transform.position.y >= 7)
                        {
                            side_bar.Sectionally_move(5, up_down);
                            up_down++;
                        }
                    }
                    if (up_down % 2 == 1)
                    {
                        rb.velocity = new Vector3(-1.5f - transform.position.x, -1, 0);
                        if (transform.position.y <= -8.18)
                        {
                            side_bar.Sectionally_move(5, up_down);
                            up_down++;
                        }
                    }
                    //if (player_pos.position.y > transform.position.y && player_pos.position.x > transform.position.x - 2.08 && player_pos.position.x < transform.position.x + 2.08)
                    //{
                    //    rb.velocity = new Vector3(-1.5f - transform.position.x, 20, 0);
                    //}
                    if (transform.position.x < player_pos.position.x)
                    { left_right = 3; }
                }
                if (left_right == 3)
                {
                    Cannonfire();
                    count++;
                    if (up_down % 2 == 0)
                    {
                        rb.velocity = new Vector3(1.5f - transform.position.x, 1, 0);
                        if (transform.position.y >= 7)
                        {
                            side_bar.Sectionally_move(5, up_down);
                            up_down++;
                        }
                    }
                    if (up_down % 2 == 1)
                    {
                        rb.velocity = new Vector3(1.5f - transform.position.x, -1, 0);
                        if (transform.position.y <= -8.18)
                        {
                            side_bar.Sectionally_move(5, up_down);
                            up_down++;
                        }
                    }
                    //if (player_pos.position.y > transform.position.y && player_pos.position.x > transform.position.x - 2.08 && player_pos.position.x < transform.position.x + 2.08)
                    //{
                    //    rb.velocity = new Vector3(1.5f - transform.position.x, 20, 0);
                    //}
                    if (transform.position.x > player_pos.position.x)
                    { left_right = 4; }
                }
                if (up_down >= 5)
                {
                    foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                    {
                        spiker.GetComponent<Tower_spike_tiles>().receding = true;
                    }
                    transitioning = true;
                    foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Base_damaging"))
                    {
                        if (spiker.GetComponent<Spikes_damage>() != null)
                        {
                            spiker.GetComponent<Spikes_damage>().receding = true;
                        }
                    }
                }
            }
            if (attack_phase == 8)
            {
                Left_flamethrower_hitbox lhitbox = FindObjectOfType<Left_flamethrower_hitbox>();
                Right_flamethrower_hitbox rhitbox = FindObjectOfType<Right_flamethrower_hitbox>();
                Front_flamethrower_hitbox fhitbox = FindObjectOfType<Front_flamethrower_hitbox>();
                if (count == 0)
                {
                    Instantiate(straight_front_laser, new Vector3(99, 99, 0), Quaternion.identity);
                    Instantiate(straight_right_laser, new Vector3(99, 99, 0), Quaternion.identity);
                    Instantiate(straight_left_laser, new Vector3(99, 99, 0), Quaternion.identity);
                    lhitbox.damageable = true;
                    rhitbox.damageable = true;
                    fhitbox.damageable = true;
                }
                count++;
                if (count % 100 == 50)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.24f;
                    Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
                }
                if (count % 100 == 0 && count != 0)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (lhitbox != null && 5 - lhitbox.health > damage_taken)
                {
                    side_bar.Sectionally_move(5, damage_taken);
                    damage_taken++;
                }
                if (rhitbox != null && 5 - rhitbox.health > damage_taken)
                {
                    side_bar.Sectionally_move(5, damage_taken);
                    damage_taken++;
                }
                if (fhitbox != null && 5 - fhitbox.health > damage_taken)
                {
                    side_bar.Sectionally_move(5, damage_taken);
                    damage_taken++;
                }
                if (damage_taken == 5)
                {
                    side_bar.Sectionally_move(5, damage_taken);
                }
                if (damage_taken >= 5)
                {
                    damage_taken++;
                }
                if (damage_taken == 8)
                {
                    Downwards_laser laser = FindObjectOfType<Downwards_laser>();
                    if (laser != null)
                    {
                        Destroy(laser.gameObject);
                        laser_firing = 0;
                    }
                    left_laser laser2 = FindObjectOfType<left_laser>();
                    if (laser2 != null)
                    {
                        Destroy(laser2.gameObject);
                        laser_firing = 0;
                    }
                    right_laser laser3 = FindObjectOfType<right_laser>();
                    if (laser3 != null)
                    {
                        Destroy(laser3.gameObject);
                        laser_firing = 0;
                    }
                }
                if (damage_taken == 495)
                {
                    transform.position = new Vector3(0, -0.35f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                    transitioning = true;
                }
                else if ((damage_taken - 45) % 50 == 0)
                {
                    for (i = -7.56f; i <= 8.64f; i += 2.16f)
                    {
                        if (!(i < 2.2f && i > -2.2f && 5.4f - 2.16f * (damage_taken - 45) / 50 < -1 && 5.4f - 2.16f * (damage_taken - 45) / 50 > -5.5))
                        {
                            Object_spawn("Red_spike_tile", new Vector3(i, 5.4f - 2.16f * (damage_taken - 45) / 50, 0), Quaternion.identity);
                        }
                    }
                    for (i = -8.64f; i <= 8.64f; i += 2.16f)
                    {
                        if (!(i < 2.2f && i > -2.2f && 5.4f - 2.16f * (damage_taken - 45) / 50 < -1 && 5.4f - 2.16f * (damage_taken - 45) / 50 > -5.5))
                        {
                            Object_spawn("Grey_spike_tile", new Vector3(i, 5.4f - 2.16f * (damage_taken - 45) / 50, 0), Quaternion.identity);
                        }
                    }
                }
                else if ((damage_taken - 45) % 50 == 25 && damage_taken > 45)
                {
                    for (i = -8.64f; i <= 8.64f; i += 2.16f)
                    {
                        if (!(i < 2.2f && i > -2.2f && 5.4f - 2.16f * (damage_taken - 70) / 50 < -1 && 5.4f - 2.16f * (damage_taken - 70) / 50 > -4.5))
                        {
                            Object_spawn("Red_spike_tile", new Vector3(i, 4.32f - 2.16f * (damage_taken - 70) / 50, 0), Quaternion.identity);
                        }
                    }
                    for (i = -7.56f; i <= 8.64f; i += 2.16f)
                    {
                        if (!(i < 2.2f && i > -2.2f && 5.4f - 2.16f * (damage_taken - 70) / 50 < -1 && 5.4f - 2.16f * (damage_taken - 70) / 50 > -4.5))
                        {
                            Object_spawn("Grey_spike_tile", new Vector3(i, 4.32f - 2.16f * (damage_taken - 70) / 50, 0), Quaternion.identity);
                        }
                    }
                }
            }
            if (attack_phase == 9)
            {
                if (count % 100 == 50)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.24f;
                    Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
                }
                if (count % 100 == 0 && count != 0)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (count % 30 == 0 && count <= 240)
                {
                    Spike_row("TempSpikes",new Vector3(8.64f, 5.4f - count / 30 * 2.16f, 0), true);
                }
                if (count % 30 == 15 && count <= 225)
                {
                    Spike_row("TempSpikes",new Vector3(7.56f, 4.32f - (count - 15) / 30 * 2.16f, 0), true);
                }
                count++;
                side_bar.Sectionally_move(3240, count);
                if (count == 340)
                {
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                    transform.position = new Vector3(0, -0.35f, 0);
                    attack_phase++;
                    count = 0;
                }
                if (count == 190)
                {
                    Spike_row("Spike_warning", new Vector3(8.64f, 5.4f, 0), true);
                    Spike_row("Spike_warning", new Vector3(7.56f, -11.88f, 0), true);
                }
            }
            if (attack_phase == 10)
            {
                if (count % 100 == 50)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.24f;
                    Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
                }
                if (count % 100 == 0 && count != 0)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (count % 50 == 0 && count <= 400)
                {
                    Spike_row("TempSpikes", new Vector3(8.64f, 5.4f - count / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes",new Vector3(7.56f, -11.88f + count / 50 * 2.16f, 0), true);
                }
                if (count % 50 == 25 && count <= 400)
                {
                    Spike_row("TempSpikes", new Vector3(7.56f, 4.32f - (count - 25) / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes",new Vector3(8.64f, -10.8f + (count - 25) / 50 * 2.16f, 0), true);
                }
                count++;
                side_bar.Sectionally_move(3340, count + 340);
                if (count == 500)
                {
                    transform.position = new Vector3(0, -0.35f, 0);
                    attack_phase++;
                    count = 0;
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (count == 350)
                {
                    Spike_row("Spike_warning", new Vector3(8.64f, 5.4f, 0), true);
                    Spike_row("Spike_warning", new Vector3(-8.64f, 4.32f, 0), false);
                }
            }
            if (attack_phase == 11)
            {
                if (count % 100 == 50)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.24f;
                    Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
                }
                if (count % 100 == 0 && count != 0)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (count % 50 == 0 && count <= 400)
                {
                    Spike_row("TempSpikes",new Vector3(8.64f, 5.4f - count / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes",new Vector3(-8.64f + count / 50 * 2.16f, 4.32f, 0), false);
                }
                if (count % 50 == 25 && count <= 400)
                {
                    Spike_row("TempSpikes",new Vector3(7.56f, 4.32f - (count - 25) / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes",new Vector3(-7.56f + (count - 25) / 50 * 2.16f, 5.4f, 0), false);
                }
                count++;
                side_bar.Sectionally_move(3340, count + 840);
                if (count == 350)
                {
                    Spike_row("Spike_warning", new Vector3(8.64f, -11.88f, 0), true);
                    Spike_row("Spike_warning", new Vector3(8.64f, 4.32f, 0), false);
                }
                if (count == 500)
                {
                    transform.position = new Vector3(0, -0.35f, 0);
                    attack_phase++;
                    count = 0;
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
            }
            if (attack_phase == 12)
            {
                if (count % 100 == 50)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.24f;
                    Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
                }
                if (count % 100 == 0 && count != 0)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (count % 50 == 0 && count <= 400)
                {
                    Spike_row("TempSpikes",new Vector3(8.64f, -11.88f + count / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes", new Vector3(8.64f - count / 50 * 2.16f, 4.32f, 0), false);
                }
                if (count % 50 == 25 && count <= 400)
                {
                    Spike_row("TempSpikes", new Vector3(7.56f, -10.8f + (count - 25) / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes", new Vector3(7.56f - (count - 25) / 50 * 2.16f, 5.4f, 0), false);
                }
                count++;
                side_bar.Sectionally_move(3340, count + 1340);
                if (count == 350)
                {
                    Spike_row("Spike_warning", new Vector3(8.64f, -11.88f, 0), true);
                    Spike_row("Spike_warning", new Vector3(-8.64f, 4.32f, 0), false);
                }
                if (count == 500)
                {
                    transform.position = new Vector3(0, -0.35f, 0);
                    attack_phase++;
                    count = 0;
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
            }
            if (attack_phase == 13)
            {
                if (count % 100 == 50)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.24f;
                    Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
                }
                if (count % 100 == 0 && count != 0)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (count % 50 == 0 && count <= 400)
                {
                    Spike_row("TempSpikes", new Vector3(8.64f, -11.88f + count / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes", new Vector3(-8.64f + count / 50 * 2.16f, 4.32f, 0), false);
                }
                if (count % 50 == 25 && count <= 400)
                {
                    Spike_row("TempSpikes", new Vector3(7.56f, -10.8f + (count - 25) / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes", new Vector3(-7.56f + (count - 25) / 50 * 2.16f, 5.4f, 0), false);
                }
                count++;
                side_bar.Sectionally_move(3340, count + 1840);
                if (count == 350)
                {
                    Spike_row("Spike_warning", new Vector3(8.64f, 5.4f, 0), true);
                    Spike_row("Spike_warning", new Vector3(8.64f, 4.32f, 0), false);
                }
                if (count == 500)
                {
                    transform.position = new Vector3(0, -0.35f, 0);
                    attack_phase++;
                    count = 0;
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
            }
            if (attack_phase == 14)
            {
                if (count % 100 == 50)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.24f;
                    Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
                }
                if (count % 100 == 0 && count != 0)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (count % 50 == 0 && count <= 400)
                {
                    Spike_row("TempSpikes", new Vector3(8.64f, 5.4f - count / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes", new Vector3(8.64f - count / 50 * 2.16f, 4.32f, 0), false);
                }
                if (count % 50 == 25 && count <= 400)
                {
                    Spike_row("TempSpikes", new Vector3(7.56f, 4.32f - (count - 25) / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes", new Vector3(7.56f - (count - 25) / 50 * 2.16f, 5.4f, 0), false);
                }
                count++;
                side_bar.Sectionally_move(3340, count + 2340);
                if (count == 350)
                {
                    Spike_row("Spike_warning", new Vector3(8.64f, 5.4f, 0), true);
                    Spike_row("Spike_warning", new Vector3(8.64f, 4.32f, 0), false);
                    Spike_row("Spike_warning", new Vector3(8.64f, -11.88f, 0), true);
                    Spike_row("Spike_warning", new Vector3(-8.64f, 4.32f, 0), false);
                }
                if (count == 500)
                {
                    transform.position = new Vector3(0, -0.35f, 0);
                    attack_phase++;
                    count = 0;
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
            }
            if (attack_phase == 15)
            {
                if (count % 100 == 50)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.24f;
                    Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
                }
                if (count % 100 == 0 && count != 0)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (count % 50 == 0 && count <= 400)
                {
                    Spike_row("TempSpikes", new Vector3(8.64f, 5.4f - count / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes", new Vector3(8.64f - count / 50 * 2.16f, 4.32f, 0), false);
                    Spike_row("TempSpikes", new Vector3(8.64f, -11.88f + count / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes", new Vector3(-8.64f + count / 50 * 2.16f, 4.32f, 0), false);
                }
                if (count % 50 == 25 && count <= 400)
                {
                    Spike_row("TempSpikes", new Vector3(7.56f, 4.32f - (count - 25) / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes", new Vector3(7.56f - (count - 25) / 50 * 2.16f, 5.4f, 0), false);
                    Spike_row("TempSpikes", new Vector3(7.56f, -10.8f + (count - 25) / 50 * 2.16f, 0), true);
                    Spike_row("TempSpikes", new Vector3(-7.56f + (count - 25) / 50 * 2.16f, 5.4f, 0), false);
                }
                count++;
                side_bar.Sectionally_move(3340, count + 2840);
                if (count + 2840 == 3340)
                {
                    transform.position = new Vector3(0, -0.35f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                    transitioning = true;
                }
            }
            if (attack_phase == 16)
            {
                Left_flamethrower_hitbox lhitbox = FindObjectOfType<Left_flamethrower_hitbox>();
                Right_flamethrower_hitbox rhitbox = FindObjectOfType<Right_flamethrower_hitbox>();
                Front_flamethrower_hitbox fhitbox = FindObjectOfType<Front_flamethrower_hitbox>();
                if (count == 0)
                {
                    foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                    {
                        if (!(spiker.transform.position.x < 3.28f && spiker.transform.position.x > -3.28f && spiker.transform.position.y < 0.2 && spiker.transform.position.y > -7.54f))
                        {
                            spiker.GetComponent<Tower_spike_tiles>().receding = true;
                        }
                    }
                    if (lhitbox != null)
                    {
                        lhitbox.damageable = true;
                    }
                    if (rhitbox != null)
                    {
                        rhitbox.damageable = true;
                    }
                    if (fhitbox != null)
                    {
                        fhitbox.damageable = true;
                    }
                }
                if (lhitbox != null && 5 - lhitbox.health > damage_taken)
                {
                    side_bar.Sectionally_move(5, damage_taken);
                    damage_taken++;
                }
                if (rhitbox != null && 5 - rhitbox.health > damage_taken)
                {
                    side_bar.Sectionally_move(5, damage_taken);
                    damage_taken++;
                }
                if (fhitbox != null && 5 - fhitbox.health > damage_taken)
                {
                    side_bar.Sectionally_move(5, damage_taken);
                    damage_taken++;
                }
                if (count % 125 == 63)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.24f;
                    Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
                }
                if (count % 125 == 0 && count != 0)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (count % 250 == 0 && !(damage_taken >= 8))
                {
                    for (i = 0; i >= -6.48f; i -= 1.08f)
                    {
                        Object_spawn("TempSpikes", new Vector3(3.24f, i, 0), Quaternion.identity);
                        Object_spawn("TempSpikes", new Vector3(-3.24f, i, 0), Quaternion.identity);
                    }
                    for (i = -2.16f; i <= 2.16f; i += 1.08f)
                    {
                        Object_spawn("TempSpikes", new Vector3(i, -6.48f, 0), Quaternion.identity);
                        Object_spawn("TempSpikes", new Vector3(i, 0, 0), Quaternion.identity);
                    }
                }
                count++;
                if (damage_taken == 5)
                {
                    if (lhitbox != null)
                    {
                        lhitbox.damageable = false;
                    }
                    if (rhitbox != null)
                    {
                        rhitbox.damageable = false;
                    }
                    if (fhitbox != null)
                    {
                        fhitbox.damageable = false;
                    }
                }
                if (damage_taken >= 5)
                {
                    damage_taken++;
                }
                if (damage_taken == 8)
                {
                    foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                    {
                        spiker.GetComponent<Tower_spike_tiles>().receding = true;
                    }
                    foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Base_damaging"))
                    {
                        if (spiker.GetComponent<spikes_disappear>() != null)
                        {
                            spiker.GetComponent<spikes_disappear>().count = 99;
                        }
                    }
                    if (fhitbox == null)
                    {
                        for (i = -7.56f; i <= 8.64f; i += 2.16f)
                        {
                            Object_spawn("Grey_spike_tile", new Vector3(i, 5.4f, 0), Quaternion.identity);
                            Object_spawn("Red_spike_tile", new Vector3(i, 4.32f, 0), Quaternion.identity);
                            Object_spawn("Red_spike_tile", new Vector3(i, -10.8f, 0), Quaternion.identity);
                            Object_spawn("Grey_spike_tile", new Vector3(i, -11.88f, 0), Quaternion.identity);
                        }
                        for (i = -8.64f; i <= 8.64f; i += 2.16f)
                        {
                            Object_spawn("Red_spike_tile", new Vector3(i, 5.4f, 0), Quaternion.identity);
                            Object_spawn("Grey_spike_tile", new Vector3(i, 4.32f, 0), Quaternion.identity);
                            Object_spawn("Grey_spike_tile", new Vector3(i, -10.8f, 0), Quaternion.identity);
                            Object_spawn("Red_spike_tile", new Vector3(i, -11.88f, 0), Quaternion.identity);
                        }
                    }
                    else
                    {
                        for (i = -10.8f; i <= 5.4f; i += 1.08f)
                        {
                            Object_spawn("Red_spike_tile", new Vector3(8.64f, i, 0), Quaternion.identity);
                            Object_spawn("Red_spike_tile", new Vector3(-8.64f, i, 0), Quaternion.identity);
                        }
                        for (i = -11.88f; i <= 5.4f; i += 1.08f)
                        {
                            Object_spawn("Grey_spike_tile", new Vector3(8.64f, i, 0), Quaternion.identity);
                            Object_spawn("Grey_spike_tile", new Vector3(-8.64f, i, 0), Quaternion.identity);
                        }
                    }
                    damage_taken++;
                }
                if (damage_taken >= 80)
                {
                    transform.position = new Vector3(0, -0.35f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                    transitioning = true;
                }
            }
            if (attack_phase == 17)
            {
                Right_flamethrower_hitbox rbox = FindObjectOfType<Right_flamethrower_hitbox>();
                Front_flamethrower_hitbox fbox = FindObjectOfType<Front_flamethrower_hitbox>();
                Left_flamethrower_hitbox lbox = FindObjectOfType<Left_flamethrower_hitbox>();
                if (rbox == null && lbox == null)
                {
                    if (count == 0)
                    {
                        for (i = -11.88f; i <= 5.4f; i += 1.08f)
                        {
                            Object_spawn("Spikes", new Vector3(8.64f, i, 0), Quaternion.identity);
                            Object_spawn("Spikes", new Vector3(-8.64f, i, 0), Quaternion.identity);
                        }
                        count++;
                    }
                    if (transform.position.y >= 7)
                    {
                        if (player_pos.position.x < transform.position.x + 0.2f && player_pos.position.x > transform.position.x - 0.2f && transform.position.x > -6.7 && transform.position.x < 6.7)
                        {
                            transform.position = new Vector3(player_pos.position.x, transform.position.y, 0);
                            rb.velocity = new Vector3(0, 0, 0);
                            if (count % 50 == 0)
                            {
                                var firevar = Instantiate(fire, transform.position + new Vector3(0, -4.96f, 0), Quaternion.Euler(0, 0, 270));
                                Fire_throw fire_direction = firevar.GetComponent<Fire_throw>();
                                fire_direction.y_direction = -0.1f;
                            }
                            if (count == 1501)
                            {
                                transitioning = true;
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                                {
                                    spiker.GetComponent<Tower_spike_tiles>().receding = true;
                                }
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Base_damaging"))
                                {
                                    if (spiker.GetComponent<Spikes_damage>() != null)
                                    {
                                        spiker.GetComponent<Spikes_damage>().receding = true;
                                    }
                                }
                            }
                            else
                            {
                                side_bar.Sectionally_move(1500, count);
                                count++;
                            }
                        }
                        else if (player_pos.position.x < transform.position.x && transform.position.x > -6.7)
                        {
                            rb.velocity = new Vector3(-1, 0, 0);
                            wheels.wheels_turning = true;
                        }
                        else if (player_pos.position.x > transform.position.x && transform.position.x < 6.7)
                        {
                            rb.velocity = new Vector3(1, 0, 0);
                            wheels.wheels_turning = true;
                        }
                        else
                        {
                            rb.velocity = new Vector3(0, 0, 0);
                            if (count % 50 == 0)
                            {
                                var firevar = Instantiate(fire, transform.position + new Vector3(0, -4.96f, 0), Quaternion.Euler(0, 0, 270));
                                Fire_throw fire_direction = firevar.GetComponent<Fire_throw>();
                                fire_direction.y_direction = -0.1f;
                            }
                            if (count == 1501)
                            {
                                transitioning = true;
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                                {
                                    spiker.GetComponent<Tower_spike_tiles>().receding = true;
                                }
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Base_damaging"))
                                {
                                    if (spiker.GetComponent<Spikes_damage>() != null)
                                    {
                                        spiker.GetComponent<Spikes_damage>().receding = true;
                                    }
                                }
                            }
                            else
                            {
                                side_bar.Sectionally_move(1500, count);
                                count++;
                            }
                        }
                    }
                    else
                    {
                        rb.velocity = new Vector3(0, 1, 0);
                        wheels.wheels_turning = true;
                    }
                }
                if (rbox == null && fbox == null)
                {
                    if (count == 0)
                    {
                        for (i = -8.64f; i <= 8.64f; i += 1.08f)
                        {
                            Object_spawn("Spikes", new Vector3(i, 5.4f, 0), Quaternion.identity);
                            Object_spawn("Spikes", new Vector3(i, 4.32f, 0), Quaternion.identity);
                            Object_spawn("Spikes", new Vector3(i, -11.88f, 0), Quaternion.identity);
                            Object_spawn("Spikes", new Vector3(i, -10.8f, 0), Quaternion.identity);
                        }
                        count++;
                    }
                    if (transform.position.x >= 6.7)
                    {
                        if (player_pos.position.y < transform.position.y - 2.7f && player_pos.position.y > transform.position.y - 3.1f && transform.position.y > -7.2 && transform.position.y < 6.4)
                        {
                            transform.position = new Vector3(transform.position.x, player_pos.position.y + 2.9f, 0);
                            rb.velocity = new Vector3(0, 0, 0);
                            if (count % 50 == 0)
                            {
                                var firevar = Instantiate(fire, transform.position + new Vector3(-3.44f, -2.9f, 0), Quaternion.Euler(0, 0, 180));
                                Fire_throw fire_direction = firevar.GetComponent<Fire_throw>();
                                fire_direction.x_direction = -0.1f;
                            }
                            if (count == 1501)
                            {
                                transitioning = true;
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                                {
                                    spiker.GetComponent<Tower_spike_tiles>().receding = true;
                                }
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Base_damaging"))
                                {
                                    if (spiker.GetComponent<Spikes_damage>() != null)
                                    {
                                        spiker.GetComponent<Spikes_damage>().receding = true;
                                    }
                                }
                            }
                            else
                            {
                                side_bar.Sectionally_move(1500, count);
                                count++;
                            }
                        }
                        else if (player_pos.position.y < transform.position.y - 2.9f && transform.position.y > -7.2)
                        {
                            rb.velocity = new Vector3(0, -1, 0);
                        }
                        else if (player_pos.position.y > transform.position.y - 2.9f && transform.position.y < 6.4)
                        {
                            rb.velocity = new Vector3(0, 1, 0);
                        }
                        else
                        {
                            rb.velocity = new Vector3(0, 0, 0);
                            if (count % 50 == 0)
                            {
                                var firevar = Instantiate(fire, transform.position + new Vector3(-3.44f, -2.9f, 0), Quaternion.Euler(0, 0, 180));
                                Fire_throw fire_direction = firevar.GetComponent<Fire_throw>();
                                fire_direction.x_direction = -0.1f;
                            }
                            if (count == 1501)
                            {
                                transitioning = true;
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                                {
                                    spiker.GetComponent<Tower_spike_tiles>().receding = true;
                                }
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Base_damaging"))
                                {
                                    if (spiker.GetComponent<Spikes_damage>() != null)
                                    {
                                        spiker.GetComponent<Spikes_damage>().receding = true;
                                    }
                                }
                            }
                            else
                            {
                                side_bar.Sectionally_move(1500, count);
                                count++;
                            }
                        }
                    }
                    else
                    {
                        rb.velocity = new Vector3(1, 0, 0);
                        wheels.wheels_turning = true;
                    }
                }
                if (lbox == null && fbox == null)
                {
                    if (count == 0)
                    {
                        for (i = -8.64f; i <= 8.64f; i += 1.08f)
                        {
                            Object_spawn("Spikes", new Vector3(i, 5.4f, 0), Quaternion.identity);
                            Object_spawn("Spikes", new Vector3(i, 4.32f, 0), Quaternion.identity);
                            Object_spawn("Spikes", new Vector3(i, -11.88f, 0), Quaternion.identity);
                            Object_spawn("Spikes", new Vector3(i, -10.8f, 0), Quaternion.identity);
                        }
                        count++;
                    }
                    if (transform.position.x <= -6.7)
                    {
                        if (player_pos.position.y < transform.position.y - 2.7f && player_pos.position.y > transform.position.y - 3.1f && transform.position.y > -7.2 && transform.position.y < 6.4)
                        {
                            transform.position = new Vector3(transform.position.x, player_pos.position.y + 2.9f, 0);
                            rb.velocity = new Vector3(0, 0, 0);
                            if (count % 50 == 0)
                            {
                                var firevar = Instantiate(fire, transform.position + new Vector3(3.44f, -2.9f, 0), Quaternion.Euler(0, 0, 0));
                                Fire_throw fire_direction = firevar.GetComponent<Fire_throw>();
                                fire_direction.x_direction = 0.1f;
                            }
                            if (count == 1501)
                            {
                                transitioning = true;
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                                {
                                    spiker.GetComponent<Tower_spike_tiles>().receding = true;
                                }
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Base_damaging"))
                                {
                                    if (spiker.GetComponent<Spikes_damage>() != null)
                                    {
                                        spiker.GetComponent<Spikes_damage>().receding = true;
                                    }
                                }
                            }
                            else
                            {
                                side_bar.Sectionally_move(1500, count);
                                count++;
                            }
                        }
                        else if (player_pos.position.y < transform.position.y - 2.9f && transform.position.y > -7.6)
                        {
                            rb.velocity = new Vector3(0, -1, 0);
                        }
                        else if (player_pos.position.y > transform.position.y - 2.9f && transform.position.y < 6.4)
                        {
                            rb.velocity = new Vector3(0, 1, 0);
                        }
                        else
                        {
                            rb.velocity = new Vector3(0, 0, 0);
                            if (count % 50 == 0)
                            {
                                var firevar = Instantiate(fire, transform.position + new Vector3(3.44f, -2.9f, 0), Quaternion.Euler(0, 0, 0));
                                Fire_throw fire_direction = firevar.GetComponent<Fire_throw>();
                                fire_direction.x_direction = 0.1f;
                            }
                            if (count == 1501)
                            {
                                transitioning = true;
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                                {
                                    spiker.GetComponent<Tower_spike_tiles>().receding = true;
                                }
                                foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Base_damaging"))
                                {
                                    if (spiker.GetComponent<Spikes_damage>() != null)
                                    {
                                        spiker.GetComponent<Spikes_damage>().receding = true;
                                    }
                                }
                            }
                            else
                            {
                                side_bar.Sectionally_move(1500, count);
                                count++;
                            }
                        }
                    }
                    else
                    {
                        rb.velocity = new Vector3(-1, 0, 0);
                        wheels.wheels_turning = true;
                    }
                }
            }
            if (attack_phase == 18)
            {
                if (count == 0)
                {
                    Right_flamethrower_hitbox rbox = FindObjectOfType<Right_flamethrower_hitbox>();
                    Front_flamethrower_hitbox fbox = FindObjectOfType<Front_flamethrower_hitbox>();
                    Left_flamethrower_hitbox lbox = FindObjectOfType<Left_flamethrower_hitbox>();
                    crush_attack = true;
                    wheels.wheels_turning = true;
                    if (rbox == null && lbox == null)
                    {
                        Instantiate(straight_front_laser, new Vector3(99, 99, 99), Quaternion.identity);
                    }
                    if (fbox == null && lbox == null)
                    {
                        Instantiate(straight_right_laser, new Vector3(99, 99, 99), Quaternion.identity);
                    }
                    if (rbox == null && fbox == null)
                    {
                        Instantiate(straight_left_laser, new Vector3(99, 99, 99), Quaternion.identity);
                    }
                    laser_firing = 1;
                }
                if (count % 50 == 0 && count != 1200)
                {
                    x_dif = player_pos.position.x - transform.position.x;
                    y_dif = player_pos.position.y - (transform.position.y - 2.9f);
                    if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                    {
                        rb.velocity = new Vector3(x_dif / Mathf.Abs(y_dif / 2), y_dif / (Mathf.Abs(y_dif) / 2), 0.0f);
                    }
                    else
                    {
                        rb.velocity = new Vector3(x_dif / (Mathf.Abs(x_dif) / 2), y_dif / (Mathf.Abs(x_dif) / 2), 0.0f);
                    }
                }
                side_bar.Sectionally_move(1199, count);
                count++;
                if (count == 1200)
                {
                    transitioning = true;
                }
            }
            if (attack_phase == 19)
            {
                if (count % 26 == 0)
                {
                    Object_spawn("Shell", new Vector3(transform.position.x, transform.position.y + 3.501f, 0), Quaternion.identity);
                }
                if (count % 26 == 13)
                {
                    Object_spawn("Cluster_shell", new Vector3(transform.position.x, transform.position.y + 3.501f, 0), Quaternion.identity);
                }
                side_bar.Sectionally_move(1499, count);
                count++;
                if (count == 1500)
                {
                    transitioning = true;
                }
            }
            if (attack_phase == 20)
            {
                if (count == 0)
                {
                    wheels.wheels_fast_turning = true;
                    crush_attack = true;
                    animator.SetBool("Shaking", true);
                    up_down = 0;
                }
                if(count == 200)
                {
                    animator.SetBool("Shaking", false);
                    rb.velocity = new Vector3(5, 0, 0);
                    left_right = 1;
                }
                if (count == 201)
                {
                    if(up_down == 8)
                    {
                        side_bar.Sectionally_move(9, up_down);
                        up_down++;
                    }
                    else if (left_right == 0)
                    {
                        if (transform.position.y > player_pos.position.y - 1.75f && transform.position.y < player_pos.position.y + 1.75f)
                        {
                            if (transform.position.x < player_pos.position.x)
                            {
                                rb.velocity = new Vector3(10, 0, 0);
                            }
                            else
                            {
                                rb.velocity = new Vector3(-10, 0, 0);
                            }
                            side_bar.Sectionally_move(9, up_down);
                            up_down++;
                            count = 401;
                            left_right = 1;
                        }
                    }
                    else
                    {
                        if (transform.position.x > player_pos.position.x - 1.75f && transform.position.x < player_pos.position.x + 1.75f)
                        {
                            if (transform.position.y< player_pos.position.y)
                            {
                                rb.velocity = new Vector3(0,10, 0);
                            }
                            else
                            {
                                rb.velocity = new Vector3(0,-10, 0);
                            }
                            side_bar.Sectionally_move(9, up_down);
                            up_down++;
                            count = 401;
                            left_right = 0;
                        }
                    }
                }
                if(count > 201)
                {
                    count--;
                }
                else
                {
                    count++;
                }
                if (up_down == 9)
                {
                    wheels.wheels_fast_turning = false;
                    transitioning = true;
                }
            }
            if (attack_phase == 21)
            {
                if (count == 0)
                {
                    wheels.wheels_turning = true;
                    crush_attack = true;
                }
                if (count % 50 == 0 && count != 1200)
                {
                    x_dif = player_pos.position.x - transform.position.x;
                    y_dif = player_pos.position.y - (transform.position.y - 2.9f);
                    if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                    {
                        rb.velocity = new Vector3(x_dif / (Mathf.Abs(y_dif / 2)), y_dif / (Mathf.Abs(y_dif) / 2), 0.0f);
                    }
                    else
                    {
                        rb.velocity = new Vector3(x_dif / (Mathf.Abs(x_dif) / 2), y_dif / (Mathf.Abs(x_dif) / 2), 0.0f);
                    }
                }
                if (count % 26 == 0)
                {
                    Object_spawn("Shell", new Vector3(transform.position.x, transform.position.y + 3.501f, 0), Quaternion.identity);
                }
                if (count == 1199)
                {
                    for (i = -10.8f; i <= 5.4f; i += 1.08f)
                    {
                        Object_spawn("Red_spike_tile", new Vector3(8.64f, i, 0), Quaternion.identity);
                        Object_spawn("Red_spike_tile", new Vector3(-8.64f, i, 0), Quaternion.identity);
                    }
                    for (i = -11.88f; i <= 5.4f; i += 1.08f)
                    {
                        Object_spawn("Grey_spike_tile", new Vector3(8.64f, i, 0), Quaternion.identity);
                        Object_spawn("Grey_spike_tile", new Vector3(-8.64f, i, 0), Quaternion.identity);
                    }
                }
                side_bar.Sectionally_move(1199, count);
                count++;
                if (count == 1200)
                {
                    transitioning = true;
                }
            }
            if (attack_phase == 22)
            {
                if (transform.position.y >= 7)
                {
                    if (count == 50)
                    {
                        for (i = -11.88f; i <= 5.4f; i += 1.08f)
                        {
                            Object_spawn("Spikes", new Vector3(8.64f, i, 0), Quaternion.identity);
                            Object_spawn("Spikes", new Vector3(-8.64f, i, 0), Quaternion.identity);
                            left_right = 0;
                        }
                        count++;
                    }
                    rb.velocity = new Vector3(0, 0, 0);
                    if ((left_right == 1 || (player_pos.position.x < transform.position.x + 0.1f && player_pos.position.x > transform.position.x - 0.1f)) && !(transform.position.x >= 6.7|| transform.position.x <= -6.7))
                    {
                        left_right = 1;
                        wheels.wheels_turning = false;
                        rb.velocity = new Vector3(0, 0, 0);
                        if (count % 20 == 0)
                        {
                            float j = new float();
                            for (j = -2.8f; j <= 2; j += 2f)
                            {
                                for (i = -1.1f; i <= 1.1f; i += 0.44f)
                                {
                                    Object_spawn("Large_arrow", new Vector3(transform.position.x + i, transform.position.y + j, 0), Quaternion.identity);
                                }
                            }
                        }
                        transform.position = new Vector3(player_pos.position.x, transform.position.y, 0);
                        if (count == 1501)
                        {
                            foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Base_damaging"))
                            {
                                if (spiker.GetComponent<Spikes_damage>() != null)
                                {
                                    spiker.GetComponent<Spikes_damage>().receding = true;
                                }
                            }
                            foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                            {
                                spiker.GetComponent<Tower_spike_tiles>().receding = true;
                            }
                            for (i = -3.24f; i <= 4f; i += 2.16f)
                            {
                                Object_spawn("Grey_spike_tile", new Vector3(i, 0f, 0), Quaternion.identity);
                                Object_spawn("Grey_spike_tile", new Vector3(i, -6.48f, 0), Quaternion.identity);
                            }
                            for (i = -2.16f; i <= 3.24f; i += 2.16f)
                            {
                                Object_spawn("Red_spike_tile", new Vector3(i, 0, 0), Quaternion.identity);
                                Object_spawn("Red_spike_tile", new Vector3(i, -6.48f, 0), Quaternion.identity);
                            }
                            for (i = -2.16f; i >= -5.4f; i -= 2.16f)
                            {
                                Object_spawn("Grey_spike_tile", new Vector3(-3.24f, i, 0), Quaternion.identity);
                                Object_spawn("Grey_spike_tile", new Vector3(3.24f, i, 0), Quaternion.identity);
                            }
                            for (i = -1.08f; i >= -6.48f; i -= 2.16f)
                            {
                                Object_spawn("Red_spike_tile", new Vector3(-3.24f, i, 0), Quaternion.identity);
                                Object_spawn("Red_spike_tile", new Vector3(3.24f, i, 0), Quaternion.identity);
                            }
                        }
                        if (count >= 50)
                        {
                            side_bar.Sectionally_move(1499, count - 50);
                        }
                        count++;
                        if (count == 1550)
                        {
                            transitioning = true;
                        }
                    }
                    else if (player_pos.position.x < transform.position.x && transform.position.x > -6.7)
                    {
                        rb.velocity = new Vector3(-1, 0, 0);
                        wheels.wheels_turning = true;
                    }
                    else if (player_pos.position.x > transform.position.x && transform.position.x < 6.7)
                    {
                        rb.velocity = new Vector3(1, 0, 0);
                        wheels.wheels_turning = true;
                    }
                }
                else
                {
                    rb.velocity = new Vector3(0, 1, 0);
                    wheels.wheels_turning = true;
                }
            }
            if (attack_phase == 23)
            {
                Front_flamethrower_hitbox fhitbox = FindObjectOfType<Front_flamethrower_hitbox>();
                Left_flamethrower_hitbox lhitbox = FindObjectOfType<Left_flamethrower_hitbox>();
                Right_flamethrower_hitbox rhitbox = FindObjectOfType<Right_flamethrower_hitbox>();
                if (count == 0)
                {
                    if (lhitbox != null)
                    {
                        lhitbox.damageable = true;
                    }
                    if (rhitbox != null)
                    {
                        rhitbox.damageable = true;
                    }
                    if (fhitbox != null)
                    {
                        fhitbox.damageable = true;
                    }
                    Right_flamethrower_hitbox rbox = FindObjectOfType<Right_flamethrower_hitbox>();
                    Front_flamethrower_hitbox fbox = FindObjectOfType<Front_flamethrower_hitbox>();
                    Left_flamethrower_hitbox lbox = FindObjectOfType<Left_flamethrower_hitbox>();
                    crush_attack = true;
                    wheels.wheels_turning = false;
                    if (rbox == null && lbox == null)
                    {
                        Object_spawn("Front_fire", new Vector3(99, 99, 0), Quaternion.Euler(0, 0, 270));
                    }
                    if (fbox == null && lbox == null)
                    {
                        Object_spawn("Right_fire", new Vector3(99, 99, 0), Quaternion.identity);
                    }
                    if (rbox == null && fbox == null)
                    {
                        Object_spawn("Left_fire", new Vector3(99, 99, 0), Quaternion.Euler(0, 0, 180));
                    }
                }
                if (lhitbox != null && 5 - lhitbox.health > damage_taken)
                {
                    side_bar.Sectionally_move(5, damage_taken);
                    damage_taken++;
                }
                if (rhitbox != null && 5 - rhitbox.health > damage_taken)
                {
                    side_bar.Sectionally_move(5, damage_taken);
                    damage_taken++;
                }
                if (fhitbox != null && 5 - fhitbox.health > damage_taken)
                {
                    side_bar.Sectionally_move(5, damage_taken);
                    damage_taken++;
                }
                if (count % 400 == 50)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.24f;
                    Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
                }
                if (count % 400 == 100 && count != 0)
                {
                    transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                }
                if (count % 200 == 0)
                {
                    for (i = 0; i >= -6.48f; i -= 1.08f)
                    {
                        Object_spawn("TempSpikes", new Vector3(3.24f, i, 0), Quaternion.identity);
                        Object_spawn("TempSpikes", new Vector3(-3.24f, i, 0), Quaternion.identity);
                    }
                    for (i = -2.16f; i <= 2.16f; i += 1.08f)
                    {
                        Object_spawn("TempSpikes", new Vector3(i, -6.48f, 0), Quaternion.identity);
                        Object_spawn("TempSpikes", new Vector3(i, 0, 0), Quaternion.identity);
                    }
                }
                count++;
                Front_flamethrower_position fpos = FindObjectOfType<Front_flamethrower_position>();
                Right_flamethrower_position rpos = FindObjectOfType<Right_flamethrower_position>();
                Left_flamethrower_position lpos = FindObjectOfType<Left_flamethrower_position>();
                if (damage_taken >= 5)
                {
                    damage_taken++;
                }
                if (damage_taken == 8)
                {
                    foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Tower_spiker"))
                    {
                        spiker.GetComponent<Tower_spike_tiles>().receding = true;
                    }
                    foreach (GameObject spiker in GameObject.FindGameObjectsWithTag("Base_damaging"))
                    {
                        if (spiker.GetComponent<Spikes_damage>() != null)
                        {
                            spiker.GetComponent<Spikes_damage>().receding = true;
                        }
                    }
                    transform.position = new Vector3(0, -0.35f, 0);
                    Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
                    wheels_pos.difference = 0.6f;
                    transitioning = true;
                }
            }
            if (attack_phase == 24)
            {
                animator.SetBool("Shaking", true);
                if (count == 100)
                {
                    attack_phase++;
                    count = -1;
                }
                count++;
            }
            if (attack_phase == 25)
            {
                if (count == 0)
                {
                    animator.SetBool("Shaking", false);
                    crush_attack = true;
                    wheels.wheels_turning = true;
                }
                if (count % 26 == 0)
                {
                    Object_spawn("Shell", new Vector3(transform.position.x, transform.position.y + 3.501f, 0), Quaternion.identity);
                }
                if (count % 50 == 0 && count != 1200)
                {
                    x_dif = player_pos.position.x - transform.position.x;
                    y_dif = player_pos.position.y - (transform.position.y - 2.9f);
                    if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                    {
                        rb.velocity = new Vector3(x_dif / (Mathf.Abs(y_dif / 2)), y_dif / (Mathf.Abs(y_dif) / 2), 0.0f);
                    }
                    else
                    {
                        rb.velocity = new Vector3(x_dif / (Mathf.Abs(x_dif) / 2), y_dif / (Mathf.Abs(x_dif) / 2), 0.0f);
                    }
                }
                side_bar.Sectionally_move(3000, count);
                count++;
                if (count == 3001)
                {
                    transitioning = true;
                }
                Cannonfire();
            }
        }
        else if (transitioning)
        {
            if (transform.position.x != 0 && transform.position.y != -0.35)
            {
                rb.velocity = new Vector3(-transform.position.x, -0.35f - transform.position.y, 0);
            }
            Fire_shell shell1 = FindObjectOfType<Fire_shell>();
            Shell_descend shell2 = FindObjectOfType<Shell_descend>();
            Fire_cluster_shell shell3 = FindObjectOfType<Fire_cluster_shell>();

            if (transform.position.x > -0.01 && transform.position.y > -0.36 && transform.position.x < 0.01 && transform.position.y < -0.34 && shell1 == null && shell2 == null && shell3 == null)
            {
                if (attack_phase == 25)
                {
                    attack_phase = 0;
                    count = 0;
                    wheels.wheels_turning = false;
                    crush_attack = false;
                    attack_phase = 26;
                    transitioning = false;
                }
                else
                {
                    Left_flamethrower_hitbox lhitbox = FindObjectOfType<Left_flamethrower_hitbox>();
                    if (lhitbox != null)
                    {
                        lhitbox.damageable = false;
                        lhitbox.health = 5;
                    }
                    Right_flamethrower_hitbox rhitbox = FindObjectOfType<Right_flamethrower_hitbox>();
                    if (rhitbox != null)
                    {
                        rhitbox.damageable = false;
                        rhitbox.health = 5;
                    }
                    Front_flamethrower_hitbox fhitbox = FindObjectOfType<Front_flamethrower_hitbox>();
                    if (fhitbox != null)
                    {
                        fhitbox.damageable = false;
                        fhitbox.health = 5;
                    }
                    rb.velocity = new Vector3(0, 0, 0);
                    transform.position = new Vector3(0, -0.35f, 0);
                    wheels.wheels_turning = false;
                    wheels.wheels_fast_turning = false;
                    count = 0;
                    crush_attack = false;
                    attack_phase++;
                    damage_taken = 0;
                    FindObjectOfType<Boss_bar>().phase_progress = 1;
                    side_bar.Bar_reset();
                    weakness.Recede();
                    b_text.Next_paragraph();
                    if (attack_phase == 8 || attack_phase == 16 || attack_phase == 23)
                    {
                        weakness.Display_weakness();
                    }
                    if (attack_phase < 10)
                    {
                        warnings.Change(attack_phase);
                    }
                    else
                    {
                        warnings.Change(attack_phase - 6);
                    }
                    transitioning = false;
                    damage_taken = 0;
                    Left_flamethrower_fire_position left_fire = FindObjectOfType<Left_flamethrower_fire_position>();
                    if (left_fire != null)
                    {
                        left_fire.gameObject.SetActive(false);
                    }
                    Right_flamethrower_fire_position right_fire = FindObjectOfType<Right_flamethrower_fire_position>();
                    if (right_fire != null)
                    {
                        right_fire.gameObject.SetActive(false);
                    }
                    Front_flamethrower_fire_position front_fire = FindObjectOfType<Front_flamethrower_fire_position>();
                    if (front_fire != null)
                    {
                        front_fire.gameObject.SetActive(false);
                    }
                    Downwards_laser laser = FindObjectOfType<Downwards_laser>();
                    if (laser != null)
                    {
                        Destroy(laser.gameObject);
                        laser_firing = 0;
                    }
                    left_laser laser2 = FindObjectOfType<left_laser>();
                    if (laser2 != null)
                    {
                        Destroy(laser2.gameObject);
                        laser_firing = 0;
                    }
                    right_laser laser3 = FindObjectOfType<right_laser>();
                    if (laser3 != null)
                    {
                        Destroy(laser3.gameObject);
                        laser_firing = 0;
                    }
                    if (attack_phase != 25 && FindObjectOfType<Player_health>().health > 0)
                    {
                        interval = true;
                        interval_menu.New_phase();
                    }
                    if (attack_phase == 8)
                    {
                        FindObjectOfType<Checkpoint>().Display_checkpoint();
                        Checkpoint_reached(1);
                    }
                    else if (attack_phase == 18)
                    {
                        FindObjectOfType<Checkpoint>().Display_checkpoint();
                        Checkpoint_reached(2);
                    }
                }
            }
        }
        else if(interval)
        {
            if (count > 3)
            {
                if(count == 4)
                {
                    Move move = FindObjectOfType<Move>();
                    move.allow_attack = false;
                    move.allow_movement = false;
                    interval_menu.active = true;
                    interval_menu.pointer.transform.position = interval_menu.pointer_pos_start - new Vector3(0.5f, 0, 0);
                    count++;
                }
                if (!interval_menu.active )
                {
                    interval = false;
                    count = 0;
                }
            }
            else
            {
                count++;
            }
        }
        if (transform.position.x >= 6.7 && rb.velocity.x > 0 && crush_attack || transform.position.x <= -6.7 && rb.velocity.x < 0 && crush_attack)
        {
            rb.velocity = new Vector3(-rb.velocity.x, rb.velocity.y, 0);
            if (crush == 51)
            {
                crush = 0;
            }
        }
        if (transform.position.y >= 7 && rb.velocity.y > 0 && crush_attack)
        {
            rb.velocity = new Vector3(rb.velocity.x, -rb.velocity.y, 0);
            if (crush == 51)
            {
                crush = 0;
            }
        }
        if (transform.position.y <= -7.6 && rb.velocity.y < 0 && crush_attack)
        {
            rb.velocity = new Vector3(rb.velocity.x, -rb.velocity.y, 0);
            if (crush == 51)
            {
                crush = 0;
            }
        }
        if (crush == 0)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y - 0.4f, 0);
            Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
            wheels_pos.difference = 0.24f;
            Object_spawn("Crush_hitbox", new Vector3(transform.position.x, transform.position.y - 2.5f, 0), Quaternion.identity);
        }
        if (crush < 50)
        {
            crush++;
        }
        else if (crush == 50)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y + 0.4f, 0);
            Wheels_position wheels_pos = FindObjectOfType<Wheels_position>();
            wheels_pos.difference = 0.6f;
            crush = 51;
        }
        if (attack_phase == 26)
        {
            animator.SetBool("Shaking", true);
            if (count == 0 || count == 120|| count ==220)
            {
                Object_spawn("Tower_explosion", transform.position + new Vector3(0, -3.501f, 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
            }
            if (count == 20|| count == 140 || count == 240)
            {
                Object_spawn("Tower_explosion", transform.position + new Vector3(-2.08f, -2.9f, 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
            }
            if (count == 40|| count == 100 || count == 280)
            {
                Object_spawn("Tower_explosion", transform.position + new Vector3(2.08f, -2.9f, 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
            }
            if (count >= 60 && count <= 140 && count%20 == 0)
            {
                Object_spawn("Tower_explosion", transform.position + new Vector3(Random.Range(-2f, 2f), Random.Range(-3.0f, 3.0f), 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
            }
            if(count % 20 == 0 && count < 320 && count >= 160)
            {
                for (i = 0; i < 2; i++)
                {
                    Object_spawn("Tower_explosion", transform.position + new Vector3(Random.Range(-2f, 2f), Random.Range(-3.0f, 3.0f), 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
                }
                if (count == 200||count == 260||count==300)
                {
                    Object_spawn("Tower_explosion", transform.position + new Vector3(Random.Range(-2f, 2f), Random.Range(-3.0f, 3.0f), 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
                }
            }
            if ((count >= 320 && count % 20 == 0 && count <= 400) || count >= 400 && (count - 400) % 15 == 0)
            {
                for (i = 0; i < 4; i++)
                {
                    Object_spawn("Tower_explosion", transform.position + new Vector3(Random.Range(-2f, 2f), Random.Range(-3.0f, 3.0f), 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
                }
            }
            if (count == 550)
            {
                Instantiate(whitebar, transform.position, Quaternion.identity);
                Instantiate(whitebar2, transform.position, Quaternion.identity);
            }
            count++;
            if (count == 700)
            {
                Instantiate(textbox, new Vector3(0, -9.04f, 0), Quaternion.identity);
            }
            if (count == 701)
            {

                Front_flamethrower_position fpos = FindObjectOfType<Front_flamethrower_position>();
                Right_flamethrower_position rpos = FindObjectOfType<Right_flamethrower_position>();
                Left_flamethrower_position lpos = FindObjectOfType<Left_flamethrower_position>();
                Destroy(fpos);
                Destroy(rpos);
                Destroy(lpos);
                i = Random.Range(0, 360);
                Instantiate(explode_shadow,transform.position + new Vector3(0, -2.9f,0), Quaternion.Euler(0, 0, i));
                Instantiate(explode_shadow, transform.position + new Vector3(0, -2.9f, 0), Quaternion.Euler(0, 0, i + 120));
                Instantiate(explode_shadow, transform.position + new Vector3(0, -2.9f, 0), Quaternion.Euler(0, 0, i + 240));
                Destroy(gameObject);
            }
        }
    }
    private GameObject Object_spawn(string name, Vector3 position, Quaternion rotation)
    {
        GameObject attack = Pool.SharedInstance.GetPooledObject(name + "(Clone)");
        if (attack != null)
        {
            attack.transform.position = position;
            attack.transform.rotation = rotation;
            attack.SetActive(true);
            return attack;
        }
        else
        {
            return null;
        }
    }
    private GameObject Shadow_spawn(string name, Vector3 position, Quaternion rotation, float height,int direction)
    {//Why do you have to be different
        GameObject attack = Pool.SharedInstance.GetPooledObject(name + "(Clone)");
        if (attack != null)
        {
            attack.transform.position = position;
            attack.transform.rotation = rotation;
            attack.GetComponent<Cannon_shadow>().height = height;
            attack.GetComponent<Cannon_shadow>().direction = direction;
            attack.SetActive(true);
            return attack;
        }
        else
        {
            return null;
        }
    }
    private void Cannonfire()
    {
        if (count % 60 == 30 || count % 60 == 40 || count % 60 == 50)
        {
            for (i = -1.08f; i <= 1.08f; i += 0.72f)
            {
              
                Shadow_spawn("Cannonball_shadow", new Vector3(transform.position.x + i, transform.position.y - 4.2f, 0), Quaternion.identity, 1.8f + (count % 60 - 30) / 5,1);
            }
            for (i = -4.04f; i <= -3.32f; i += 0.24f)
            {
                if (count % 120 > 60)
                {
                    Shadow_spawn("Cannonball_shadow", new Vector3(transform.position.x + 1.7f, transform.position.y + i, 0), Quaternion.identity, 1.8f + (count % 60 - 30) / 5,2);
                }
                else
                {
                    Shadow_spawn("Cannonball_shadow", new Vector3(transform.position.x + 1.1f, transform.position.y + i, 0), Quaternion.identity, 1.8f + (count % 60 - 30) / 5,2);
                }
            }
            for (i = -4.04f; i <= -3.32f; i += 0.24f)
            {
              
                if (count % 120 > 60)
                {
                    Shadow_spawn("Cannonball_shadow", new Vector3(transform.position.x - 1.7f, transform.position.y + i, 0), Quaternion.identity, 1.8f + (count % 60 - 30) / 5,3);
                }
                else
                {
                    Shadow_spawn("Cannonball_shadow", new Vector3(transform.position.x - 1.1f, transform.position.y + i, 0), Quaternion.identity, 1.8f + (count % 60 - 30) / 5,3);
                }
            }
        }
    }
    private void Spike_row(string name, Vector3 start, bool horizontal)
    {
        float j = new float();
        if(horizontal)
        {
            for(j = start.x; j >= - 8.64f; j -= 2.16f)
            {
                if (!(j < 2.2f && j > -2.2f && start.y < -1 && start.y > -5.5))
                {
                    Object_spawn(name, new Vector3(j, start.y, 0), Quaternion.identity);
                }
            }
        }
        else
        {
            for (j = start.y; j >= -11.88f; j -= 2.16f)
            {
                if (!(start.x < 2.2f && start.x > -2.2f && j < -1 && j > -5.5))
                {
                    Object_spawn(name, new Vector3(start.x,j,  0), Quaternion.identity);
                }
            }
        }
    }
    private void Checkpoint_reached(int current_checkpoint)
    {
        if (FindObjectOfType<Player_health>().health != 0)
        {
            Log log = FindObjectOfType<Log>();
            log.boss_checkpoints[current_checkpoint - 1][0] = 1;
            log.boss_checkpoints[current_checkpoint - 1][1] = FindObjectOfType<Player_health>().health;
            log.boss_checkpoints[current_checkpoint - 1][2] = interval_menu.swords.Count;
            log.boss_checkpoints[current_checkpoint - 1][3] = interval_menu.hearts.Count;
            log.boss_checkpoints[current_checkpoint - 1][4] = interval_menu.caps.Count;
            Save_system.Save(log, FindObjectOfType<Keybinds>(), false);
        }
    }
}
