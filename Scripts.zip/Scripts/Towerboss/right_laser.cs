﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class right_laser : MonoBehaviour {
	void Start () {
        transform.Rotate(0, 0, 90);
	}
	void Update () {
        Transform fthrower = FindObjectOfType<Right_flamethrower_position>().transform;
        transform.position = fthrower.position + new Vector3(28.95f,0, 0);
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
        }
    }
}
