﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tower_spike_tiles : MonoBehaviour
{
    public Animator animator;
    public int count;
    public bool receding;
    public GameObject shadow;
    private void OnEnable()
    {
        count = 0;
        receding = false;
    }
    void FixedUpdate()
    {
        if(count < 50)
        {
            count++;
            GetComponent<SpriteRenderer>().sortingOrder = Mathf.RoundToInt(-transform.position.y * 100 + 1000);
        }
        if(count == 49)
        {
            animator.enabled = false;
            shadow.SetActive(false);
        }
        if (receding)
        {
            if (count == 60)
            {
                GetComponent<SpriteRenderer>().sortingOrder = Mathf.RoundToInt(-transform.position.y * 100 + 1000);
                animator.enabled = true;
                animator.SetBool("Recede", true);
                shadow.SetActive(true);
            }
            if (count == 110)
            {
                gameObject.SetActive(false);
            }
            count++;
        }
    }
}
