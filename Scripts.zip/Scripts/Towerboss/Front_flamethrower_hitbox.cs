﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Front_flamethrower_hitbox : MonoBehaviour {
    public Transform flamethrowerpos;
    public int health = 5;
    public bool damageable = false;
    private int count;
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player_attack") && damageable)
        {
            health -= 1;
        }
    }
    void Update()
    {
        transform.position = flamethrowerpos.position;
        if (health <= 0)
        {
            if (count == 2)
            {
                GameObject flamethrower = GameObject.Find("Flamethrower_front");
                Front_flamethrower_position flamethrower_destroyed = flamethrower.GetComponent<Front_flamethrower_position>();
                flamethrower_destroyed.destroyed = true;
                FindObjectOfType<Log>().boss_checkpoints[1][6] = 1;
                Destroy(gameObject);
            }
            count++;
        }
    }
}
