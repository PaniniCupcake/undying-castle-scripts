﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Downwards_laser : MonoBehaviour {
    public Transform fthrower;
	void Update () {
        fthrower = FindObjectOfType<Front_flamethrower_position>().transform;
        transform.position = fthrower.position + new Vector3(0, -29.05f, 0);
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
        }
    }
}
