﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Fire_throw : MonoBehaviour {
    public float y_direction = 0;
    public float x_direction  = 0;
    public void FixedUpdate()
    {
        transform.position += new Vector3(x_direction, y_direction, 0);
        if(transform.position.x > 10 || transform.position.x < -10 || transform.position.y < -15)
        {
            gameObject.SetActive(false);
        }
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
        }
    }
}
