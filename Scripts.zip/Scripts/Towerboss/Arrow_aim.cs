﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrow_aim : MonoBehaviour {
    public Transform target;
    public Rigidbody2D rb;
    private float x_dif;
    private float y_dif;
    public int direction = 1;
	void OnEnable () {
        target = FindObjectOfType<Move>().transform;
        direction = 1;
        if(direction == 1)
        {
            if(transform.position.y > target.position.y)
            {
                x_dif = target.position.x - transform.position.x;
                y_dif = target.position.y - transform.position.y;
                if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                {
                    rb.velocity = new Vector3(x_dif / Mathf.Abs(y_dif / 4), y_dif / (Mathf.Abs(y_dif) / 4), 0.0f);
                    if(transform.position.x > target.position.x)
                    {
                        transform.Rotate(0,0,360-Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
                    }
                    if (transform.position.x < target.position.x)
                    {
                        transform.Rotate(0,0,Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
                    }
                }
                else
                {
                    rb.velocity = new Vector3(x_dif / (Mathf.Abs(x_dif) / 4), y_dif / (Mathf.Abs(x_dif) / 4), 0.0f);
                    if (transform.position.x > target.position.x)
                    {
                        transform.Rotate(0,0, 360-Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
                    }
                    if (transform.position.x < target.position.x)
                    {
                        transform.Rotate(0,0,Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
                    }
                }
            }
        }
    }
	void FixedUpdate () {
        if (Mathf.Abs(transform.position.x) > 12 || Mathf.Abs(transform.position.y) > 14)
            gameObject.SetActive(false);
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
            gameObject.SetActive(false);
        }
    }
}
