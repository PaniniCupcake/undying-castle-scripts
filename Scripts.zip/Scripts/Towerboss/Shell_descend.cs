﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shell_descend : MonoBehaviour {
    private int count;
    public GameObject Explosion;
    public GameObject Explosion2;
    public Transform target;
    public GameObject shadow;
    public float y_dif = 0;
    public float x_dif = 0;
    private void OnEnable()
    {
        target = FindObjectOfType<Player_follow>().transform;
        transform.position = target.position + new Vector3(x_dif, 25 - 0.4f + y_dif, 0);
        Object_spawn("Shell_shadow", target.position + new Vector3(x_dif, -0.4f + y_dif, 0), Quaternion.identity);
        transform.Rotate(180, 0, 0);
        count = 0;
    }
    void FixedUpdate () {
        if (count < 63)
        {
            transform.position -= new Vector3(0, 0.4f, 0);
            if (target.position.y > transform.position.y && count < 371)
            {
                GetComponent<SpriteRenderer>().sortingOrder = 7;
            }
            else if (target.position.y < transform.position.y && count > 371)
            {
                GetComponent<SpriteRenderer>().sortingOrder = 5;
            }
        }
        else
        {
            Object_spawn("Explosion_low", new Vector3(transform.position.x + 0.02f, transform.position.y + 0.5f, 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
            gameObject.SetActive(false);
        }
        count++;
	}
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox") && (count==62))
        {
            Object_spawn("Explosion_high", new Vector3(transform.position.x + 0.02f, transform.position.y + 0.5f, 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));
            gameObject.SetActive(false);
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
        }
    }
    private GameObject Object_spawn(string name, Vector3 position, Quaternion rotation)
    {
        GameObject attack = Pool.SharedInstance.GetPooledObject(name + "(Clone)");
        if (attack != null)
        {
            attack.transform.position = position;
            attack.transform.rotation = rotation;
            attack.SetActive(true);
            return attack;
        }
        else
        {
            return null;
        }
    }
}
