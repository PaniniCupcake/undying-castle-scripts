﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Wheels_position : MonoBehaviour {
    public Transform tower_position;
    public float difference = 0.6f;
    private Vector3 position;

    void Update()
    {
        position = tower_position.position + new Vector3(0, -3.42f - difference, 0);
        transform.position = position;
        
    }
}
