﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lower_stirrer : MonoBehaviour
{
    //Why did I have to program this twice
    public Transform stirrer;
    private Quaternion rot_storage;
    private Vector3 pos_storage;
    private Vector3 initial_pos = new Vector3(178.34f, -5.73f, 0);
    void Update()
    {
        pos_storage = stirrer.position;
        rot_storage = stirrer.rotation;
        stirrer.rotation = Quaternion.Euler(0, 0, 0);
        stirrer.position = initial_pos;
        transform.RotateAround(stirrer.position, new Vector3(1, 0, 0), 1);
        stirrer.rotation = rot_storage;
        stirrer.position = pos_storage;
    }
}
