﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Animation_stagger : MonoBehaviour
{
    public Animator anim;
    private int count;
    public int stagger;
    void FixedUpdate()
    {
        if(count == stagger)
        {
            anim.enabled = true;
            Destroy(this);
        }
        count++;
    }
}
