﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spikes_damage : MonoBehaviour {
    public Animator animator;
    public bool spiking;
    private int count;
    public bool receding = false;
	void Update () {
		if(spiking)
        {//Plays the animation and allows the spikes to deal damage when they are instructed to
            gameObject.tag = "Base_damaging";
        }
        Tower_attack_pattern tower = FindObjectOfType<Tower_attack_pattern>();
        if (receding)
        {
            gameObject.tag = "Spikes";
            animator.SetBool("Recede", true);
            if (count == 10)
            {
                count = 0;
                receding = false;
                gameObject.SetActive(false);
            }//Destroys all spikes when the boss starts a new phase
            count++;
        }
	}
}
