﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lower_stir : MonoBehaviour
{
    //Why did I have to program this twice
    private float rot_storage = 0;
    void Update()
    {
        Rotate_around rot = gameObject.GetComponent<Rotate_around>();
        rot_storage = transform.rotation.z;
        rot_storage %= 180;
        rot.axis.x = Mathf.Abs(rot_storage - 90) / 90;
        rot.axis.y = 1 - rot.axis.x;
    }
}
