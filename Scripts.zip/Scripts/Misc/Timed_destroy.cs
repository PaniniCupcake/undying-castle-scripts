﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Timed_destroy : MonoBehaviour
{
    public int end_time;
    private int count;
    void FixedUpdate()
    {
        if(count == end_time)
        {
            Destroy(gameObject);
        }
        count++;
    }
}
