﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Player_chess_move : MonoBehaviour {
    public int grid_width;
    public int grid_length;
    public List<string> buttons = new List<string>();
    public List<int> my_grid_pos = new List<int>(); //first number horizontal, second verical
    private int i;
    private int j;
    private int count;
    private int mycount;
    public bool player_turn;
    public int piece_turn;
    private bool moving;
    public int blip;
    private int move_direction;//1 is up, 2 is up-right etc 0 is none
    public Animator animator;
    public string puzzle_level;
    private bool lose;
    private float opacity = 100;
    public int puzzle_index;
    public float middle;
    private bool win;
    public float pos_dif;
    public float size_dif;
    public bool first_attempt = true;
    public List<int> finish_pos = new List<int>();
    public List<List<List<int>>> grid = new List<List<List<int>>>(); //first width, second length, third dimension of list has 3 digits, first for tile type, second for piece on tile, third for if in range.
    //0 for passable, 1 for not 
    //0 for empty, 1 for player, 2 for white, 3 for black
    //0 for out of range, 1 for in range, 2 for in range of player
    void Start()
    {
        buttons = FindObjectOfType<Keybinds>().buttons;
        first_attempt = FindObjectOfType<Log>().first_attempt;
        pos_dif = GameObject.Find("Puzzle_background").transform.position.y - FindObjectOfType<Camera>().transform.position.y + 0.02f;
        size_dif = GameObject.Find("Puzzle_background").transform.localScale.y - 0.0175f;
        
        for (i = 0; i < grid_width; i++)
        {
            List<List<int>> list1 = new List<List<int>>();
            for (j = 0; j < grid_length; j++)
            {
                List<int> list2 = new List<int>();
                for (count = 0; count < 3; count++)
                {
                    list2.Add(0);
                }
                list1.Add(list2);
            }
            grid.Add(list1);
        }
        if (first_attempt)
        {
            GameObject.Find("Puzzle_background").transform.localScale = new Vector3(0.0175f, 0.0175f, 0);
            GameObject.Find("Puzzle_background").transform.position = new Vector3(transform.position.x, FindObjectOfType<Camera>().transform.position.y + 0.02f, 0);
        }
        count = 0;
        player_turn = true;
        animator.SetFloat("Direction", 4f);
    }
    void Update () {
        if (first_attempt)
        {
            if(count < 100)
            {
                count++;
                GameObject.Find("Puzzle_background").transform.position += new Vector3(0, 0.01f, 0) * pos_dif;
                GameObject.Find("Puzzle_background").transform.localScale += new Vector3(0.01f, 0.01f, 0) * size_dif;
            }
            else
            {
                SceneManager.LoadScene(puzzle_level);
                count = 0;
                first_attempt = false;
                FindObjectOfType<Log>().first_attempt = false;
            }
        }
        else
        {
            if (Input.GetKey(buttons[8]))
            {
                blip = 0;
                lose = true;
            }
            for (i = 0; i < grid_width; i++)
            {
                for (j = 0; j < grid_length; j++)
                {
                    grid[i][j][1] = 0;
                }
            }
            if (opacity > 0 && !lose && !win)
            {
                opacity--;
            }
            GameObject white = GameObject.Find("White_piece");
            GameObject black = GameObject.Find("Black_piece");
            Chess_move_2 black_move = black.GetComponent<Chess_move_2>();
            Chess_move_2 white_move = white.GetComponent<Chess_move_2>();
            if (((black_move.my_grid_pos[0] == my_grid_pos[0] && black_move.my_grid_pos[1] == my_grid_pos[1]) || (white_move.my_grid_pos[0] == my_grid_pos[0] && white_move.my_grid_pos[1] == my_grid_pos[1])) && !lose)
            {
                blip = 0;
                player_turn = false;
                lose = true;
            }
            if (lose)
            {
                opacity += 2; //I reused the opacity variable from the win statement so I didn't need to add another
                if (opacity == 100) 
                { //
                    GameObject.Find("Obscurer").GetComponent<SpriteRenderer>().sortingLayerName = "Text";
                }
                if (blip < 100 && blip >= 55)
                {
                    GameObject.Find("Yellow_right_page").transform.RotateAround(new Vector3(middle, 0, 0), new Vector3(0, 1, 0), 4f);
                }
                if (blip == 100)
                {
                    SceneManager.LoadScene(puzzle_level);
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                }
                blip++;
            }
            if(win)
            {
                
                if (GameObject.Find("Puzzle_background").transform.localScale.y > 0)
                {
                    GameObject.Find("Puzzle_background").transform.position += new Vector3(0, -0.01f, 0) * pos_dif;
                    GameObject.Find("Puzzle_background").transform.localScale += new Vector3(-0.01f, -0.01f, 0) * size_dif;
                }
                else
                {
                    FindObjectOfType<Background_darkness>().GetComponent<SpriteRenderer>().sortingLayerName = "Death layer";
                }
                if (blip == 150)
                {
                    SceneManager.LoadScene("Temple");
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                }
                blip++;
            }
            grid[black_move.my_grid_pos[0]][black_move.my_grid_pos[1]][1] = 1;
            grid[white_move.my_grid_pos[0]][white_move.my_grid_pos[1]][1] = 1;
            GameObject.FindGameObjectWithTag("Paper").GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f, opacity * 0.01f);
            if (player_turn && !lose)
            {
                if (Input.GetKeyDown(buttons[9])) //Sees if the select key is down
                {
                    if (Input.GetKey(buttons[0]) && Input.GetKey(buttons[2])) //Sees if this combination of buttons is down
                    {
                        if (my_grid_pos[0] - 1 >= 0 && my_grid_pos[1] - 1 >= 0 && grid[my_grid_pos[0] - 1][my_grid_pos[1] - 1][0] != 1 && grid[my_grid_pos[0] - 1][my_grid_pos[1] - 1][1] != 1)
                        {
                            move_direction = 8;
                            my_grid_pos[0] -= 1;
                            my_grid_pos[1] -= 1;
                            animator.SetFloat("Direction", 1f);
                            moving = true;
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[0]) && Input.GetKey(buttons[3]))
                    {
                        if (my_grid_pos[0] + 1 < grid_width && my_grid_pos[1] - 1 >= 0 && grid[my_grid_pos[0] + 1][my_grid_pos[1] - 1][0] != 1 && grid[my_grid_pos[0] + 1][my_grid_pos[1] - 1][1] != 1)
                        {
                            move_direction = 2;
                            my_grid_pos[0] += 1;
                            my_grid_pos[1] -= 1;
                            animator.SetFloat("Direction", 1f);
                            moving = true;
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[1]) && Input.GetKey(buttons[2]))
                    {
                        if (my_grid_pos[0] - 1 >= 0 && my_grid_pos[1] + 1 < grid_length && grid[my_grid_pos[0] - 1][my_grid_pos[1] + 1][0] != 1 && grid[my_grid_pos[0] - 1][my_grid_pos[1] + 1][1] != 1)
                        {
                            move_direction = 6;
                            my_grid_pos[0] -= 1;
                            my_grid_pos[1] += 1;
                            animator.SetFloat("Direction", 2f);
                            moving = true;
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[1]) && Input.GetKey(buttons[3]))
                    {
                        if (my_grid_pos[0] + 1 < grid_width && my_grid_pos[1] + 1 < grid_length && grid[my_grid_pos[0] + 1][my_grid_pos[1] + 1][0] != 1 && grid[my_grid_pos[0] + 1][my_grid_pos[1] + 1][1] != 1)
                        {
                            move_direction = 4;
                            my_grid_pos[0] += 1;
                            my_grid_pos[1] += 1;
                            moving = true;
                            animator.SetFloat("Direction", 2f);
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[3]))
                    {
                        if (my_grid_pos[0] + 1 < grid_width && grid[my_grid_pos[0] + 1][my_grid_pos[1]][0] != 1 && grid[my_grid_pos[0] + 1][my_grid_pos[1]][1] != 1)
                        {
                            move_direction = 3;
                            my_grid_pos[0] += 1;
                            moving = true;
                            animator.SetFloat("Direction", 4f);
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[0]))
                    {
                        if (my_grid_pos[1] - 1 >= 0 && grid[my_grid_pos[0]][my_grid_pos[1] - 1][0] != 1 && grid[my_grid_pos[0]][my_grid_pos[1] - 1][1] != 1)
                        {
                            move_direction = 1;
                            my_grid_pos[1] -= 1;
                            moving = true;
                            animator.SetFloat("Direction", 1f);
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[1]))
                    {
                        if (my_grid_pos[1] + 1 < grid_length && grid[my_grid_pos[0]][my_grid_pos[1] + 1][0] != 1 && grid[my_grid_pos[0]][my_grid_pos[1] + 1][1] != 1)
                        {
                            move_direction = 5;
                            my_grid_pos[1] += 1;
                            moving = true;
                            animator.SetFloat("Direction", 2f);
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[2]))
                    {
                        if (my_grid_pos[0] - 1 >= 0 && grid[my_grid_pos[0] - 1][my_grid_pos[1]][0] != 1 && grid[my_grid_pos[0] - 1][my_grid_pos[1]][1] != 1)
                        {
                            move_direction = 7;
                            my_grid_pos[0] -= 1;
                            moving = true;
                            animator.SetFloat("Direction", 3f);
                            player_turn = false;
                        }
                    }
                    else
                    {
                        move_direction = 0;
                        moving = true;
                        player_turn = false;
                    }
                    mycount = 0;
                }
            }
            if (moving)
            {
                if (mycount < 28)
                {
                    if (move_direction != 0)
                    {
                        animator.SetFloat("Magnitude", 1f);
                    }
                    if (move_direction == 1)
                    {
                        transform.position += new Vector3(0, 0.02f, 0);
                    }
                    if (move_direction == 2)
                    {
                        transform.position += new Vector3(0.02f, 0.02f, 0);
                    }
                    if (move_direction == 3)
                    {
                        transform.position += new Vector3(0.02f, 0, 0);
                    }
                    if (move_direction == 4)
                    {
                        transform.position += new Vector3(0.02f, -0.02f, 0);
                    }
                    if (move_direction == 5)
                    {
                        transform.position += new Vector3(0, -0.02f, 0);
                    }
                    if (move_direction == 6)
                    {
                        transform.position += new Vector3(-0.02f, -0.02f, 0);
                    }
                    if (move_direction == 7)
                    {
                        transform.position += new Vector3(-0.02f, 0, 0);
                    }
                    if (move_direction == 8)
                    {
                        transform.position += new Vector3(-0.02f, 0.02f, 0);
                    }
                }
                else
                {
                    if (my_grid_pos[0] == finish_pos[0] && my_grid_pos[1] == finish_pos[1])
                    {
                        FindObjectOfType<Log>().puzzles_completed[2][puzzle_index] = true;
                        win = true;
                        blip = 0;
                    }
                    if (piece_turn == 0 && !win)
                    {
                        piece_turn = 1;
                        white_move.turn_setup = true;
                    }
                    else if (piece_turn == 1 && !win)
                    {
                        piece_turn = 0;
                        black_move.turn_setup = true;
                    }
                    animator.SetFloat("Magnitude", 0);
                    moving = false;
                }
                mycount++;
            }
        }
    }
}
