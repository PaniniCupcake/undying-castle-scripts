﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stalactite_falling : MonoBehaviour
{
    private int count;
    void FixedUpdate()
    {
        if(count == 32)
        {
            Destroy(gameObject);
        }
        count++;
        transform.position -= new Vector3(0,0.2f,0);
    }
}
