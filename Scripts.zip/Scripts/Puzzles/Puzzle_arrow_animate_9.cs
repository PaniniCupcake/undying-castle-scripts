﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Puzzle_arrow_animate_9 : MonoBehaviour
{
    public Animator animator;
    public List<string> buttons = new List<string>();
    private void Start()
    {
        buttons = FindObjectOfType<Keybinds>().buttons;
    }
    void Update()
    {
        if (Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1]))
        {
            animator.SetFloat("Vertical", 1);
        }
        else if (!Input.GetKey(buttons[0]) && Input.GetKey(buttons[1]))
        {
            animator.SetFloat("Vertical", -1);
        }
        else
        {
            animator.SetFloat("Vertical", 0);
        }
        if (Input.GetKey(buttons[2]) && !Input.GetKey(buttons[3]))
        {
            animator.SetFloat("Horizontal", -1);
        }
        else if (!Input.GetKey(buttons[2]) && Input.GetKey(buttons[3]))
        {
            animator.SetFloat("Horizontal", 1);
        }
        else
        {
            animator.SetFloat("Horizontal", 0);
        }
    }
}
