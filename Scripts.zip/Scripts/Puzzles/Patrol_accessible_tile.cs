﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Patrol_accessible_tile : MonoBehaviour
{
    private int count;
    public int xpos;
    public int ypos;
    void Update()
    {
        if(count == 2)
        {
            Player_patrol_move player_script = FindObjectOfType<Player_patrol_move>();
            player_script.grid[xpos][ypos] = 1;
            Destroy(this);
        }
        count++;
    }
}
