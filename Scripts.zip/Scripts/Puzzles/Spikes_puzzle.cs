﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spikes_puzzle : MonoBehaviour
{
    public int tier;
    public int x_pos;
    public int y_pos;
    private int count;
    public Animator animator;
    void FixedUpdate()
    {
        Player_spikes_move player_script = FindObjectOfType<Player_spikes_move>();
        if(count == 2 && tier != 3)
        {
            player_script.grid[x_pos][y_pos] = true;
        }
        if(count <= 2)
        {
            count++;
        }
        if(player_script.spikes_turn == 4)
        {   
            if(!(tier == 2 && player_script.my_grid_pos[0] == x_pos && player_script.my_grid_pos[1] == y_pos))
            {
                tier++;
                if(tier > 3)
                {
                    tier = 1;
                }
            }
            if(tier == 1)
            {
                player_script.grid[x_pos][y_pos] = true;
                animator.SetInteger("Tier", 1);
            }
            if(tier == 2)
            {
                player_script.grid[x_pos][y_pos] = true;
                animator.SetInteger("Tier", 2);
            }
            if(tier == 3)
            {
                player_script.grid[x_pos][y_pos] = false;
                animator.SetInteger("Tier", 3);
            }
        }
    }
}
