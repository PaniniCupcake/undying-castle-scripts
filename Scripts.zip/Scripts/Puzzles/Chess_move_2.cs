﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chess_move_2 : MonoBehaviour
{

    private bool moving;
    public int grid_width;
    public int grid_length;
    public List<int> my_grid_pos = new List<int>(); //first number horizontal, second verical
    public List<int> player_grid_pos = new List<int>();
    private int i;
    private int j;
    private int gap;
    private int count;
    private int counter;
    private int tiers;
    public int multiplier;
    public bool turn_setup;
    private int close_spaces;
    private List<List<int>> closest_spaces = new List<List<int>>();
    private List<int> closest_space = new List<int>();
    private float smallest_distance;
    public bool black;
    public int max_moves_needed;
    private List<bool> breaks = new List<bool>();
    public List<List<List<int>>> grid = new List<List<List<int>>>(); //first width, second length, third dimension of list has 3 digits, first for tile type, second for piece on tile, third for if in range.
    private int least_moves_needed;
    //0 for passable, 1 for not
    //0 for empty, 1 for has a piece
    //0 for out of range, 1 for in range, 2 for in range of player
    //Bonus digits for the tiles that generated it
    void Start()
    {
        close_spaces = 0;
        for (i = 0; i < grid_width; i++)
        {
            List<List<int>> list1 = new List<List<int>>();
            for (j = 0; j < grid_length; j++)
            {
                List<int> list2 = new List<int>();
                list2.Add(0);
                list2.Add(0);
                list2.Add(0);
                list2.Add(-1);
                list2.Add(-1);
                list1.Add(list2);
            } //Generates the grid
            grid.Add(list1);
        }
        for (i = 0; i < 8; i++)
        {
            breaks.Add(false);
        }
    }
    void FixedUpdate()
    {
        if (turn_setup)
        {
            least_moves_needed = 2000; //Sets the most possible moves to an unreachable amount
            Player_chess_move player_move = FindObjectOfType<Player_chess_move>();
            player_grid_pos = player_move.my_grid_pos;
            for (i = 0; i < grid_width; i++)
            {
                for (j = 0; j < grid_length; j++)
                {
                    grid[i][j][4] = -1;
                    grid[i][j][3] = -1;
                    grid[i][j][2] = 0;
                    grid[i][j][1] = 0; //Resets the grid
                    int y = new int();
                    for (y = grid[i][j].Count - 1; y > 4; y--)
                    {
                        grid[i][j].Remove(y);
                    } // Removes all parent tiles
                }
            }
            if (black) //Checks which chess piece is blocking this one's movement
            {
                GameObject white = GameObject.Find("White_piece");
                Chess_move_2 white_move = white.GetComponent<Chess_move_2>();
                grid[white_move.my_grid_pos[0]][white_move.my_grid_pos[1]][1] = 1;
            }
            else
            {
                GameObject black = GameObject.Find("Black_piece");
                Chess_move_2 black_move = black.GetComponent<Chess_move_2>();
                grid[black_move.my_grid_pos[0]][black_move.my_grid_pos[1]][1] = 1;
            }
            closest_spaces.Clear();
            closest_space.Clear();
            closest_space.Add(400); //Sets the closest spaces to be an unreachable amount
            closest_space.Add(400);
            grid[my_grid_pos[0]][my_grid_pos[1]][2] = 1;
            gap = 0;
            for (i = 0; i < 8; i++) 
            {
                breaks[i] = false; 
            }
            //Marks all tiles horizontal, vertical or diagonal to piece
            while (my_grid_pos[0] - gap >= 0 || my_grid_pos[1] - gap >= 0 || my_grid_pos[0] + gap < grid_width || my_grid_pos[1] + gap < grid_width)
            {
                if (my_grid_pos[0] - gap >= 0 && !breaks[0]) //Marks the tiles on this specific row in this direction until the edge or an inaccesible tile
                {
                    if (grid[my_grid_pos[0] - gap][my_grid_pos[1]][0] == 0 && grid[my_grid_pos[0] - gap][my_grid_pos[1]][1] == 0)
                    {
                        grid[my_grid_pos[0] - gap][my_grid_pos[1]][2] = 1;
                    }
                    else
                    {
                        breaks[0] = true;
                    }
                }
                if (my_grid_pos[1] - gap >= 0 && !breaks[1])
                {
                    if (grid[my_grid_pos[0]][my_grid_pos[1] - gap][0] == 0 && grid[my_grid_pos[0]][my_grid_pos[1] - gap][1] == 0)
                    {
                        grid[my_grid_pos[0]][my_grid_pos[1] - gap][2] = 1;
                    }
                    else
                    {
                        breaks[1] = true;
                    }
                }
                if (my_grid_pos[0] + gap < grid_width && !breaks[2])
                {
                    if (grid[my_grid_pos[0] + gap][my_grid_pos[1]][0] == 0 && grid[my_grid_pos[0] + gap][my_grid_pos[1]][1] == 0)
                    {
                        grid[my_grid_pos[0] + gap][my_grid_pos[1]][2] = 1;
                    }
                    else
                    {
                        breaks[2] = true;
                    }
                }
                if (my_grid_pos[1] + gap < grid_length && !breaks[3])
                {
                    if (grid[my_grid_pos[0]][my_grid_pos[1] + gap][0] == 0 && grid[my_grid_pos[0]][my_grid_pos[1] + gap][1] == 0)
                    {
                        grid[my_grid_pos[0]][my_grid_pos[1] + gap][2] = 1;
                    }
                    else
                    {
                        breaks[3] = true;
                    }
                }
                if ((my_grid_pos[0] - gap >= 0) && (my_grid_pos[1] - gap >= 0) && !breaks[4])
                {
                    if (grid[my_grid_pos[0] - gap][my_grid_pos[1] - gap][0] == 0 && grid[my_grid_pos[0] - gap][my_grid_pos[1] - gap][1] == 0)
                    {
                        grid[my_grid_pos[0] - gap][my_grid_pos[1] - gap][2] = 1;
                    }
                    else
                    {
                        breaks[4] = true;
                    }
                }
                if ((my_grid_pos[0] - gap >= 0) && (my_grid_pos[1] + gap < grid_length) && !breaks[5])
                {
                    if (grid[my_grid_pos[0] - gap][my_grid_pos[1] + gap][0] == 0 && grid[my_grid_pos[0] - gap][my_grid_pos[1] + gap][1] == 0)
                    {
                        grid[my_grid_pos[0] - gap][my_grid_pos[1] + gap][2] = 1;
                    }
                    else
                    {
                        breaks[5] = true;
                    }
                }
                if ((my_grid_pos[0] + gap < grid_width) && (my_grid_pos[1] - gap >= 0) && !breaks[6])
                {
                    if (grid[my_grid_pos[0] + gap][my_grid_pos[1] - gap][0] == 0 && grid[my_grid_pos[0] + gap][my_grid_pos[1] - gap][1] == 0)
                    {
                        grid[my_grid_pos[0] + gap][my_grid_pos[1] - gap][2] = 1;
                    }
                    else
                    {
                        breaks[6] = true;
                    }
                }
                if ((my_grid_pos[0] + gap < grid_width) && (my_grid_pos[1] + gap < grid_length) && !breaks[7])
                {
                    if (grid[my_grid_pos[0] + gap][my_grid_pos[1] + gap][0] == 0 && grid[my_grid_pos[0] + gap][my_grid_pos[1] + gap][1] == 0)
                    {
                        grid[my_grid_pos[0] + gap][my_grid_pos[1] + gap][2] = 1;
                    }
                    else
                    {
                        breaks[7] = true;
                    }
                }
                gap++;
            }
            counter = 1;
            tiers = 1;
            while (counter != 0)
            {
                counter = 0;
                for (i = 0; i < grid_width; i++)
                {
                    for (j = 0; j < grid_length; j++)
                    {
                        if (grid[i][j][2] == tiers)
                        {
                            grid_fill(i, j, tiers + 1); //Marks all accesible tiles on the grid
                            counter++;
                        }
                    }
                }
                tiers++;
            }
            for (i = 0; i < 8; i++)
            {
                breaks[i] = false;
            }
            gap = 0;
            if(grid[player_grid_pos[0]][player_grid_pos[1]][0] == 0 || grid[player_grid_pos[0]][player_grid_pos[1]][2] > 1)
            { 
                grid[player_grid_pos[0]][player_grid_pos[1]][2] += 1000; //Marks the player's tile as in range
            }
            //Marks all tiles horizontal, vertical or diagonal to player as in range
            while (player_grid_pos[0] - gap >= 0 || player_grid_pos[1] - gap >= 0 || player_grid_pos[0] + gap < grid_width || player_grid_pos[1] + gap < grid_width)
            {
                gap++;
                if (player_grid_pos[0] - gap >= 0 && !breaks[0]) //Marks the tiles on this specific row in this direction until the edge or an inaccesible tile as in range
                    {
                    if (grid[player_grid_pos[0] - gap][player_grid_pos[1]][0] == 0 && (grid[player_grid_pos[0] - gap][player_grid_pos[1]][2] > 1 || grid[player_grid_pos[0] - gap][player_grid_pos[1]][1] == 0))
                    {
                            grid[player_grid_pos[0] - gap][player_grid_pos[1]][2] += 1000;
                    }
                    else
                    {
                        breaks[0] = true;
                    }
                }
                if (player_grid_pos[1] - gap >= 0 && !breaks[1])
                {
                    if (grid[player_grid_pos[0]][player_grid_pos[1] - gap][0] == 0 && (grid[player_grid_pos[0]][player_grid_pos[1] - gap][2] > 1 || grid[player_grid_pos[0]][player_grid_pos[1] - gap][1] == 0))
                    { 
                            grid[player_grid_pos[0]][player_grid_pos[1] - gap][2] += 1000;
                    }
                    else
                    {
                        breaks[1] = true;
                    }
                }
                if (player_grid_pos[0] + gap < grid_width && !breaks[2])
                {
                    if (grid[player_grid_pos[0] + gap][player_grid_pos[1]][0] == 0 && (grid[player_grid_pos[0] + gap][player_grid_pos[1]][2] > 1 || grid[player_grid_pos[0] + gap][player_grid_pos[1]][1] == 0))
                    {
                            grid[player_grid_pos[0] + gap][player_grid_pos[1]][2] += 1000;
                    }
                    else
                    {
                        breaks[2] = true;
                    }
                }
                if (player_grid_pos[1] + gap < grid_length && !breaks[3])
                {
                    if (grid[player_grid_pos[0]][player_grid_pos[1] + gap][0] == 0 && (grid[player_grid_pos[0]][player_grid_pos[1] + gap][2] > 1 || grid[player_grid_pos[0]][player_grid_pos[1] + gap][1] == 0))
                    {

                            grid[player_grid_pos[0]][player_grid_pos[1] + gap][2] += 1000;
                    }
                    else
                    {
                        breaks[3] = true;
                    }
                }
                if ((player_grid_pos[0] - gap >= 0) && (player_grid_pos[1] - gap >= 0) && !breaks[4])
                {
                    if (grid[player_grid_pos[0] - gap][player_grid_pos[1] - gap][0] == 0 && (grid[player_grid_pos[0] - gap][player_grid_pos[1] - gap][2] > 1 || grid[player_grid_pos[0] - gap][player_grid_pos[1] - gap][1] == 0))
                    {
                            grid[player_grid_pos[0] - gap][player_grid_pos[1] - gap][2] += 1000;
                    }
                    else
                    {
                        breaks[4] = true;
                    }
                }
                if ((player_grid_pos[0] - gap >= 0) && (player_grid_pos[1] + gap < grid_length) && !breaks[5])
                {
                    if (grid[player_grid_pos[0] - gap][player_grid_pos[1] + gap][0] == 0 && (grid[player_grid_pos[0] - gap][player_grid_pos[1] + gap][2] > 1 || grid[player_grid_pos[0] - gap][player_grid_pos[1] + gap][1] == 0))
                    {
                            grid[player_grid_pos[0] - gap][player_grid_pos[1] + gap][2] += 1000;
                    }
                    else
                    {
                        breaks[5] = true;
                    }
                }
                if ((player_grid_pos[0] + gap < grid_width) && (player_grid_pos[1] - gap >= 0) && !breaks[6])
                {
                    if (grid[player_grid_pos[0] + gap][player_grid_pos[1] - gap][0] == 0 && (grid[player_grid_pos[0] + gap][player_grid_pos[1] - gap][2] > 1 || grid[player_grid_pos[0] + gap][player_grid_pos[1] - gap][1] == 0))
                    {
                            grid[player_grid_pos[0] + gap][player_grid_pos[1] - gap][2] += 1000;
                    }
                    else
                    {
                        breaks[6] = true;
                    }
                }
                if ((player_grid_pos[0] + gap < grid_width) && (player_grid_pos[1] + gap < grid_length) && !breaks[7])
                {
                    if (grid[player_grid_pos[0] + gap][player_grid_pos[1] + gap][0] == 0 && (grid[player_grid_pos[0] + gap][player_grid_pos[1] + gap][2] > 1 || grid[player_grid_pos[0] + gap][player_grid_pos[1] + gap][1] == 0))
                    {
                            grid[player_grid_pos[0] + gap][player_grid_pos[1] + gap][2] += 1000;
                    }
                    else
                    {
                        breaks[7] = true;
                    }
                }
            }
            for (i = 0; i < grid_width; i++)
            {
                for (j = 0; j < grid_length; j++)
                {
                    if (grid[i][j][2] > 1000 && grid[i][j][2] < least_moves_needed)
                    {
                        least_moves_needed = grid[i][j][2]; //Checks what the shortest amount of moves needed is
                    }
                }
            }
            for (i = 0; i < grid_width; i++)
            {
                for (j = 0; j < grid_length; j++)
                {
                    if (grid[i][j][2] == least_moves_needed)
                    {
                        Find_parent_tile(i,j); //Marks the optimal tiles that can be reached in one move
                    }
                }
            }
            smallest_distance = 99;
            List<int> filler_list_1 = new List<int>();
            closest_spaces.Add(filler_list_1);
            filler_list_1.Add(99);
            List<int> filler_list_2 = new List<int>();
            filler_list_2.Add(99);
            closest_spaces.Add(filler_list_2);
            for (i = 0; i < grid_width; i++) //Finds the closest optimal tiles to the player
            {
                for (j = 0; j < grid_length; j++)
                {
                    if (grid[i][j][2] == 999 && smallest_distance >= Mathf.Sqrt(Mathf.Pow(i - player_grid_pos[0], 2) + Mathf.Pow(j - player_grid_pos[1], 2)))
                    {
                        if (smallest_distance == Mathf.Sqrt(Mathf.Pow(i - player_grid_pos[0], 2) + Mathf.Pow(j - player_grid_pos[1], 2)))
                        {
                            closest_spaces[0].Add(i);
                            closest_spaces[1].Add(j);
                            close_spaces++;
                        }
                        else
                        {
                            close_spaces = 1;
                            closest_spaces.Clear();
                            List<int> filler_list_3 = new List<int>();
                            filler_list_3.Add(99);
                            closest_spaces.Add(filler_list_3);
                            List<int> filler_list_4 = new List<int>();
                            filler_list_4.Add(99);
                            closest_spaces.Add(filler_list_4);
                            closest_spaces[0][0] = i;
                            closest_spaces[1][0] = j;
                            smallest_distance = Mathf.Sqrt(Mathf.Pow(i - player_grid_pos[0], 2) + Mathf.Pow(j - player_grid_pos[1], 2));
                        }
                    }
                }
            }
            smallest_distance = 99;
            for (i = 0; i < close_spaces; i++)//Finds the closest tile to the piece of the closest optimal tile to the player
            {
                if (smallest_distance > Mathf.Sqrt(Mathf.Pow(closest_spaces[0][i] - my_grid_pos[0], 2) + Mathf.Pow(closest_spaces[1][i] - my_grid_pos[1], 2)))
                {
                    smallest_distance = Mathf.Sqrt(Mathf.Pow(closest_spaces[0][i] - my_grid_pos[0], 2) + Mathf.Pow(closest_spaces[1][i] - my_grid_pos[1], 2));
                    closest_space[0] = closest_spaces[0][i];
                    closest_space[1] = closest_spaces[1][i];
                }
            }

            if (Mathf.Abs(closest_space[0] - my_grid_pos[0]) >= Mathf.Abs(closest_space[1] - my_grid_pos[1]))
            {
                multiplier = Mathf.Abs(closest_space[0] - my_grid_pos[0]);
            }
            else
            {
                multiplier = Mathf.Abs(closest_space[1] - my_grid_pos[1]);
            }
            if (closest_space[0] == 400 && closest_space[1] == 400)
            {
                player_move.player_turn = true;
                turn_setup = false;
            }
            else
            {
                moving = true;
                count = 0;
            }
        }
        if (moving) //Moves the tile to the correct piece
        {
            turn_setup = false;
            if (count < multiplier * 28)
            {
                if (closest_space[0] - my_grid_pos[0] == 0)
                {
                    transform.position += new Vector3(0, (my_grid_pos[1] - closest_space[1]) / Mathf.Abs(closest_space[1] - my_grid_pos[1]) * 0.02f, 0);
                }
                else if (closest_space[1] - my_grid_pos[1] == 0)
                {
                    transform.position += new Vector3(-(my_grid_pos[0] - closest_space[0]) / Mathf.Abs(closest_space[0] - my_grid_pos[0]) * 0.02f, 0, 0);
                }
                else
                {
                    transform.position += new Vector3(-(my_grid_pos[0] - closest_space[0]) / Mathf.Abs(closest_space[0] - my_grid_pos[0]) * 0.02f, -(closest_space[1] - my_grid_pos[1]) / Mathf.Abs(my_grid_pos[1] - closest_space[1]) * 0.02f, 0);
                }
            }
            else
            {
                moving = false;
                my_grid_pos[0] = closest_space[0];
                my_grid_pos[1] = closest_space[1];//Sets the piece's tile to its new location
                Player_chess_move player_move = FindObjectOfType<Player_chess_move>();
                player_move.player_turn = true;
            }
            count++;
        }
    }
    private void grid_fill(int x_pos, int y_pos, int tier)
    {
        gap = 0;
        int y = new int();
        for (y = 0; y < 8; y++)
        {
            breaks[y] = false;
        }
        while (x_pos - gap >= 0 || y_pos - gap >= 0 || x_pos + gap < grid_width || y_pos + gap < grid_width)
        {
            if (x_pos - gap >= 0 && !breaks[0])
            {
                if (grid[x_pos - gap][y_pos][0] == 0 || (x_pos - gap == player_grid_pos[0] && y_pos == player_grid_pos[1]))
                {
                    if (grid[x_pos - gap][y_pos][2] == 0)
                    {
                        grid[x_pos - gap][y_pos][2] = tier;
                        grid[x_pos - gap][y_pos][3] = x_pos;
                        grid[x_pos - gap][y_pos][4] = y_pos;
                    }
                    else if(grid[x_pos - gap][y_pos][2] == tier)
                    {
                        grid[x_pos - gap][y_pos].Add(x_pos);
                        grid[x_pos - gap][y_pos].Add(y_pos);
                    }
                }
                else
                {
                    breaks[0] = true;
                }
            }
            if (y_pos - gap >= 0 && !breaks[1])
            {
                if (grid[x_pos][y_pos - gap][0] == 0 || (x_pos == player_grid_pos[0] && y_pos - gap == player_grid_pos[1]))
                {
                    if (grid[x_pos][y_pos - gap][2] == 0)
                    {
                        grid[x_pos][y_pos - gap][2] = tier;
                        grid[x_pos][y_pos - gap][3] = x_pos;
                        grid[x_pos][y_pos - gap][4] = y_pos;
                    }
                    else if (grid[x_pos][y_pos - gap][2] == tier)
                    {
                        grid[x_pos][y_pos - gap].Add(x_pos);
                        grid[x_pos][y_pos - gap].Add(y_pos);
                    }
                }
                else
                {
                    breaks[1] = true;
                }
            }
            if (x_pos + gap < grid_width && !breaks[2])
            {
                if (grid[x_pos + gap][y_pos][0] == 0 || (x_pos + gap == player_grid_pos[0] && y_pos == player_grid_pos[1]))
                {
                    if (grid[x_pos + gap][y_pos][2] == 0)
                    {
                        grid[x_pos + gap][y_pos][2] = tier;
                        grid[x_pos + gap][y_pos][3] = x_pos;
                        grid[x_pos + gap][y_pos][4] = y_pos;
                    }
                    else if (grid[x_pos + gap][y_pos][2] == tier)
                    {
                        grid[x_pos + gap][y_pos].Add(x_pos);
                        grid[x_pos + gap][y_pos].Add(y_pos);
                    }
                }
                else
                {
                    breaks[2] = true;
                }
            }
            if (y_pos + gap < grid_length && !breaks[3])
            {
                if (grid[x_pos][y_pos + gap][0] == 0 || (x_pos + gap == player_grid_pos[0] && y_pos == player_grid_pos[1]))
                {
                    if (grid[x_pos][y_pos + gap][2] == 0)
                    {
                        grid[x_pos][y_pos + gap][2] = tier;
                        grid[x_pos][y_pos + gap][3] = x_pos;
                        grid[x_pos][y_pos + gap][4] = y_pos;
                    }
                    else if (grid[x_pos][y_pos + gap][2] == tier)
                    {
                        grid[x_pos][y_pos + gap].Add(x_pos);
                        grid[x_pos][y_pos + gap].Add(y_pos);
                    }
                }
                else
                {
                    breaks[3] = true;
                }
            }
            if ((x_pos - gap >= 0) && (y_pos - gap >= 0) && !breaks[4])
            {
                if (grid[x_pos - gap][y_pos - gap][0] == 0 || (x_pos - gap == player_grid_pos[0] && y_pos - gap == player_grid_pos[1]))
                {
                    if (grid[x_pos - gap][y_pos - gap][2] == 0)
                    {
                        grid[x_pos - gap][y_pos - gap][2] = tier;
                        grid[x_pos - gap][y_pos - gap][3] = x_pos;
                        grid[x_pos - gap][y_pos - gap][4] = y_pos;
                    }
                    else if (grid[x_pos - gap][y_pos - gap][2] == tier)
                    {
                        grid[x_pos - gap][y_pos - gap].Add(x_pos);
                        grid[x_pos - gap][y_pos - gap].Add(y_pos);
                    }
                }
                else
                {
                    breaks[4] = true;
                }
            }
            if ((x_pos - gap >= 0) && (y_pos + gap < grid_length) && !breaks[5])
            {
                if (grid[x_pos - gap][y_pos + gap][0] == 0 || (x_pos - gap == player_grid_pos[0] && y_pos + gap == player_grid_pos[1]))
                {
                    if (grid[x_pos - gap][y_pos + gap][2] == 0)
                    {
                        grid[x_pos - gap][y_pos + gap][2] = tier;
                        grid[x_pos - gap][y_pos + gap][3] = x_pos;
                        grid[x_pos - gap][y_pos + gap][4] = y_pos;
                    }
                    else if (grid[x_pos - gap][y_pos + gap][2] == tier)
                    {
                        grid[x_pos - gap][y_pos + gap].Add(x_pos);
                        grid[x_pos - gap][y_pos + gap].Add(y_pos);
                    }
                }
                else
                {
                    breaks[5] = true;
                }
            }
            if ((x_pos + gap < grid_width) && (y_pos - gap >= 0) && !breaks[6])
            {
                if (grid[x_pos + gap][y_pos - gap][0] == 0 || (x_pos + gap == player_grid_pos[0] && y_pos - gap == player_grid_pos[1]))
                {
                    if (grid[x_pos + gap][y_pos - gap][2] == 0)
                    {
                        grid[x_pos + gap][y_pos - gap][2] = tier;
                        grid[x_pos + gap][y_pos - gap][3] = x_pos;
                        grid[x_pos + gap][y_pos - gap][4] = y_pos;
                    }
                    else if (grid[x_pos + gap][y_pos - gap][2] == tier)
                    {
                        grid[x_pos + gap][y_pos - gap].Add(x_pos);
                        grid[x_pos + gap][y_pos - gap].Add(y_pos);
                    }
                }
                else
                {
                    breaks[6] = true;
                }
            }
            if ((x_pos + gap < grid_width) && (y_pos + gap < grid_length) && !breaks[7])
            {
                if (grid[x_pos + gap][y_pos + gap][0] == 0 || (x_pos + gap == player_grid_pos[0] && y_pos + gap == player_grid_pos[1]))
                {
                    if (grid[x_pos + gap][y_pos + gap][2] == 0)
                    {
                        grid[x_pos + gap][y_pos + gap][2] = tier;
                        grid[x_pos + gap][y_pos + gap][3] = x_pos;
                        grid[x_pos + gap][y_pos + gap][4] = y_pos;

                    }
                    else if (grid[x_pos + gap][y_pos + gap][2] == tier)
                    {
                        grid[x_pos + gap][y_pos + gap].Add(x_pos);
                        grid[x_pos + gap][y_pos + gap].Add(y_pos);
                    }
                }
                else
                {
                    breaks[7] = true;
                }
            }
            gap++;
        }
    }
    private void Find_parent_tile(int my_x, int my_y)
    {
        int y = new int();
        for (y = 3; y < grid[my_x][my_y].Count; y += 2)
        {
            if (grid[my_x][my_y][y] != -1)
            {
                Find_parent_tile(grid[my_x][my_y][y], grid[my_x][my_y][y+1]);
            }
            else
            {
                break;
            }
        }
        if(grid[my_x][my_y][3] == -1)
        {
            grid[my_x][my_y][2] = 999;
        }
    }
}
