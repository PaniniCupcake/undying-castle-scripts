﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Player_stalactite_move : MonoBehaviour
{
    public int grid_width;
    public int grid_length;
    public List<int> my_grid_pos = new List<int>();
    private int i;
    private int j;
    private int count;
    private int mycount;
    public bool player_turn = true;
    private bool moving;
    public int blip;
    private int move_direction;
    public Animator animator;
    public string puzzle_level;
    private bool lose;
    public bool win;
    public int tiles_needed;
    public bool environment_turn;
    public int spikes_fall;
    public List<List<int>> grid = new List<List<int>>();
    public float middle;
    private int opacity = 100;
    public List<string> buttons = new List<string>();
    public float pos_dif;
    public float size_dif;
    public bool first_attempt = true;
    void Start()
    {
        first_attempt = FindObjectOfType<Log>().first_attempt;
        pos_dif = GameObject.Find("Puzzle_background").transform.position.y - FindObjectOfType<Camera>().transform.position.y + 0.02f;
        size_dif = GameObject.Find("Puzzle_background").transform.localScale.y - 0.0175f;
        buttons = FindObjectOfType<Keybinds>().buttons;
        for (i = 0; i < grid_width; i++)
        {
            List<int> list1 = new List<int>();
            for (j = 0; j < grid_length; j++)
            {
                list1.Add(1);
            }
            grid.Add(list1);
        }
        player_turn = true;
        animator.SetFloat("Direction", 4f);
        if (first_attempt)
        {
            GameObject.Find("Puzzle_background").transform.localScale = new Vector3(0.0175f, 0.0175f, 0);
            GameObject.Find("Puzzle_background").transform.position = new Vector3(transform.position.x, FindObjectOfType<Camera>().transform.position.y + 0.02f, 0);
        }
        count = 0;
    }
    void Update()
    {
        if (first_attempt)
        {
            if (count < 100)
            {
                count++;
                GameObject.Find("Puzzle_background").transform.position += new Vector3(0, 0.01f, 0) * pos_dif;
                GameObject.Find("Puzzle_background").transform.localScale += new Vector3(0.01f, 0.01f, 0) * size_dif;
            }
            else
            {
                SceneManager.LoadScene(puzzle_level);
                count = 0;
                first_attempt = false;
                FindObjectOfType<Log>().first_attempt = false;
            }
        }
        else
        {
            if (count == 90 && my_grid_pos[1] != 0)
            {
                gameObject.GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f, 0.25f);
            }
            if (count == 100)
            {
                gameObject.GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f, 1f);
                count = 0;
            }
            count++;
            if (Input.GetKey(buttons[8]))
            {
                blip = 0;
                player_turn = false;
                lose = true;
            }
            if (opacity > 0 && !lose)
            {
                opacity--;
            }
            if (tiles_needed == 0)
            {
                win = true;
            }
            if (lose)
            {
                opacity += 2;
                if (opacity == 100)
                {
                    GameObject.Find("Obscurer").GetComponent<SpriteRenderer>().sortingLayerName = "Text";
                }
                if (blip < 100 && blip >= 55)
                {
                    GameObject.Find("Yellow_right_page").transform.RotateAround(new Vector3(middle, 0, 0), new Vector3(0, 1, 0), 4f);
                }
                if (blip == 100)
                {
                    SceneManager.LoadScene(puzzle_level);
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                }
                blip++;
            }
            if (win)
            {
                if (GameObject.Find("Puzzle_background").transform.localScale.y > 0)
                {
                    GameObject.Find("Puzzle_background").transform.position += new Vector3(0, -0.01f, 0) * pos_dif;
                    GameObject.Find("Puzzle_background").transform.localScale += new Vector3(-0.01f, -0.01f, 0) * size_dif;
                }
                else
                {
                    FindObjectOfType<Background_darkness>().GetComponent<SpriteRenderer>().sortingLayerName = "Death layer";
                }
                if (blip == 150)
                {
                    SceneManager.LoadScene("Cave");
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                }
                blip++;
            }
            GameObject.FindGameObjectWithTag("Paper").GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f, opacity * 0.01f);
            if (player_turn)
            {
                if (Input.GetKeyDown(buttons[9]))
                {
                    if (Input.GetKey(buttons[0]) && Input.GetKey(buttons[2]))
                    {
                        if (my_grid_pos[0] - 1 >= 0 && my_grid_pos[1] - 1 >= 0 && grid[my_grid_pos[0] - 1][my_grid_pos[1] - 1] != 1 && grid[my_grid_pos[0] - 1][my_grid_pos[1] - 1] != 1)
                        {
                            move_direction = 8;
                            my_grid_pos[0] -= 1;
                            my_grid_pos[1] -= 1;
                            animator.SetFloat("Direction", 1f);
                            moving = true;
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[0]) && Input.GetKey(buttons[3]))
                    {
                        if (my_grid_pos[0] + 1 < grid_width && my_grid_pos[1] - 1 >= 0 && grid[my_grid_pos[0] + 1][my_grid_pos[1] - 1] != 1 && grid[my_grid_pos[0] + 1][my_grid_pos[1] - 1] != 1)
                        {
                            move_direction = 2;
                            my_grid_pos[0] += 1;
                            my_grid_pos[1] -= 1;
                            animator.SetFloat("Direction", 1f);
                            moving = true;
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[1]) && Input.GetKey(buttons[2]))
                    {
                        if (my_grid_pos[0] - 1 >= 0 && my_grid_pos[1] + 1 < grid_length && grid[my_grid_pos[0] - 1][my_grid_pos[1] + 1] != 1 && grid[my_grid_pos[0] - 1][my_grid_pos[1] + 1] != 1)
                        {
                            move_direction = 6;
                            my_grid_pos[0] -= 1;
                            my_grid_pos[1] += 1;
                            animator.SetFloat("Direction", 2f);
                            moving = true;
                            player_turn = false;
                            gameObject.GetComponent<SpriteRenderer>().sortingOrder = my_grid_pos[1] * 2 + 2;
                        }
                    }
                    else if (Input.GetKey(buttons[1]) && Input.GetKey(buttons[3]))
                    {
                        if (my_grid_pos[0] + 1 < grid_width && my_grid_pos[1] + 1 < grid_length && grid[my_grid_pos[0] + 1][my_grid_pos[1] + 1] != 1 && grid[my_grid_pos[0] + 1][my_grid_pos[1] + 1] != 1)
                        {
                            move_direction = 4;
                            my_grid_pos[0] += 1;
                            my_grid_pos[1] += 1;
                            moving = true;
                            animator.SetFloat("Direction", 2f);
                            player_turn = false;
                            gameObject.GetComponent<SpriteRenderer>().sortingOrder = my_grid_pos[1] * 2 + 2;
                        }
                    }
                    else if (Input.GetKey(buttons[3]))
                    {
                        if (my_grid_pos[0] + 1 < grid_width && grid[my_grid_pos[0] + 1][my_grid_pos[1]] != 1 && grid[my_grid_pos[0] + 1][my_grid_pos[1]] != 1)
                        {
                            move_direction = 3;
                            my_grid_pos[0] += 1;
                            moving = true;
                            animator.SetFloat("Direction", 4f);
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[0]))
                    {
                        if (my_grid_pos[1] - 1 >= 0 && grid[my_grid_pos[0]][my_grid_pos[1] - 1] != 1 && grid[my_grid_pos[0]][my_grid_pos[1] - 1] != 1)
                        {
                            move_direction = 1;
                            my_grid_pos[1] -= 1;
                            moving = true;
                            animator.SetFloat("Direction", 1f);
                            player_turn = false;
                        }
                    }
                    else if (Input.GetKey(buttons[1]))
                    {
                        if (my_grid_pos[1] + 1 < grid_length && grid[my_grid_pos[0]][my_grid_pos[1] + 1] != 1 && grid[my_grid_pos[0]][my_grid_pos[1] + 1] != 1)
                        {
                            move_direction = 5;
                            my_grid_pos[1] += 1;
                            moving = true;
                            animator.SetFloat("Direction", 2f);
                            player_turn = false;
                            gameObject.GetComponent<SpriteRenderer>().sortingOrder = my_grid_pos[1] * 2 + 2;
                        }
                    }
                    else if (Input.GetKey(buttons[2]))
                    {
                        if (my_grid_pos[0] - 1 >= 0 && grid[my_grid_pos[0] - 1][my_grid_pos[1]] != 1 && grid[my_grid_pos[0] - 1][my_grid_pos[1]] != 1)
                        {
                            move_direction = 7;
                            my_grid_pos[0] -= 1;
                            moving = true;
                            animator.SetFloat("Direction", 3f);
                            player_turn = false;
                        }
                    }
                    else
                    {
                        move_direction = 0;
                        moving = true;
                        player_turn = false;
                    }
                    mycount = 0;
                }
            }
            if (moving)
            {
                if (mycount < 28)
                {
                    if (move_direction != 0)
                    {
                        animator.SetFloat("Magnitude", 1f);
                    }
                    if (move_direction == 1)
                    {
                        transform.position += new Vector3(0, 0.02f, 0);
                    }
                    if (move_direction == 2)
                    {
                        transform.position += new Vector3(0.02f, 0.02f, 0);
                    }
                    if (move_direction == 3)
                    {
                        transform.position += new Vector3(0.02f, 0, 0);
                    }
                    if (move_direction == 4)
                    {
                        transform.position += new Vector3(0.02f, -0.02f, 0);
                    }
                    if (move_direction == 5)
                    {
                        transform.position += new Vector3(0, -0.02f, 0);
                    }
                    if (move_direction == 6)
                    {
                        transform.position += new Vector3(-0.02f, -0.02f, 0);
                    }
                    if (move_direction == 7)
                    {
                        transform.position += new Vector3(-0.02f, 0, 0);
                    }
                    if (move_direction == 8)
                    {
                        transform.position += new Vector3(-0.02f, 0.02f, 0);
                    }
                }
                else
                {
                    gameObject.GetComponent<SpriteRenderer>().sortingOrder = my_grid_pos[1] * 2 + 2;
                    animator.SetFloat("Magnitude", 0);
                    moving = false;
                    environment_turn = true;
                }
                mycount++;
            }
            if (environment_turn)
            {
                spikes_fall++;
                if (spikes_fall == 29)
                {
                    player_turn = true;
                    spikes_fall = 0;
                    environment_turn = false;
                }
            }
        }
    }
}