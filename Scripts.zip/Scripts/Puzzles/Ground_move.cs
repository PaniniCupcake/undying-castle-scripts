﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ground_move : MonoBehaviour
{
    public bool going_up;
    public int x_pos;
    public int y_pos;
    public int grid_height;
    public bool tile_turn;
    private bool moving;
    private int count;
    private int count2;
    void FixedUpdate()
    {
        if((y_pos == 0 && going_up)||(y_pos == grid_height - 1 && !going_up))
        {
            gameObject.GetComponent<Renderer>().material.color = Color.red;
        }
        else
        {
            gameObject.GetComponent<Renderer>().material.color = Color.white;
        }
        Player_floating_ground_move player_script = FindObjectOfType<Player_floating_ground_move>();
        if(!moving && !tile_turn && player_script.tiles_turn == 1)
        {
            tile_turn = true;
        }
        if (count2 == 2)
        {
            player_script.grid[x_pos][y_pos] = true;
        }
        if (count2 <= 2)
        {
            count2++;
        }
        if(tile_turn)
        {
            if(going_up)
            {
                y_pos -= 1;
                if(y_pos == -1)
                {
                    y_pos = grid_height - 1;
                }
            }
            else
            {
                y_pos += 1;
                if (y_pos == grid_height)
                {
                    y_pos = 0;
                    gameObject.GetComponent<SpriteRenderer>().sortingOrder = 0;
                }
            }
            tile_turn = false;
            moving = true;
            count = 0;
        }
        if (moving)
        {
            if (going_up)
            {
                if (y_pos == grid_height - 1)
                {
                    if (count < 14)
                    {
                        transform.position += new Vector3(0, -0.5f, 0);
                    }
                    else if (count < 28)
                    {
                        transform.position += new Vector3(0, 0.5f, 0);
                    }
                    else { moving = false; }
                    if (count == 14)
                    {
                        gameObject.GetComponent<SpriteRenderer>().sortingOrder = 0;
                        transform.position += new Vector3(0, -0.56f * (grid_height - 1), 0);
                    }
                    count++;
                }
                else
                {
                    if (count < 28)
                    {
                        transform.position += new Vector3(0, 0.02f, 0);
                    }
                    else { moving = false; }
                    count++;
                }
            }
            else
            {
                if (y_pos == 0)
                {
                    if (count < 14)
                    {
                        transform.position += new Vector3(0, -0.5f, 0);
                    }
                    else if (count < 28)
                    {
                        transform.position += new Vector3(0, 0.5f, 0);
                    }
                    else { moving = false; }
                    if (count == 14)
                    {
                        transform.position += new Vector3(0, 0.56f * (grid_height - 1), 0);
                        gameObject.GetComponent<SpriteRenderer>().sortingOrder = 3;
                    }
                    count++;
                }
                else
                {
                    if (count < 28)
                    {
                        transform.position += new Vector3(0, -0.02f, 0);
                    }
                    else { moving = false; }
                    count++;
                }
            }
            if (count == 28)
            {
                moving = false;
                player_script.grid[x_pos][y_pos] = true;
                gameObject.GetComponent<SpriteRenderer>().sortingOrder = 3;
                count = 0;
            }
        }
    }
}
