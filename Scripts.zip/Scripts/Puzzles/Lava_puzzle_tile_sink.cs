﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Lava_puzzle_tile_sink : MonoBehaviour
{
    public int tier;
    public Animator animator;
    private int count;
    public int x_pos;
    public int y_pos;
    public GameObject tier_2_tile;
    public GameObject tier_1_tile;
    public void Update()
    {
        if(count == 2)
        {
            Player_lava_move player = FindObjectOfType<Player_lava_move>();
            player.grid[x_pos][y_pos] = true;
        }
        else if(count < 2)
        {
            count++;
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {
        if (tier == 1)
        {
            animator.SetBool("Destroyed", true);
            Player_lava_move player = FindObjectOfType<Player_lava_move>();
            player.grid[x_pos][y_pos] = false;
            player.remaining_tiles -= 1;
            Destroy(this);
        }
        else if (tier == 2)
        {
            Lava_puzzle_tile_sink tile = Instantiate(tier_1_tile, new Vector3(transform.position.x, transform.position.y, 0), Quaternion.identity).GetComponent<Lava_puzzle_tile_sink>();
            tile.x_pos = x_pos;
            tile.y_pos = y_pos;
            Destroy(this);
        }
        else if (tier == 3)
        {
            Lava_puzzle_tile_sink tile = Instantiate(tier_2_tile, new Vector3(transform.position.x, transform.position.y, 0), Quaternion.identity).GetComponent<Lava_puzzle_tile_sink>();
            tile.x_pos = x_pos;
            tile.y_pos = y_pos;
            Destroy(this);
        }
    }
}
