﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stalactite_tile_setup : MonoBehaviour
{
    private int count;
    public int xpos;
    public int ypos;
    void Update()
    {
        if (count == 2)
        {
            Player_stalactite_move player_script = FindObjectOfType<Player_stalactite_move>();
            player_script.grid[xpos][ypos] = 0;
            GetComponent<SpriteRenderer>().sortingOrder = ypos * 2;
            Destroy(this);
        }
        count++;
    }
}