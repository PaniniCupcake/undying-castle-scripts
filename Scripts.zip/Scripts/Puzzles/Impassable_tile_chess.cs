﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Impassable_tile_chess : MonoBehaviour {
    public int x_pos;
    public int y_pos;
    public int type;
	void Update () {
		if(type>= 2)
        {
            GameObject white = GameObject.Find("White_piece");
            Chess_move_2 white_move = white.GetComponent<Chess_move_2>();
            white_move.grid[x_pos][y_pos][0] = 1;
            GameObject black = GameObject.Find("Black_piece");
            Chess_move_2 black_move = black.GetComponent<Chess_move_2>();
            black_move.grid[x_pos][y_pos][0] = 1;

        }
        if(type <= 2)
        {
            Player_chess_move player_move = FindObjectOfType<Player_chess_move>();
            player_move.grid[x_pos][y_pos][0] = 1;
        }
        Destroy(this);
	}
}
