﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stalactite_fall : MonoBehaviour
{
    public GameObject stalactite;
    public bool accesible;
    private bool stalactite_made;
    public int x_pos;
    public int y_pos;
    public Animator animator;
    private int count;
    public GameObject player;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if(other.CompareTag("Player"))
        {
            stalactite_made = true;
            player = other.gameObject;
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            player = null;
        }
    }
    void FixedUpdate()
    {
        if (Input.GetKeyDown(KeyCode.E) && !Input.GetKey(KeyCode.A) && !Input.GetKey(KeyCode.W) && !Input.GetKey(KeyCode.S) && !Input.GetKey(KeyCode.D) && player != null && FindObjectOfType<Player_stalactite_move>().environment_turn == false)
        {
            stalactite_made = true;
        }
        if (stalactite_made)
        {
            Player_stalactite_move player_script = FindObjectOfType<Player_stalactite_move>();
            if(count == 0)
            {
                SpriteRenderer falling = Instantiate(stalactite, new Vector3(transform.position.x, transform.position.y + 5.6f, 0), Quaternion.identity).GetComponent<SpriteRenderer>();
                falling.sortingOrder = GetComponent<SpriteRenderer>().sortingOrder;
                if (player_script.my_grid_pos[1] == y_pos - 1)
                {
                    falling.sortingOrder = GetComponent<SpriteRenderer>().sortingOrder + 3;
                }
            }
            count++;
            if(count == 28)
            {
                if (accesible)
                {
                    player_script.tiles_needed--;
                    animator.SetInteger("Accesible", 1);
                    accesible = false;
                    player_script.grid[x_pos][y_pos] = 1;
                }
                else
                {
                    player_script.tiles_needed++;
                    animator.SetInteger("Accesible", 2);
                    accesible = true;
                    player_script.grid[x_pos][y_pos] = 0;
                }
                count = 0;
                stalactite_made = false;
            }
        }
    }
}
