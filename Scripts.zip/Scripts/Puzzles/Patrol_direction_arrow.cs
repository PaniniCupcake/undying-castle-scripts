﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Patrol_direction_arrow : MonoBehaviour
{
    public GameObject bot;
    void Update()
    {
        if(bot.GetComponent<Patrol_bot>().directions[bot.GetComponent<Patrol_bot>().turn] == 1)
        {
            transform.position = bot.transform.position + new Vector3(0,-0.3f,0);
            transform.rotation = Quaternion.Euler(0,0,180);
        }
        else if(bot.GetComponent<Patrol_bot>().directions[bot.GetComponent<Patrol_bot>().turn] == 2)
        {
            transform.position = bot.transform.position + new Vector3(0.4f, -0.6f, 0);
            transform.rotation = Quaternion.Euler(0, 0, 90);
        }
        else if (bot.GetComponent<Patrol_bot>().directions[bot.GetComponent<Patrol_bot>().turn] == 3)
        {
            transform.position = bot.transform.position + new Vector3(0, -0.9f, 0);
            transform.rotation = Quaternion.Euler(0, 0, 0);
        }
        else if (bot.GetComponent<Patrol_bot>().directions[bot.GetComponent<Patrol_bot>().turn] == 4)
        {
            transform.position = bot.transform.position + new Vector3(-0.4f, -0.6f, 0);
            transform.rotation = Quaternion.Euler(0, 0, 270);
        }
    }
}
