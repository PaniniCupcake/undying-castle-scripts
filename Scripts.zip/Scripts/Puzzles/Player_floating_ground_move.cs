﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Player_floating_ground_move : MonoBehaviour
{
    public int grid_width;
    public int grid_length;
    public List<int> my_grid_pos = new List<int>();
    private int i;
    private int j;
    public int count = 0;
    private bool moving;
    public int blip;
    private int move_direction;
    public List<string> buttons = new List<string>();
    public Animator animator;
    public string puzzle_level;
    public List<bool> up_columns;
    public bool my_turn = true;
    private bool restart;
    public bool getting_moved;
    public int tiles_turn;
    private int opacity = 100;
    public float middle;
    public float pos_dif;
    public float size_dif;
    public bool first_attempt = true;
    public List<int> finish_pos = new List<int>();
    private bool win;
    public int puzzle_index;
    public List<List<bool>> grid = new List<List<bool>>();
    void Start()
    {
        first_attempt = FindObjectOfType<Log>().first_attempt;
        pos_dif = GameObject.Find("Puzzle_background").transform.position.y - FindObjectOfType<Camera>().transform.position.y + 0.02f;
        size_dif = GameObject.Find("Puzzle_background").transform.localScale.y - 0.0175f;
        buttons = FindObjectOfType<Keybinds>().buttons;
        for (i = 0; i < grid_width; i++)
        {
            List<bool> list1 = new List<bool>();
            for (j = 0; j < grid_length; j++)
            {
                list1.Add(false);
            }
            grid.Add(list1);
        }
        animator.SetFloat("Direction", 4f);
        if (first_attempt)
        {
            GameObject.Find("Puzzle_background").transform.localScale = new Vector3(0.0175f, 0.0175f, 0);
            GameObject.Find("Puzzle_background").transform.position = new Vector3(transform.position.x, FindObjectOfType<Camera>().transform.position.y + 0.02f, 0);
        }
        count = 0;
    }
    void Update()
    {
        if (first_attempt)
        {
            if (count < 100)
            {
                print(count);
                count++;
                GameObject.Find("Puzzle_background").transform.position += new Vector3(0, 0.01f, 0) * pos_dif;
                GameObject.Find("Puzzle_background").transform.localScale += new Vector3(0.01f, 0.01f, 0) * size_dif;
            }
            else
            {
                SceneManager.LoadScene(puzzle_level);
                count = 0;
                first_attempt = false;
                FindObjectOfType<Log>().first_attempt = false;
            }
        }
        else
        {
            if (win)
            {
                if (GameObject.Find("Puzzle_background").transform.localScale.y > 0)
                {
                    GameObject.Find("Puzzle_background").transform.position += new Vector3(0, -0.01f, 0) * pos_dif;
                    GameObject.Find("Puzzle_background").transform.localScale += new Vector3(-0.01f, -0.01f, 0) * size_dif;
                }
                else
                {
                    FindObjectOfType<Background_darkness>().GetComponent<SpriteRenderer>().sortingLayerName = "Workshop";
                }
                if (blip == 150)
                {
                    SceneManager.LoadScene("Geomancy school");
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                }
                blip++;
            }
            if (Input.GetKey(buttons[8]))
            {
                blip = 0;
                restart = true;
            }
            if (opacity > 0 && !restart)
            {
                opacity--;
            }
            if (restart)
            {
                opacity += 2;
                if (opacity == 100)
                {
                    GameObject.Find("Obscurer").GetComponent<SpriteRenderer>().sortingLayerName = "Text";
                }
                if (blip < 100 && blip >= 55)
                {
                    GameObject.Find("Yellow_right_page").transform.RotateAround(new Vector3(middle, 0, 0), new Vector3(0, 1, 0), 4f);
                }
                if (blip == 100)
                {
                    SceneManager.LoadScene(puzzle_level);
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                }
                blip++;
            }
            GameObject.FindGameObjectWithTag("Paper").GetComponent<SpriteRenderer>().color = new Color(1f, 1f, 1f, opacity * 0.01f);
            if (my_turn)
            {
                if (Input.GetKeyDown(buttons[9]))
                {
                    if (Input.GetKey(buttons[3]) && !Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1]))
                    {
                        if (my_grid_pos[0] + 1 < grid_width && grid[my_grid_pos[0] + 1][my_grid_pos[1]])
                        {
                            my_grid_pos[0] += 1;
                            moving = true;
                            my_turn = false;
                            animator.SetFloat("Direction", 4f);
                            move_direction = 0;
                        }
                    }
                    else if (Input.GetKey(buttons[0]) && !Input.GetKey(buttons[2]) && !Input.GetKey(buttons[3]))
                    {
                        if (my_grid_pos[1] - 1 >= 0 && grid[my_grid_pos[0]][my_grid_pos[1] - 1])
                        {
                            my_grid_pos[1] -= 1;
                            moving = true;
                            my_turn = false;
                            animator.SetFloat("Direction", 1f);
                            move_direction = 1;
                        }
                    }
                    else if (Input.GetKey(buttons[1]) && !Input.GetKey(buttons[2]) && !Input.GetKey(buttons[3]))
                    {
                        if (my_grid_pos[1] + 1 < grid_length && grid[my_grid_pos[0]][my_grid_pos[1] + 1])
                        {
                            my_grid_pos[1] += 1;
                            moving = true;
                            my_turn = false;
                            animator.SetFloat("Direction", 2f);
                            move_direction = 2;
                        }
                    }
                    else if (Input.GetKey(buttons[2]) && !Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1]))
                    {
                        if (my_grid_pos[0] - 1 >= 0 && grid[my_grid_pos[0] - 1][my_grid_pos[1]])
                        {
                            my_grid_pos[0] -= 1;
                            moving = true;
                            my_turn = false;
                            animator.SetFloat("Direction", 3f);
                            move_direction = 3;
                        }
                    }
                    else if (!Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1]) && !Input.GetKey(buttons[2]) && !Input.GetKey(buttons[3]))
                    {
                        moving = true;
                        my_turn = false;
                        move_direction = 4;
                        animator.SetFloat("Magnitude", 0);
                    }
                }
            }
            if (moving)
            {
                if (count < 28)
                {
                    count++;
                    if (move_direction != 4)
                    {
                        animator.SetFloat("Magnitude", 1f);
                    }
                    else
                    {
                        count = 28;
                    }
                    if (move_direction == 0)
                    {
                        transform.position += new Vector3(0.02f, 0, 0);
                    }
                    if (move_direction == 1)
                    {
                        transform.position += new Vector3(0, 0.02f, 0);
                    }
                    if (move_direction == 2)
                    {
                        transform.position += new Vector3(0, -0.02f, 0);
                    }
                    if (move_direction == 3)
                    {
                        transform.position += new Vector3(-0.02f, 0, 0);
                    }
                }
                else
                {
                    moving = false;
                    count = 0;
                    animator.SetFloat("Magnitude", 0);
                    getting_moved = true;
                    tiles_turn = 0;
                    for (i = 0; i < grid_width; i++)
                    {
                        for (j = 0; j < grid_length; j++)
                        {
                            grid[i][j] = false;
                        }
                    }
                }
            }
            if (getting_moved)
            {
                tiles_turn++;
                if (count < 28)
                {
                    if (up_columns[my_grid_pos[0]])
                    {
                        transform.position += new Vector3(0, 0.02f, 0);
                        if (my_grid_pos[1] == 0)
                        {
                            transform.position += new Vector3(0, -0.52f, 0);
                            transform.Rotate(0, 0, 15);
                            gameObject.GetComponent<SpriteRenderer>().sortingOrder = 1;
                        }
                    }
                    else
                    {
                        transform.position += new Vector3(0, -0.02f, 0);
                        if (my_grid_pos[1] == grid_length - 1)
                        {
                            transform.position += new Vector3(0, -0.48f, 1);
                            transform.Rotate(0, 0, -15);
                        }
                    }
                }
                count++;
                if (count == 28)
                {
                    getting_moved = false;
                    count = 0;
                    my_turn = true;
                    if ((!up_columns[my_grid_pos[0]] && my_grid_pos[1] == grid_length - 1) || (up_columns[my_grid_pos[0]] && my_grid_pos[1] == 0))
                    {
                        blip = 0;
                        restart = true;
                    }
                    if (up_columns[my_grid_pos[0]])
                    {
                        my_grid_pos[1] -= 1;
                    }
                    else
                    {
                        my_grid_pos[1] += 1;
                    }
                    if (my_grid_pos[0] == finish_pos[0] && my_grid_pos[1] == finish_pos[1])
                    {
                        FindObjectOfType<Log>().puzzles_completed[1][puzzle_index] = true;
                        win = true;
                        blip = 0;
                    }
                }
            }
        }
    }
}