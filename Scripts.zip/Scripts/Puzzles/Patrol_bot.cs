﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Patrol_bot : MonoBehaviour
{
    public List<int> directions; //1 = up,2=right,3=down,4=left
    public int turn;
    public int total_turns;
    public int x_pos;
    public int y_pos;
    private bool caught;
    private int i;
    private int count;
    public GameObject exclamation;
    void FixedUpdate()
    {
        Player_patrol_move player_script = FindObjectOfType<Player_patrol_move>();
        if(player_script.my_grid_pos[1] > y_pos)
        {
            gameObject.GetComponent<SpriteRenderer>().sortingOrder = 5;
        }
        else
        {
            gameObject.GetComponent<SpriteRenderer>().sortingOrder = 7;
        }
        if(player_script.moving)
        {
            if(directions[turn] == 1)
            {
                if (!(y_pos - 1 == player_script.my_grid_pos[1] && x_pos == player_script.my_grid_pos[0]))
                {
                    transform.position += new Vector3(0, 0.02f, 0);
                }
            }
            if (directions[turn] == 2)
            {
                    if (!(x_pos + 1 == player_script.my_grid_pos[0] && y_pos == player_script.my_grid_pos[1]))
                    {
                        transform.position += new Vector3(0.02f, 0, 0);
                    }
            }
            if (directions[turn] == 3)
            {
                if (!(y_pos + 1 == player_script.my_grid_pos[1] && x_pos == player_script.my_grid_pos[0]))
                {
                    transform.position += new Vector3(0, -0.02f, 0);
                }
            }
            if (directions[turn] == 4)
            {
                if (!(x_pos - 1 == player_script.my_grid_pos[0] && y_pos == player_script.my_grid_pos[1]))
                {
                    transform.position += new Vector3(-0.02f, 0, 0);
                }
            }
        }
        if(player_script.count == 28)
        {
            if (directions[turn] == 1)
            {
                y_pos -= 1;
            }
            if (directions[turn] == 2)
            {
                x_pos += 1;
            }
            if (directions[turn] == 3)
            {
                y_pos += 1;
            }
            if (directions[turn] == 4)
            {
                x_pos -= 1;
            }
            if (player_script.my_grid_pos[0] == x_pos || player_script.my_grid_pos[1] == y_pos)
            {
                caught = true;
            }
            else
            {
                caught = false;
            }
            if(caught)
            {
                Instantiate(exclamation,new Vector3(transform.position.x,transform.position.y + 1f,0),Quaternion.identity);
            }
            turn++;
            if(turn == total_turns)
            {
                turn = 0;
            }
        }
        if(caught)
        {
            if(count == 20)
            {
                player_script.restart = true;
            }
            count++;
        }
    }
}
