﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_ground_move : MonoBehaviour
{
    public List<int> my_grid_pos = new List<int>();
    private List<int> initial_pos = new List<int>();
    public bool moving;
    public int cycling;
    private int x_di;
    private int y_di;
    private int x_di2;
    private int y_di2;
    public float count;
    private int count2 = 1;
    private int count3 = 0;
    private int tile = 0;
    public bool edge;
    public bool player_touch;
    public GameObject gap;
    public Vector3 start_pos;
    private float speed_storage;
    private float speed;
    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            player_touch = true;
        }
    }
    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player") && cycling == 0)
        {
            player_touch = false;
        }
    }
    private void Start()
    {
        initial_pos.Add (my_grid_pos[0]);
        initial_pos.Add (my_grid_pos[1]);
        start_pos.x = transform.position.x;
        start_pos.y = transform.position.y;
        start_pos.z =0;
        speed = FindObjectOfType<Geomancer_attack_pattern>().speed;
    }
    void FixedUpdate()
    {
        if ((count2 * speed)% 56 == 0)
        {
            if (FindObjectOfType<Geomancer_attack_pattern>().retile != true)
            {
                if (edge)
                {
                    x_di2 = x_di;
                    y_di2 = y_di;
                    count3 = 3;
                }
                if(cycling == 0 && !edge)
                {
                    my_grid_pos[0] = Mathf.RoundToInt((transform.position.x + 2.28f) / 0.56f);
                    my_grid_pos[1] = 8 - Mathf.RoundToInt((transform.position.y + 2.28f) / 0.56f);
                }
                else if(!edge)
                {
                    if (tile == 1)
                    {
                        my_grid_pos[1] --;
                    }
                    else if (tile == 2)
                    {
                        my_grid_pos[0] ++;
                        my_grid_pos[1] --;
                    }
                    else if (tile == 3)
                    {
                        my_grid_pos[0] ++;
                    }
                    else if (tile == 4)
                    {
                        my_grid_pos[0] ++;
                        my_grid_pos[1] ++;
                    }
                    else if (tile == 5)
                    {
                        my_grid_pos[1] ++;
                    }
                    else if (tile == 6)
                    {
                        my_grid_pos[0] --;
                        my_grid_pos[1] ++;
                    }
                    else if (tile == 7)
                    {
                        my_grid_pos[0] --;
                    }
                    else if (tile == 8)
                    {
                        my_grid_pos[0] --;
                        my_grid_pos[1] --;
                    }
                    if (my_grid_pos[0] == 8)
                    {
                        my_grid_pos[0] = 1;
                    }
                    else if (my_grid_pos[1] == 8)
                    {
                        my_grid_pos[1] = 1;
                    }
                    else if (my_grid_pos[0] == 0)
                    {
                        my_grid_pos[0] = 7;
                    }
                    else if (my_grid_pos[1] == 0)
                    {
                        my_grid_pos[1] = 7;
                    }
                }
                count2 = 0;
                tile = FindObjectOfType<Geomancer_attack_pattern>().tiles[my_grid_pos[0]][my_grid_pos[1]];
                speed = FindObjectOfType<Geomancer_attack_pattern>().speed;
                if(cycling == 0)
                {
                    speed_storage = speed;
                }
                if (tile == 0)
                {
                    x_di = 0;
                    y_di = 0;
                }
                else if (tile == 1)
                {
                    y_di = 1;
                    x_di = 0;
                }
                else if (tile == 2)
                {
                    x_di = 1;
                    y_di = 1;
                }
                else if (tile == 3)
                {
                    x_di = 1;
                    y_di = 0;
                }
                else if (tile == 4)
                {
                    x_di = 1;
                    y_di = -1;
                }
                else if (tile == 5)
                {
                    x_di = 0;
                    y_di = -1;
                }
                else if (tile == 6)
                {
                    x_di = -1;
                    y_di = -1;
                }
                else if (tile == 7)
                {
                    x_di = -1;
                    y_di = 0;
                }
                else if (tile == 8)
                {
                    x_di = -1;
                    y_di = 1;
                }
            }
            else
            {
                transform.position = start_pos;
                my_grid_pos[0] = initial_pos[0];
                my_grid_pos[1] = initial_pos[1];
                count3 = 0;
                y_di = 0;
                x_di = 0;
                x_di2 = 0;
                y_di2 = 0;
                if (player_touch && cycling != 0)
                {
                    GameObject.Find("Player").transform.position = transform.position + new Vector3(0, 0.42f, 0);
                }
                cycling = 0;
            }
        }
        if (count3 > 0 && edge)
        {
            transform.position += new Vector3(-x_di2 * 0.56f / 3, -y_di2 * 0.56f / 3, 0);
            count3--;
        }
        if (tile != 0)
        {
            transform.position += speed * new Vector3(0.01f * x_di, 0.01f * y_di, 0);
            if(player_touch)
            {
                GameObject.Find("Player").transform.position += speed * new Vector3(0.01f * x_di, 0.01f * y_di, 0);
            }
        }
        count2++;
        if (cycling == 1 && count2 != 29)
        {
            if (count == 0)
            {
                gameObject.GetComponent<SpriteRenderer>().sortingOrder = 1;
                gameObject.GetComponent<BoxCollider2D>().enabled = false;
                move_amount space = Instantiate(gap, transform.position, Quaternion.identity).GetComponent<move_amount>();
                space.x_mod = x_di * 0.01f * speed_storage;
                space.y_mod = y_di * 0.01f * speed_storage;
                if (player_touch)
                {
                    GameObject.Find("Player").GetComponent<BoxCollider2D>().enabled = false;
                    FindObjectOfType<Move>().being_moved = true;
                }
            }
            if (count < 16 / speed_storage)
            {
                transform.position += speed_storage / 2 * new Vector3(0, -1f, 0);
                count++;
            }
            else 
            {
                transform.position += new Vector3(x_di2 * 3.92f, y_di2 * 3.92f, 0);
                cycling = 2;
                count = 0;
            }
            if (player_touch)
            {
                GameObject.Find("Player").transform.position = transform.position + new Vector3(0, 0.42f, 0);
            }
        }
        else if (cycling == 2)
        { 
            if (count < 16 / speed_storage)
            {
                transform.position += speed_storage / 2* new Vector3(0, 1f, 0);
                count++;
            }
            else
            {
                gameObject.GetComponent<BoxCollider2D>().enabled = true;
                if (player_touch)
                {
                    GameObject.Find("Player").GetComponent<BoxCollider2D>().enabled = true;
                    FindObjectOfType<Move>().being_moved = false;
                }
                gameObject.GetComponent<SpriteRenderer>().sortingOrder = 2;
                count = 0;
                cycling = 0;
                x_di2 = 0;
                y_di2 = 0;
            }
            if (player_touch)
            {
                GameObject.Find("Player").transform.position = transform.position + new Vector3(0, 0.42f, 0);
            }
        }
        else if(!edge)
        {
            if (transform.position.x >= 1.96f)
            {
                cycling = 1;
                x_di2 = -1;
            }
            if (transform.position.x <= -1.96f)
            {
                cycling = 1;
                x_di2 = 1;
            }
            if (transform.position.y >= 1.96f)
            {
                cycling = 1;
                y_di2 = -1;
            }
            if (transform.position.y <= -1.96f)
            {
                cycling = 1;
                y_di2 = 1;
            }
        }
    }
}
