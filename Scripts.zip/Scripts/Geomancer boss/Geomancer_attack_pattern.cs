﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Geomancer_attack_pattern : MonoBehaviour
{
    public List<List<int>> tiles = new List<List<int>>();
    private int i, j;
    public bool transitioning;
    public bool retile;
    public float speed;
    public int attack_phase = 1;
    public int count;
    private void Start()
    {
        for (i = 0; i < 9; i++)
        {
            List<int> list1 = new List<int>();
            for (j = 0; j < 9; j++)
            {
                list1.Add(0);
            }
            tiles.Add(list1);
        }
        for(i = 0; i < 9; i++)
        {
            tiles[i][0] = 3;
            tiles[i][1] = 7;
            tiles[i][2] = 3;
            tiles[i][3] =7;
            tiles[i][4] = 3;
            tiles[i][5] = 7;
            tiles[i][6] = 3;
            tiles[i][7] = 7;
            tiles[i][8] = 3;
        }
    }
    void FixedUpdate()
    {
        if(attack_phase == 1)
        {
            for (i = 0; i < 9; i++)
            {
                tiles[i][0] = 3;
                tiles[i][1] = 7;
                tiles[i][2] = 3;
                tiles[i][3] = 7;
                tiles[i][4] = 3;
                tiles[i][5] = 7;
                tiles[i][6] = 3;
                tiles[i][7] = 7;
                tiles[i][8] = 3;
            }
            count++;
            if (count == 500)
            {
                transitioning = true;
            }
        }
        if(attack_phase == 2)
        {
            if (count == 0)
            {
                for (i = 0; i < 9; i++)
                {
                    tiles[i][0] = 4;
                    tiles[i][1] = 4;
                    tiles[i][2] = 4;
                    tiles[i][3] = 4;
                    tiles[i][4] = 4;
                    tiles[i][5] = 4;
                    tiles[i][6] = 4;
                    tiles[i][7] = 4;
                    tiles[i][8] = 4;
                }
            }
            if(count == 392)
            {
                for (i = 0; i < 9; i++)
                {
                    tiles[i][0] = 8;
                    tiles[i][1] = 8;
                    tiles[i][2] = 8;
                    tiles[i][3] = 8;
                    tiles[i][4] = 8;
                    tiles[i][5] = 8;
                    tiles[i][6] = 8;
                    tiles[i][7] = 8;
                    tiles[i][8] = 8;
                }
            }
            count++;
            if(count == 784)
            {
                transitioning = true;
            }
        }
        if(attack_phase == 3)
        {
            for (i = 0; i < 9; i++)
            {
                tiles[i][0] = 0;
                tiles[i][1] = 0;
                tiles[i][2] = 0;
                tiles[i][3] = 0;
                tiles[i][4] = 0;
                tiles[i][5] = 0;
                tiles[i][6] = 0;
                tiles[i][7] = 0;
                tiles[i][8] = 0;
            }
            count++;
            if (count == 500)
            {
                transitioning = true;
            }
        }
        if(transitioning)
        {
            retile = true;
            attack_phase++;
            count = 0;
            transitioning = false;
        }
        if(retile)
        {
            for (i = 0; i < 9; i++)
            {
                for (j = 0;j < 9; j++)
                {
                    tiles[i][j] = 0;
                }
            }
            retile = false;
        }
    }
}
