﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rope : MonoBehaviour
{
    public int spinning;
    public GameObject centre;
    public Transform neck_pos;
    public Rigidbody2D rb;
    public Rope child_rope;
    public int speed = 1;
    public int count;
    private void Start()
    {
        neck_pos = GameObject.Find("Neck").transform;
    }
    private void FixedUpdate()
    {
        if (spinning == 2 && count < 80)
        {
            if(centre.transform.rotation.eulerAngles.z <= 90) //Moves the rope segment in the appropriate direction through the centre of the rope
            {//Makes sure the rope won't be thrown too far away form it's middle
                rb.velocity = 0.5f*10.475f * new Vector3(-Mathf.Abs(Mathf.Sin(centre.transform.rotation.eulerAngles.z*Mathf.Deg2Rad)), Mathf.Abs(Mathf.Cos(centre.transform.rotation.eulerAngles.z * Mathf.Deg2Rad)), 0);
            }
            else if(centre.transform.rotation.eulerAngles.z > 90 && centre.transform.rotation.eulerAngles.z <= 180)
            {
                rb.velocity = 0.5f * -10.475f * new Vector3(Mathf.Abs(Mathf.Sin(centre.transform.rotation.eulerAngles.z * Mathf.Deg2Rad)), Mathf.Abs(Mathf.Cos(centre.transform.rotation.eulerAngles.z * Mathf.Deg2Rad)), 0);
            }
            else if(centre.transform.eulerAngles.z > 180 && centre.transform.rotation.eulerAngles.z <= 270)
            {

                rb.velocity = 0.5f * 10.475f * new Vector3(Mathf.Abs(Mathf.Sin(centre.transform.rotation.eulerAngles.z * Mathf.Deg2Rad)), -Mathf.Abs(Mathf.Cos(centre.transform.rotation.eulerAngles.z * Mathf.Deg2Rad)), 0);
            }
            else
            {
                rb.velocity = 0.5f * 10.475f * new Vector3(Mathf.Abs(Mathf.Sin(centre.transform.rotation.eulerAngles.z * Mathf.Deg2Rad)), Mathf.Abs(Mathf.Cos(centre.transform.rotation.eulerAngles.z * Mathf.Deg2Rad)), 0);
            }
            count++;
        }
        else if (spinning == 1)
        {
            centre.GetComponent<Rope_middle>().speed = 0;
            if (child_rope != null)
            {
                child_rope.spinning = 1; //Makes the next rope segment also circle round the player
            }
            float x_dif = transform.position.x - neck_pos.position.x;
            float y_dif = transform.position.y - neck_pos.position.y;
            if (Mathf.Abs(x_dif) > 0.1 || Mathf.Abs(y_dif) > 0.1)
            {//Makes the rope appear to wrap around the player's neck
                if (Mathf.Abs(x_dif) < Mathf.Abs(y_dif)) //Moves the rope segment towards the player
                {
                    rb.velocity = 2 * new Vector3(-x_dif / Mathf.Abs(y_dif), -y_dif / (Mathf.Abs(y_dif)), 0.0f);
                }
                else
                {
                    rb.velocity = 2 * new Vector3(-x_dif / Mathf.Abs(x_dif), -y_dif / (Mathf.Abs(x_dif)), 0.0f);
                }
                transform.RotateAround(neck_pos.position, new Vector3(0, 0, 1), 3f);//Rotates the rope segment around the player
            }
            else
            {//Destroys the rope segment when the player is close enough
                Destroy(gameObject);
            }
        }
        else if(spinning == 2)
        {
            FindObjectOfType<Rope_middle>().speed = 1;//Makes the rope start spinning once it has been thrown
            rb.velocity = new Vector3(0, 0, 0);//Stops the rope from moving outwards once it has been thrown
            spinning = 3;
        }
    }
}
