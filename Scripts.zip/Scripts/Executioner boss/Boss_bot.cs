﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_bot : MonoBehaviour
{
    public int x_multiplier;
    public int y_multiplier;
    private int count;
    public int destroyed;
    public GameObject laser;
    public GameObject explosion;
    void Update()
    {
        if(destroyed == 11)
        {
            Instantiate(explosion, transform.position + new Vector3(0, 0.16f, 0), Quaternion.Euler(0, 0, Random.Range(0, 360)));//Creates an explosion at a random rotation to show the bot is destroyed
        }
        if(destroyed > 0)
        {
            destroyed--;//Waits a few frames before the object is destroyed
        }
        if(destroyed == 1)
        {
            FindObjectOfType<Executioner_attack_pattern>().Boss_bar_move();
            Destroy(gameObject);
        }
        if(count < 100)
        { 
            gameObject.GetComponent<BoxCollider2D>().enabled = false; //Allows the bot to move through the walls while entering the arena
            transform.position += new Vector3(0.15f * x_multiplier,0.15f * y_multiplier,0);
        }
        else if(count == 100)
        {
            gameObject.GetComponent<BoxCollider2D>().enabled = true;
        }
        else if(destroyed == 0) //Moves the bot in a square pattern if it isn't destroyed
        {
            if (transform.position.x < 10.8 && transform.position.y >= -93.921)//Checks if the bot has reached a certain point and moves it in the according direc
            {
                transform.position += new Vector3(0.135f / 4, 0, 0);
            }
            else if (transform.position.x >= 10.8 && transform.position.y > -102.54)
            {
                transform.position += new Vector3(0, -0.135f / 4, 0);
            }
            else if (transform.position.x > 2.16 && transform.position.y <= -102.54)
            {
                transform.position += new Vector3(-0.135f / 4, 0, 0);
            }
            else if (transform.position.x <= 2.16 && transform.position.y < -93.921)
            {
                transform.position += new Vector3(0, 0.135f/4, 0);
            }
            if(count % 100 == 0)
            {//Fires lasers in four directions every 100 frames
                GameObject laser1 = Instantiate(laser, new Vector3(0.22f,0.16f,0) + transform.position, Quaternion.identity);
                laser1.GetComponent<Laser_bullet>().x_multiplier = 1;
                GameObject laser2 = Instantiate(laser, new Vector3(-0.22f, 0.16f, 0) + transform.position, Quaternion.Euler(0,0,180));
                laser2.GetComponent<Laser_bullet>().x_multiplier = -1;
                GameObject laser3 = Instantiate(laser, transform.position, Quaternion.Euler(0, 0, 90));
                laser3.GetComponent<Laser_bullet>().y_multiplier = -1;
                GameObject laser4 = Instantiate(laser, new Vector3(0, 0.32f, 0) + transform.position, Quaternion.Euler(0, 0, 270));
                laser4.GetComponent<Laser_bullet>().y_multiplier = 1;
            }
        }
        count++;
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player_attack"))//Destroys the bot if the player has hit it once with their attack
        {
            destroyed = 11;
        }
    }
}
