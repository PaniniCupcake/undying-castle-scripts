﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Small_sword_spin : MonoBehaviour
{
    public Rigidbody2D rb;
    private int attacking;
    public float rotation_dif_1;
    public float rotation_dif_2;
    public float rotation;
    private void Start()
    {
        Transform player_pos = GameObject.Find("Player").transform;
        float x_dif = player_pos.position.x - transform.position.x;
        float y_dif = player_pos.position.y - transform.position.y;
        if (transform.position.y >= player_pos.position.y)//Makes the sword face away from the player when it is summoned
        {
            if (transform.position.x > player_pos.position.x)
            {
                transform.Rotate(0, 0, 180 - Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
            }
            if (transform.position.x < player_pos.position.x)
            {
                transform.Rotate(0, 0, 180 + Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
            }
        }
        else
        {
            if (transform.position.x > player_pos.position.x)
            {
                transform.Rotate(0, 0, Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
            }
            if (transform.position.x < player_pos.position.x)
            {
                transform.Rotate(0, 0, 360 - Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
            }
        }
    }
    void FixedUpdate()
    {
        if (attacking == 0)
        {
            transform.Rotate(0, 0, 2);//Spins the sword
            Transform player_pos = GameObject.Find("Player").transform;
            float x_dif = player_pos.position.x - transform.position.x;
            float y_dif = player_pos.position.y - transform.position.y;
            rotation = (transform.rotation.eulerAngles.z - 45 + 360) % 360; //Gives a 45 degree offset as the sprite is drawn at a 45 angle
            if (transform.position.y >= player_pos.position.y)
            {
                rotation_dif_1 = Mathf.Abs(360 - Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
                rotation_dif_2 = Mathf.Abs(Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
            }
            else
            {
                rotation_dif_1 = Mathf.Abs(180 + Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
                rotation_dif_2 = Mathf.Abs(180 - Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
            }
            if (transform.position.x >= player_pos.position.x)
            {
                if (rotation >= -3 + rotation_dif_1 && rotation <= 3 + rotation_dif_1)
                {//Checks if the sword is almost facing the player
                    rb.velocity = 3 * new Vector3(x_dif, y_dif, 0.0f); //Moves the sword towards the player if it facing them
                    attacking = 1; //Stops the sword from spinning 
                    if (transform.position.y >= player_pos.position.y)
                    {//Makes the sword directly face the player once it is almost facing them
                        transform.rotation = Quaternion.Euler(0, 0, 360 - Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
                    }
                    else
                    {
                        transform.rotation = Quaternion.Euler(0, 0, 180 + Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
                    }
                }
            }
            else
            {
                if (rotation >= -3 + rotation_dif_2 && rotation <= 3 + rotation_dif_2)
                {
                    rb.velocity = 3 * new Vector3(x_dif, y_dif, 0.0f);
                    attacking = 1;
                    if (transform.position.y >= player_pos.position.y)
                    {
                        transform.rotation = Quaternion.Euler(0, 0, Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
                    }
                    else
                    {
                        transform.rotation = Quaternion.Euler(0, 0, 180 - Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
                    }
                }
            }
        }
        else
        {
            attacking++;
            if(attacking == 150)
            {//Destroys the sword after it has moved for enough
                Destroy(gameObject);
            }
        }
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }//Damages the player if it hits them
        }
    }
}
