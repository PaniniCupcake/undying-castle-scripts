﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Executioner_setup : MonoBehaviour
{
    public int start_phase;
    void Start()
    {
        FindObjectOfType<Log>().boss = true;
    }
    void FixedUpdate()
    {
        GameObject text_stuff = GameObject.FindWithTag("Text");
        if (text_stuff == null)
        {//Makes sure there is no text before the boss starts attacking
            Executioner_attack_pattern attacks = gameObject.GetComponent<Executioner_attack_pattern>();
            attacks.attack_phase = start_phase;
            GameObject boss_frame = GameObject.Find("Boss_frame");
            boss_frame.GetComponent<SpriteRenderer>().sortingLayerName = "Magic"; //Reveals the boss bar when the boss fight starts
            GameObject boss_bar = GameObject.Find("Boss_bar");
            boss_bar.GetComponent<SpriteRenderer>().sortingLayerName = "Magic";
            Destroy(this);
        }
    }
}
