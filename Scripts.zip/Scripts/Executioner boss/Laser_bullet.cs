﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Laser_bullet : MonoBehaviour
{
    public int x_multiplier = 0;
    public int y_multiplier = 0;
    private int count;
    public Rigidbody2D rb;
    void FixedUpdate()
    {
        rb.velocity = new Vector3(2f * x_multiplier,2 * y_multiplier,0); //Moves the attack in the appropriate direction
        if(count == 300)
        {
            Destroy(gameObject);
        }
        count++;
        if (FindObjectOfType<Executioner_attack_pattern>().transitioning == true)
        {
            Destroy(gameObject);
        }
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
                Destroy(this);
            }//Destroys the attack and damages the player if it hits them
        }
    }
}
