﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Neck : MonoBehaviour
{
    public GameObject noose;
    public GameObject noose2;
    public Transform player_pos;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Rope") && collision.GetComponent<SpriteRenderer>().sortingLayerName == "Magic" &&(FindObjectOfType<Executioner_attack_pattern>().count2 > 100|| FindObjectOfType<Executioner_attack_pattern>().attack_phase != 12))
        {//Checks if a rope has hit the player while it is visible
            collision.GetComponent<Rope>().spinning = 1; //Makes the rope past the player spin around them
            FindObjectOfType<Rope_middle>().speed = 0; //Makes the rope in front of the player stop spinning
            if(GameObject.Find("Noose_taught(Clone)") == null)
            {//Makes the player appear as if they have a rope around their neck if a rope has touched it
                Instantiate(noose,transform.position, Quaternion.identity);
            }
            if(collision.name == "Noose")
            {//Triggers the player being dragged towards the boss
                Instantiate(noose2, transform.position, Quaternion.identity);
            }
            FindObjectOfType<Move>().being_moved = true; //Stops the player from being moved via user input while being roped
            FindObjectOfType<Move>().animator.SetFloat("Magnitude", 0);
            FindObjectOfType<Move>().animator.SetBool("Fast", false);
            FindObjectOfType<Move>().rb.velocity = new Vector3(0, 0, 0);//Cancels the player's existing movement
        }
        if((FindObjectOfType<Executioner_attack_pattern>().count2 <= 100 && FindObjectOfType<Executioner_attack_pattern>().attack_phase == 12))
        {
            FindObjectOfType<Move>().being_moved = false;
        }
    }
    private void FixedUpdate()
    {
        transform.position = player_pos.position + new Vector3(0, 0.15f, 0);
        //Sets the neck hitbox to be in the correct position relative to the player
    }
}
