﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Neck_noose : MonoBehaviour
{
    void Update()
    {
        transform.position = GameObject.Find("Neck").transform.position;
        //Moves the neck noose to be over the neck
    }
}
