﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Small_sword_spin_2 : MonoBehaviour
{
    private float x_dif;
    private float y_dif;
    private int count;
    public Rigidbody2D rb;
    void FixedUpdate()
    {
        Transform player_pos = GameObject.Find("Player").transform;
        x_dif = player_pos.position.x - transform.position.x;
        y_dif = player_pos.position.y - transform.position.y;
        if (count <= 150)
        {//Changes rotation to face the player
            if (transform.position.y >= player_pos.position.y)
            {
                if (transform.position.x > player_pos.position.x)
                {
                    transform.rotation = Quaternion.Euler(0, 0, 360 - Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
                }
                if (transform.position.x < player_pos.position.x)
                {
                    transform.rotation = Quaternion.Euler(0, 0, Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
                }
            }
            else
            {
                if (transform.position.x > player_pos.position.x)
                {
                    transform.rotation = Quaternion.Euler(0, 0, 180 + Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
                }
                if (transform.position.x < player_pos.position.x)
                {
                    transform.rotation = Quaternion.Euler(0, 0, 180 - Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg + 45);
                }
            }
        }
        if(count == 150)
        {//Moves the sword towards the player once a certain number of frames have passed
            rb.velocity = 3 * new Vector3(x_dif, y_dif, 0.0f);
        }
        count++;
        if(count == 300)
        {//Destroys the sword after a certain number of frames have passed
            Destroy(gameObject);
        }
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }//Damages the player if it hits them
        }
    }
}
