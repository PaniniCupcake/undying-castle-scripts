﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stun_halo : MonoBehaviour
{
    private int count = 0;
    void Update()
    {
        if(count == 100)
        {
            Destroy(gameObject);
        }
        count++;
        transform.position = GameObject.Find("Executioner").transform.position + new Vector3(0, 0.7f, 0);
    }
}
