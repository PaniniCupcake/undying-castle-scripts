﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Axe : MonoBehaviour
{
    public Transform executioner_pos;
    private int count;
    public Rigidbody2D rb;
    public bool move_away;
    void Update()
    {
        count++;
        executioner_pos = GameObject.Find("Executioner").transform;
        float x_dif = transform.position.x - executioner_pos.position.x;
        float y_dif = transform.position.y - executioner_pos.position.y;//Finds the position of the axe relative to the boss
        if (move_away)
        {
            if (count == 250)
            {
                Destroy(gameObject);
            }
            transform.position += new Vector3(x_dif / 25f, y_dif / 25f, 0.0f);//Moves the axe away from the boss
            transform.RotateAround(executioner_pos.position, new Vector3(0, 0, 1), -5);//Rotates the axe around the executioner to create a spiral
        }
        else
        {
            if(count > 200)
            {
                transform.RotateAround(new Vector3(6.48f, -98.28f, 0), new Vector3(0, 0, 1), -5);
            }
            if (FindObjectOfType<Executioner_attack_pattern>().attack_phase != 12 && FindObjectOfType<Executioner_attack_pattern>().attack_phase != 5)
            {
                Destroy(gameObject);
            }
        }
        transform.Rotate(0, 0, -2);//Rotates the axe
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
        }
    }
}
