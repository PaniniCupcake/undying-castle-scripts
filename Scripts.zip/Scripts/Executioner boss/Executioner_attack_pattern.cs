﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Executioner_attack_pattern : MonoBehaviour
{
    public int attack_phase;
    private float count;
    public int count2;
    public Animator animator;
    public Transform player_pos;
    public Rigidbody2D rb;
    public GameObject spinbox;
    public bool transitioning;
    public int stunned = -150;
    public GameObject sword;
    public GameObject sword2;
    public GameObject sword3;
    public GameObject stun;
    public GameObject rope;
    public GameObject bot;
    public GameObject axe;
    public GameObject axe2;
    public GameObject boss_bar_part;
    public int health = 3;
    public int noose_timer = -1;
    public float x_dif;
    public float y_dif;
    public bool rope_moving = true;
    private float bar_position = 9.696f;
    public GameObject drone_spawn;
    public GameObject final;
    public GameObject pedestal;
    void FixedUpdate()
    {
        x_dif = transform.position.x - player_pos.position.x; //Checks the distance from the boss to the player in both axes
        y_dif = transform.position.y - player_pos.position.y;
        if (attack_phase == 1)
        {
            if (count == 0)
            {
                animator.SetBool("Summon_axe", true);
            }
            if (count == 50)
            {
                animator.SetBool("Axe_nuetral", true);
                animator.SetBool("Walking", true); //Sets the animation to the appropriate position
            }
            count++;
            if (count > 50)
            {
                if (count % 5 == 0)
                {//Moves the boss towards the player in bursts
                    if (Mathf.Abs(x_dif) < Mathf.Abs(y_dif))
                    {
                        rb.velocity = new Vector3(-x_dif / Mathf.Abs(y_dif), -y_dif / (Mathf.Abs(y_dif)), 0.0f);
                    }
                    else
                    {
                        rb.velocity = new Vector3(-x_dif / Mathf.Abs(x_dif), -y_dif / (Mathf.Abs(x_dif)), 0.0f);
                    }
                }
            }
            if (count % 58 == 0 && count > 50)
            {
                Boss_bar_move();
            }
            if(count == 400)
            {
                transitioning = true; //Starts the next attack after a certain number of frames
            }
            if (Mathf.Sqrt(x_dif * x_dif + y_dif * y_dif) <= 0.87)//Checks if the player is in range of the spin attack 
            {
                animator.SetBool("Spinning", true); //Tells the animator that the boss is doing the spin attack
                Instantiate(spinbox, transform.position, Quaternion.identity);//Makes the spin attack damage the player
                rb.velocity = new Vector3(0,0,0); //Stops the boss from moving while doing the spin attack
            }
            else
            {//Stops the spin attack if the player isn't in range
                animator.SetBool("Spinning", false);
            }
        }
        if(attack_phase == 2)
        {
            animator.SetBool("Spinning", true); //Persistently performs the spin attack throughout the phase
            Instantiate(spinbox, transform.position, Quaternion.identity);
            if (Mathf.Abs(x_dif) < Mathf.Abs(y_dif))
            {//Moves the boss towards the player faster as the attack progresses
                rb.velocity = (count / 250) * new Vector3(-x_dif / Mathf.Abs(y_dif), -y_dif / (Mathf.Abs(y_dif)), 0.0f);
            }
            else
            {
                rb.velocity = (count / 250) * new Vector3(-x_dif / Mathf.Abs(x_dif), -y_dif / (Mathf.Abs(x_dif)), 0.0f);
            }
            count++;
            if ((count) % 133 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count == 800)
            {
                transitioning = true;
            }
        }
        if(attack_phase == 3)
        {
            animator.SetBool("Walking", false);
            animator.SetBool("Spinning", false);
            animator.SetBool("Axe_nuetral", false);
            animator.SetBool("Summon_axe", false);
            animator.SetBool("Summon", true);
            if (count % 400 == 0 && count > 200)
            {//Adds swords in specific positions around the player every few frames
                Instantiate(sword, player_pos.position + new Vector3(0.001f, 4, 0), Quaternion.identity);
            }
            if (count % 400 == 50 && count > 200)
            {
                Instantiate(sword, player_pos.position + new Vector3(2, 2, 0), Quaternion.identity);
            }
            if (count % 400 == 100 && count > 200)
            {
                Instantiate(sword, player_pos.position + new Vector3(4, 0.001f, 0), Quaternion.identity);
            }
            if (count % 400 == 150 && count > 200)
            {
                Instantiate(sword, player_pos.position + new Vector3(2, -2, 0), Quaternion.identity);
            }
            if (count % 400 == 200)
            {
                Instantiate(sword, player_pos.position + new Vector3(0.001f, -4, 0), Quaternion.identity);
            }
            if (count % 400 == 250)
            {
                Instantiate(sword, player_pos.position + new Vector3(-2, -2, 0), Quaternion.identity);
            }
            if (count % 400 == 300)
            {
                Instantiate(sword, player_pos.position + new Vector3(-4, 0.001f, 0), Quaternion.identity);
            }
            if (count % 400 == 350)
            {
                Instantiate(sword, player_pos.position + new Vector3(-2, 2, 0), Quaternion.identity);
            }
            if(count % 200 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if(count == 1201)
            {
                transitioning = true;
                animator.SetBool("Summon", false);
            }
            else
            {
                count++;
            }
            rb.bodyType = RigidbodyType2D.Static;
        }
        if (attack_phase == 4)
        {
            if (count == 0)
            {
                animator.SetBool("Summon_axe", true);
            }
            else if (count == 50)
            {
                animator.SetBool("Axe_nuetral", true);
                animator.SetBool("Running", true);
            }
            else if ((count - 50) % 100 == 0)//Ignores the first 50 frames of count
            {//Moves the boss towards the player in fast bursts
                if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                {
                    rb.velocity = new Vector3(-x_dif / (Mathf.Abs(y_dif / 8)), -y_dif / (Mathf.Abs(y_dif) / 8), 0.0f);
                }
                else
                {
                    rb.velocity = new Vector3(-x_dif / (Mathf.Abs(x_dif) / 8), -y_dif / (Mathf.Abs(x_dif) / 8), 0.0f);
                }
            }
            if ((count - 50) % 100 == 50)
            {//Stops the boss from moving after the boss has been chargins for 50 frames
                rb.velocity = new Vector3(0, 0, 0);
            }
            else if (Mathf.Sqrt(x_dif * x_dif + y_dif * y_dif) <= 0.6 && (count -50) % 100 < 50)
            {//Performs the spin attack if the player is close enough
                animator.SetBool("Spinning", true);
                Instantiate(spinbox, transform.position, Quaternion.identity);
                rb.velocity = new Vector3(0, 0, 0);//Stops the charge
            }
            else
            {
                animator.SetBool("Spinning", false);
            }
            if (health == 0)
            {
                if (transform.position.x > 6.49 || transform.position.x < 6.47 || transform.position.y < -98.29 || transform.position.y > -98.27)
                {//Moves the boss back into the middle of the arena after it has been damaged enough
                    rb.velocity = new Vector3(6.48f-transform.position.x, -98.28f - transform.position.y, 0);
                }
                else
                {//Moves onto the next attack phase after the boss is in the middle
                    transitioning = true;
                }
            }
            else if(stunned <= 0)
            {
                count++; //Allows the boss to start charging again after it has been stunned for 100 frames
            }
            if(stunned == 0)
            {//Destroys the stunned halo if the boss has been hit
                if(FindObjectOfType<Stun_halo>() != null)
                {
                    Destroy(FindObjectOfType<Stun_halo>().gameObject);
                }
            }
            if(stunned > -150)
            {
                stunned--; //Counts down the amount of time the boss will remain stunned or unable to be stunned again for
            }
            if (stunned == -150 && (count-50) % 100 > 10 &&(transform.position.x <= -0.256 || transform.position.x >= 13.22|| transform.position.y <= -105.2 || transform.position.y >= -91.45))
            {//Stuns the boss if they hit a wall and have not been stunned for a certain number of frames
                rb.velocity = new Vector3(0, 0, 0); //Stops the boss from moving while it is stunned
                stunned = 100;//Starts a countdown for how long the boss will be stunned for
                Instantiate(stun, transform.position + new Vector3(0, 0.7f, 0), Quaternion.identity);//Creates a stun halo
                count = 101;//Sets the player to not charge for several frames after being stunned
            }
        }
        if(attack_phase == 5)
        {
            rb.velocity = new Vector3(0, 0, 0);
            if (count == 0)
            {
                Instantiate(axe2, new Vector3(0, -92.34f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(1.08f, -93.42f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(0, -105.3f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(1.08f, -104.22f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(12.96f, -105.3f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(12.96f, -92.34f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(11.88f, -104.22f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(11.88f, -92.34f, 0), Quaternion.identity);
            }
            if (count < 100)
            {
                animator.SetBool("Running", false);
                animator.SetBool("Spinning", false);
                animator.SetBool("Axe_nuetral", false);
                animator.SetBool("Summon_axe", false);
                animator.SetBool("Summon_rope", true);
                count++;
            }
            if(count == 100)
            {//Throws a rope once the animation has finished changing
                Instantiate(rope, transform.position + new Vector3(0.2f,0.32f,0), Quaternion.identity);
                count++;
            }
            if(GameObject.Find("Rope_joint(Clone)") != null && (GameObject.Find("Noose_taught(Clone)")==null&&GameObject.Find("Noose_taught2(Clone)") == null))
            {//Allows the attack to reach its end while the rope is being used and the player is not caught in it
                count2++;
                if(count2 % 166 == 0 && count != 0)
                {
                    Boss_bar_move();
                }
            }
            else if(GameObject.Find("Rope_joint(Clone)") == null && count > 100)
            {//Checks if there is no rope and the original rope has been thrown
                count++;
                if(count %50 == 0)
                {//Throws a new rope a few frames after an old one has been destroyed
                    Instantiate(rope, transform.position + new Vector3(0.2f, 0.32f, 0), Quaternion.identity);
                }
            }
            if (Mathf.Sqrt(x_dif * x_dif + y_dif * y_dif) <= 0.87)
            {
                animator.SetBool("Spinning", true);
                Instantiate(spinbox, transform.position, Quaternion.identity);
                rb.velocity = new Vector3(0, 0, 0);
                //Destroys all parts of the rope once the spin attack has been performed
                if (GameObject.Find("Noose_taught2(Clone)") != null)
                {
                    Destroy(GameObject.Find("Noose_taught2(Clone)"));
                }
                if (GameObject.Find("Noose_taught(Clone)") != null)
                {
                    Destroy(GameObject.Find("Noose_taught(Clone)"));
                }
                if (GameObject.Find("Rope_joint(Clone)") != null)
                {
                    Destroy(GameObject.Find("Rope_joint(Clone)"));
                }
                FindObjectOfType<Move>().being_moved = false; //Allows the player to move again
                count = 201;//Resets the count to allow for a pause before a new rope is thrown
            }
            else
            {
                animator.SetBool("Spinning", false);
            }
            if (GameObject.Find("Noose_taught2(Clone)") != null)
            {//Instructs the code to wait a few frames when they are caught before pulling the player towards it
                if(noose_timer == -1)
                {
                    noose_timer = 0;
                }
            }
            else
            {
                noose_timer = -1;//Stops the player from being pulled once they are no longer caught
            }
            if (noose_timer == 10)
            {//Pulls the player towards the boss
                GameObject.Find("Player").GetComponent<Rigidbody2D>().velocity = new Vector3(x_dif * 4, y_dif * 4, 0);
            }
            else if(noose_timer != -1)
            {
                noose_timer++;
            }
            if(count2 == 1000)
            {
                Instantiate(drone_spawn,new Vector3(6.49f, -103.52f,0), Quaternion.identity);
                transitioning = true;
                Destroy(GameObject.Find("Rope_joint(Clone)"));//Destroys the rope once the attack is finished
            }
            rb.bodyType = RigidbodyType2D.Static;
        }
        if(attack_phase == 6 && GameObject.FindWithTag("Text") == null)
        {
            if(count == 0)
            {//Instantiates several bots that move into the arena
                animator.SetBool("Summon_rope", false);
                GameObject bot1 = Instantiate(bot, new Vector3(-12.84f, -78.92f, 0), Quaternion.identity);
                bot1.GetComponent<Boss_bot>().x_multiplier = 1; //Sets each bot to move from their position in a particular direction
                bot1.GetComponent<Boss_bot>().y_multiplier = -1;
                GameObject bot2 = Instantiate(bot, new Vector3(6.48f, -78.92f, 0), Quaternion.identity);
                bot2.GetComponent<Boss_bot>().y_multiplier = -1;
                GameObject bot3 = Instantiate(bot, new Vector3(25.8f, -78.92f, 0), Quaternion.identity);
                bot3.GetComponent<Boss_bot>().x_multiplier = -1;
                bot3.GetComponent<Boss_bot>().y_multiplier = -1;
                GameObject bot4 = Instantiate(bot, new Vector3(25.8f, -98.24f, 0), Quaternion.identity);
                bot4.GetComponent<Boss_bot>().x_multiplier = -1;
                GameObject bot5 = Instantiate(bot, new Vector3(25.8f, -117.56f, 0), Quaternion.identity);
                bot5.GetComponent<Boss_bot>().x_multiplier = -1;
                bot5.GetComponent<Boss_bot>().y_multiplier = 1;
                GameObject bot6 = Instantiate(bot, new Vector3(6.48f, -117.56f, 0), Quaternion.identity);
                bot6.GetComponent<Boss_bot>().y_multiplier = 1;
                GameObject bot7 = Instantiate(bot, new Vector3(-12.84f, -117.56f, 0), Quaternion.identity);
                bot7.GetComponent<Boss_bot>().x_multiplier = 1;
                bot7.GetComponent<Boss_bot>().y_multiplier = 1;
                GameObject bot8 = Instantiate(bot, new Vector3(-12.84f, -98.24f, 0), Quaternion.identity);
                bot8.GetComponent<Boss_bot>().x_multiplier = 1;
                count++;
            }
            if(GameObject.Find("Boss_bot(Clone)")==null)
            {//Checks that all bots are destroyed
                transitioning = true;
            }
            rb.bodyType = RigidbodyType2D.Static;
        }
        if(attack_phase == 7)
        {
            animator.SetBool("Summon", true);
            if ((count-100) % 200 == 0 && count > 0)
            {//Instantiates 8 swords at 45 degree angles away the player every 200 frames
                Instantiate(sword2, player_pos.position + new Vector3(0.001f, 4, 0), Quaternion.identity);
                Instantiate(sword2, player_pos.position + new Vector3(2, 2, 0), Quaternion.identity);
                Instantiate(sword2, player_pos.position + new Vector3(4, 0.001f, 0), Quaternion.identity);
                Instantiate(sword2, player_pos.position + new Vector3(2, -2, 0), Quaternion.identity);
                Instantiate(sword2, player_pos.position + new Vector3(0.001f, -4, 0), Quaternion.identity);
                Instantiate(sword2, player_pos.position + new Vector3(-2, -2, 0), Quaternion.identity);
                Instantiate(sword2, player_pos.position + new Vector3(-4, 0.001f, 0), Quaternion.identity);
                Instantiate(sword2, player_pos.position + new Vector3(-2, 2, 0), Quaternion.identity);
            }
            if (count % 200 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count == 1201)
            {
                transitioning = true;
            }
            else { count++; }
            rb.bodyType = RigidbodyType2D.Static;
        }
        if(attack_phase == 8)
        {//Repeats phase 5, but moves the boss towards the player
            if (count < 100)
            {
                animator.SetBool("Summon_rope", true);
                animator.SetBool("Summon", false);
                animator.SetBool("Walking", true);
                count++;
            }
            if (count > 50)
            {//Moves the boss towards the player
                if (count2 % 5 == 0)
                {
                    if (Mathf.Abs(x_dif) < Mathf.Abs(y_dif))
                    {
                        rb.velocity = new Vector3(-x_dif / Mathf.Abs(y_dif), -y_dif / (Mathf.Abs(y_dif)), 0.0f);
                    }
                    else
                    {
                        rb.velocity = new Vector3(-x_dif / Mathf.Abs(x_dif), -y_dif / (Mathf.Abs(x_dif)), 0.0f);
                    }
                }
            }
            if (count == 100)
            {
                Instantiate(rope, transform.position + new Vector3(0.2f, 0.32f, 0), Quaternion.identity);
                count++;
            }
            if (GameObject.Find("Rope_joint(Clone)") != null && (GameObject.Find("Noose_taught(Clone)") == null && GameObject.Find("Noose_taught2(Clone)") == null))
            {
                count2++;
                if (count2 % 166 == 0 && count != 0)
                {
                    Boss_bar_move();
                }
            }
            else if (GameObject.Find("Rope_joint(Clone)") == null && count > 100)
            {
                count++;
                if (count % 50 == 0)
                {
                    Instantiate(rope, transform.position + new Vector3(0.2f, 0.32f, 0), Quaternion.identity);
                }
            }
            if (Mathf.Sqrt(x_dif * x_dif + y_dif * y_dif) <= 0.87)
            {
                animator.SetBool("Spinning", true);
                Instantiate(spinbox, transform.position, Quaternion.identity);

                if (GameObject.Find("Noose_taught2(Clone)") != null)
                {
                    Destroy(GameObject.Find("Noose_taught2(Clone)"));
                }
                if (GameObject.Find("Noose_taught(Clone)") != null)
                {
                    Destroy(GameObject.Find("Noose_taught(Clone)"));
                }
                if (GameObject.Find("Rope_joint(Clone)") != null)
                {
                    Destroy(GameObject.Find("Rope_joint(Clone)"));
                }
                FindObjectOfType<Move>().being_moved = false;
                count = 201;
            }
            else
            {
                animator.SetBool("Spinning", false);
            }
            if (GameObject.Find("Noose_taught2(Clone)") != null)
            {
                rb.velocity = new Vector3(0, 0, 0);
                if (noose_timer == -1)
                {
                    noose_timer = 0;
                }
            }
            else
            {
                noose_timer = -1;
            }
            if (noose_timer == 10)
            {
                GameObject.Find("Player").GetComponent<Rigidbody2D>().velocity = new Vector3(x_dif * 4, y_dif * 4, 0);
            }
            else if (noose_timer != -1)
            {
                noose_timer++;
            }
            if (count2 == 1000)
            {
                transitioning = true;
                Destroy(GameObject.Find("Rope_joint(Clone)"));
            }
        }
        if(attack_phase == 10)
        {//Repeats phase 5, but slightly homes in on the player
            if (count == 0)
            {
                animator.SetBool("Walking", false);
                animator.SetBool("Summon_axe", true);
            }
            else if (count == 50)
            {
                animator.SetBool("Axe_nuetral", true);
                animator.SetBool("Running", true);
            }
            else if ((count - 50) % 100 == 0)
            {
                if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                {
                    rb.velocity = new Vector3(-x_dif / (Mathf.Abs(y_dif / 8)), -y_dif / (Mathf.Abs(y_dif) / 8), 0.0f);
                }
                else
                {
                    rb.velocity = new Vector3(-x_dif / (Mathf.Abs(x_dif) / 8), -y_dif / (Mathf.Abs(x_dif) / 8), 0.0f);
                }
            }
            else if((count-50) % 100 <50 && stunned == -150 && !transitioning && count > 50)
            {//Makes sure the boss is charging when its direction is adjusted
                if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))//Adjusts the boss' direciton to slightly home in on the player
                {
                    rb.velocity = new Vector3(rb.velocity.x-x_dif / (Mathf.Abs(y_dif))/3, rb.velocity.y - y_dif / (Mathf.Abs(y_dif)) / 3, 0.0f);
                }
                else
                {
                    rb.velocity = new Vector3(rb.velocity.x - x_dif / (Mathf.Abs(x_dif)) / 3, rb.velocity.y - y_dif / (Mathf.Abs(x_dif)) / 3, 0.0f);
                }
            }
            if ((count - 50) % 100 == 50)
            {
                rb.velocity = new Vector3(0, 0, 0);
            }
            else if (Mathf.Sqrt(x_dif * x_dif + y_dif * y_dif) <= 0.6 && (count - 50) % 100 < 50)
            {
                animator.SetBool("Spinning", true);
                Instantiate(spinbox, transform.position, Quaternion.identity);
                rb.velocity = new Vector3(0, 0, 0);
            }
            else
            {
                animator.SetBool("Spinning", false);
            }
            if (health == 0)
            {
                if (transform.position.x > 6.49 || transform.position.x < 6.47 || transform.position.y < -98.29 || transform.position.y > -98.27)
                {
                    rb.velocity = new Vector3(6.48f - transform.position.x, -98.28f - transform.position.y, 0);
                }
                else
                {
                    transitioning = true;
                }
            }
            else if (stunned <= 0)
            {
                count++;
            }
            if (stunned == 0)
            {
                if (FindObjectOfType<Stun_halo>() != null)
                {
                    Destroy(FindObjectOfType<Stun_halo>().gameObject);
                }
            }
            if (stunned > -150)
            {
                stunned--;
            }
            if (stunned == -150 && (count - 50) % 100 > 10 && (transform.position.x <= -0.256 || transform.position.x >= 13.22 || transform.position.y <= -105.2 || transform.position.y >= -91.45))
            {
                rb.velocity = new Vector3(0, 0, 0);
                stunned = 100;
                Instantiate(stun, transform.position + new Vector3(0, 0.7f, 0), Quaternion.identity);
                count = 101;
            }
        }
        if(attack_phase == 9)
        {
            if (count == 0)
            {
                animator.SetBool("Summon_axe", true);
            }
            if (count == 50)
            {
                animator.SetBool("Axe_nuetral", true);
                animator.SetBool("Walking", true);
                animator.SetBool("Spinning", true);
            }
            if (count > 100)
            {//Moves the boss towards the player while persistently performing the spin attack
                Instantiate(spinbox, transform.position, Quaternion.identity);
                if (Mathf.Abs(x_dif) < Mathf.Abs(y_dif))
                {
                    rb.velocity = 2 * new Vector3(-x_dif / Mathf.Abs(y_dif), -y_dif / (Mathf.Abs(y_dif)), 0.0f);
                }
                else
                {
                    rb.velocity = 2 * new Vector3(-x_dif / Mathf.Abs(x_dif), -y_dif / (Mathf.Abs(x_dif)), 0.0f);
                }
                if (count % 50 == 0)
                {//Throws axes while spinning
                    axe = Instantiate(axe, transform.position + new Vector3(0.1f, 0, 0) / 4, Quaternion.identity);
                    axe.transform.SetParent(transform);
                }
            }
            count++;
            if (count % 200 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count == 1200)
            {
                transitioning = true;
            }
        }
        if (attack_phase == 11)
        {
            animator.SetBool("Running", false);
            animator.SetBool("Spinning", false);
            animator.SetBool("Axe_nuetral", false);
            animator.SetBool("Summon_axe", false);
            animator.SetBool("Summon", true);
            if ((count - 100) % 200 == 0 && count > 0)
            {//Instantiates 8 swords at 45 degree angles away the player every 200 frames
                Instantiate(sword, player_pos.position + new Vector3(0.001f, 4, 0), Quaternion.identity);
                Instantiate(sword, player_pos.position + new Vector3(2, 2, 0), Quaternion.identity);
                Instantiate(sword, player_pos.position + new Vector3(4, 0.001f, 0), Quaternion.identity);
                Instantiate(sword, player_pos.position + new Vector3(2, -2, 0), Quaternion.identity);
                Instantiate(sword, player_pos.position + new Vector3(0.001f, -4, 0), Quaternion.identity);
                Instantiate(sword, player_pos.position + new Vector3(-2, -2, 0), Quaternion.identity);
                Instantiate(sword, player_pos.position + new Vector3(-4, 0.001f, 0), Quaternion.identity);
                Instantiate(sword, player_pos.position + new Vector3(-2, 2, 0), Quaternion.identity);
            }
            if (count % 200 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count == 1201)
            {
                transitioning = true;
            }
            else { count++; }
            rb.bodyType = RigidbodyType2D.Static;
        }
        if(attack_phase == 12)
        {
            if(count == 0)
            {
                rope_moving = false;
                Instantiate(axe2,new Vector3(0, -92.34f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(1.08f, -93.42f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(0, -105.3f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(1.08f, -104.22f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(12.96f, -105.3f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(12.96f, -92.34f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(11.88f, -104.22f, 0), Quaternion.identity);
                Instantiate(axe2, new Vector3(11.88f, -92.34f, 0), Quaternion.identity);
            }
            if (count < 100)
            {
                animator.SetBool("Summon_rope", true);
                animator.SetBool("Summon", false);
                count++;
            }
            if (count % 150 == 0 && count > 0 && count < 1250)
            {
                Instantiate(rope, transform.position + new Vector3(0.2f, 0.32f, 0), Quaternion.identity);
                count++;
            }
            count2++;
            if (Mathf.Sqrt(x_dif * x_dif + y_dif * y_dif) <= 0.87)
            {
                animator.SetBool("Spinning", true);
                Instantiate(spinbox, transform.position, Quaternion.identity);
                FindObjectOfType<Move>().being_moved = false;
                count2 = 0;
                if (GameObject.Find("Noose_taught2(Clone)") != null)
                {
                    Destroy(GameObject.Find("Noose_taught2(Clone)"));
                }
                if (GameObject.Find("Noose_taught(Clone)") != null)
                {
                    Destroy(GameObject.Find("Noose_taught(Clone)"));
                }
            }
            else
            {
                animator.SetBool("Spinning", false);
            }
            if (GameObject.Find("Noose_taught2(Clone)") != null)
            {
                if (noose_timer == -1)
                {
                    noose_timer = 0;
                }
            }
            else
            {
                noose_timer = -1;
            }
            if (noose_timer == 10 && count2 >= 100)
            {
                GameObject.Find("Player").GetComponent<Rigidbody2D>().velocity = new Vector3(x_dif * 4, y_dif * 4, 0);
            }
            else if (noose_timer != -1)
            {
                noose_timer++;
            }
            if (count % 250 == 0 && count != 0 && count <= 1250)
            {
                Boss_bar_move();
            }
            if (count == 1250)
            {
                rope_moving = true;
                Boss_bar_move();
                Boss_bar_move();
            }
            if(count == 1500)
            {
                Boss_bar_move();
            }
            if(count == 1750)
            {
                transitioning = true;
                Boss_bar_move();
            }
            else
            {
                count++;
            }
            rb.bodyType = RigidbodyType2D.Static;
        }
        if (attack_phase == 13)
        {
            if (count == 0)
            {
                animator.SetBool("Summon_rope", false);
                animator.SetBool("Summon_axe", true);
                health = 5;
            }
            else if (count == 50)
            {
                animator.SetBool("Axe_nuetral", true);
                animator.SetBool("Running", true);
            }
            else if ((count - 50) % 85 == 0)
            {
                if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                {
                    rb.velocity = new Vector3(-x_dif / (Mathf.Abs(y_dif / 8)), -y_dif / (Mathf.Abs(y_dif) / 8), 0.0f);
                }
                else
                {
                    rb.velocity = new Vector3(-x_dif / (Mathf.Abs(x_dif) / 8), -y_dif / (Mathf.Abs(x_dif) / 8), 0.0f);
                }
            }
            if ((count - 50) % 85 == 40 && count > 100)
            {
                rb.velocity = new Vector3(0, 0, 0);
                GameObject sword_1 = Instantiate(sword3, transform.position, Quaternion.Euler(0, 0, 0));
                sword_1.GetComponent<Laser_bullet>().x_multiplier = -3;
                sword_1.GetComponent<Laser_bullet>().y_multiplier = -3;
                GameObject sword_2 = Instantiate(sword3, transform.position, Quaternion.Euler(0, 0, 90));
                sword_2.GetComponent<Laser_bullet>().x_multiplier = 3;
                sword_2.GetComponent<Laser_bullet>().y_multiplier = -3;
                GameObject sword_3 = Instantiate(sword3, transform.position, Quaternion.Euler(0, 0, 270));
                sword_3.GetComponent<Laser_bullet>().x_multiplier = -3;
                sword_3.GetComponent<Laser_bullet>().y_multiplier = 3;
                GameObject sword_4 = Instantiate(sword3, transform.position, Quaternion.Euler(0, 0, 180));
                sword_4.GetComponent<Laser_bullet>().x_multiplier = 3;
                sword_4.GetComponent<Laser_bullet>().y_multiplier = 3;
                GameObject sword_5 = Instantiate(sword3, transform.position, Quaternion.Euler(0, 0, 45));
                sword_5.GetComponent<Laser_bullet>().y_multiplier = -3;
                GameObject sword_6 = Instantiate(sword3, transform.position, Quaternion.Euler(0, 0, 225));
                sword_6.GetComponent<Laser_bullet>().y_multiplier = 3;
                GameObject sword_7 = Instantiate(sword3, transform.position, Quaternion.Euler(0, 0, 315));
                sword_7.GetComponent<Laser_bullet>().x_multiplier = -3;
                GameObject sword_8 = Instantiate(sword3, transform.position, Quaternion.Euler(0, 0, 135));
                sword_8.GetComponent<Laser_bullet>().x_multiplier = 3;
            }
            else if (Mathf.Sqrt(x_dif * x_dif + y_dif * y_dif) <= 0.6 && (count - 50) % 100 < 50)
            {
                animator.SetBool("Spinning", true);
                Instantiate(spinbox, transform.position, Quaternion.identity);
                rb.velocity = new Vector3(0, 0, 0);
            }
            else
            {
                animator.SetBool("Spinning", false);
            }
            if (health == 0)
            {
                transitioning = true;
            }
            else if (stunned <= 0)
            {
                count++;
            }
            if (stunned == 0)
            {
                if (FindObjectOfType<Stun_halo>() != null)
                {
                    Destroy(FindObjectOfType<Stun_halo>().gameObject);
                }
            }
            if (stunned > -150)
            {
                stunned--;
            }
            if (stunned == -150 && (count - 50) % 100 > 10 && (transform.position.x <= -0.256 || transform.position.x >= 13.22 || transform.position.y <= -105.2 || transform.position.y >= -91.45))
            {
                rb.velocity = new Vector3(0, 0, 0);
                stunned = 100;
                Instantiate(stun, transform.position + new Vector3(0, 0.7f, 0), Quaternion.identity);
                count = 101;
            }
        }
        if (attack_phase == 14)
        {
            if (count == 0)
            {
                Instantiate(final, new Vector3(6.49f, -103.52f, 0), Quaternion.identity);
                animator.SetBool("Summon_axe", false);
                animator.SetBool("Running", false);
                animator.SetBool("Axe_nuetral", false);
                count++;
            }
            else if(GameObject.FindWithTag("Text") == null)
            {
                animator.SetBool("Teleporting", true);
                count++;
            }
            if(count == 125)
            {
                Destroy(FindObjectOfType<Neck>()); 
                Instantiate(pedestal, transform.position- new Vector3(0,-0.2f,0), Quaternion.identity);
                Destroy(gameObject);
            }
        }
        animator.SetFloat("Player_location", (player_pos.position.y - transform.position.y - 0.1f));
        if (transitioning)
        {
            if (FindObjectOfType<Small_sword_spin>() == null)//Makes sure all swords are gone before starting a new one
            {
                count = 0;//Resets the variables
                count2 = 0;
                health = 3;
                rb.velocity = new Vector3(0, 0, 0);
                attack_phase++;//Starts the next phase
                transitioning = false;
                Boss_bar_move();
                rb.bodyType =   RigidbodyType2D.Dynamic;
            }
        }
        if(transform.position.x < -0.256)
        {
            transform.position = new Vector3(-0.256f, transform.position.y, 0);
        }
        if (transform.position.x > 13.22)
        {
            transform.position = new Vector3(13.22f,transform.position.y, 0);
        }
        if (transform.position.y < -105.2)
        {
            transform.position = new Vector3(transform.position.x, -105.1f, 0);
        }
        if(transform.position.y > -91.47)
        {
            transform.position = new Vector3(transform.position.x, -91.47f, 0);
        }
        if(attack_phase == 2)
        {
            if (transform.position.y < -104.7)
            {
                transform.position = new Vector3(transform.position.x, -104.7f, 0);
            }
            if (transform.position.y > -91.97)
            {
                transform.position = new Vector3(transform.position.x, -91.97f, 0);
            }
        }
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player_attack"))//Checks if the player has attacked the boss
        {
            if (stunned > 0) //Makes sure the boss is stunned while it can be attacked
            {
                health--;
                stunned = 0;
                Boss_bar_move();
            }
        }
    }
    public void Boss_bar_move()
    {
        Instantiate(boss_bar_part, new Vector3(bar_position, -90.324f, 0), Quaternion.identity);
        bar_position -= 0.072f;
    }
}
