﻿    using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rope_middle : MonoBehaviour
{
    public int speed;
    private void Start()
    {
        Transform player_pos = GameObject.Find("Neck").transform;
        float x_dif = player_pos.position.x - transform.position.x;
        float y_dif = player_pos.position.y - transform.position.y;
        if (transform.position.y >= player_pos.position.y)//Makes the rope face in the direction so that it will be thrown towards the player
        {
            if (transform.position.x > player_pos.position.x)
            {
                transform.rotation = Quaternion.Euler(0, 0, 180 - Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
            }
            if (transform.position.x < player_pos.position.x)
            {
                transform.rotation = Quaternion.Euler(0, 0, 180 + Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
            }
        }
        else
        {
            if (transform.position.x > player_pos.position.x)
            {
                transform.rotation = Quaternion.Euler(0, 0, Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
            }
            if (transform.position.x < player_pos.position.x)
            {
                transform.rotation = Quaternion.Euler(0, 0, 360 - Mathf.Atan(Mathf.Abs(x_dif) / Mathf.Abs(y_dif)) * Mathf.Rad2Deg);
            }
        }
    }
    private void FixedUpdate()
    {
        transform.position = GameObject.Find("Executioner").transform.position + new Vector3(0.2f,0.32f,0);
        //Makes the rope be in the correct position relative to the boss
        if (Mathf.Sqrt(FindObjectOfType<Executioner_attack_pattern>().x_dif * FindObjectOfType<Executioner_attack_pattern>().x_dif + FindObjectOfType<Executioner_attack_pattern>().y_dif * FindObjectOfType<Executioner_attack_pattern>().y_dif) <= 0.87)
        {
            Destroy(gameObject);
        }
        if(FindObjectOfType<Executioner_attack_pattern>().rope_moving == true)
        {
            transform.Rotate(0, 0, speed * 1.5f);//Makes the rope spin once the rope has been thrown
        }
        if (FindObjectOfType<Executioner_attack_pattern>().attack_phase != 5 && FindObjectOfType<Executioner_attack_pattern>().attack_phase != 12 && FindObjectOfType<Executioner_attack_pattern>().attack_phase != 8)
        {
            Destroy(gameObject);
        }
    }
    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Rope"))
        {//Makes the rope segment visible once it has passed through the centre
            collision.GetComponent<SpriteRenderer>().sortingLayerName = "Magic";
        }
    }
}
