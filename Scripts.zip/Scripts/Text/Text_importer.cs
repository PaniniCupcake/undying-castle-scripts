﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Text_importer : MonoBehaviour
{
    public List<string> buttons = new List<string>();
    public Text words;
    public Text speaker;
    public Text options;

    public string[] text_Lines;

    public List<string> paragraphs = new List<string>();
    public List<string> speaker_names = new List<string>();
    private int i;
    public int current_paragraph = 0;
    public int text_menu_button = 1;
    public int count;
    public Transform pointer_pos;
    public Transform canvas;
    public float size;
    private bool autoread;
    public GameObject next_file;
    public bool multi_next;
    public float y_modifier;
    private float camera_size;
    private int cooldown = 15;
    public int startup_count = 0;
    public int finish_count = 0;
    void Start()
    {
        FindObjectOfType<Move>().allow_attack = false;
        FindObjectOfType<Move>().allow_movement = false;
        buttons = FindObjectOfType<Keybinds>().buttons;
        camera_size = FindObjectOfType<Camera>().orthographicSize;
        size *= camera_size * 0.125f;
        speaker.text = speaker_names[0];
        canvas.position = new Vector3(0, -0.6f,10) * camera_size + FindObjectOfType<Camera>().transform.position;
        canvas.localScale = new Vector3(0.25f, 0.25f, 0) * camera_size * y_modifier;
        if (startup_count > 0)
        {
            canvas.position -= new Vector3(0, 1.5f, 0) * camera_size * y_modifier;
        }
        if(startup_count == -30)
        {
            canvas.position += new Vector3(0, 0.9f, 0) * camera_size * y_modifier;
        }
    }
    void Update()
    {
        if (finish_count > 1)
        {
            canvas.position -= new Vector3(0, 0.03f, 0) * camera_size * y_modifier;
            finish_count--;
        }    
        else if (finish_count == 1)
        {
            if (next_file != null)
            {
                Instantiate(next_file, canvas.position, Quaternion.identity);                                       
            }
            Destroy(canvas.gameObject);
        }
        else if (startup_count > 0)
        {
            canvas.position += new Vector3(0, 0.03f, 0) * camera_size * y_modifier;
            startup_count--;
        }//Set to 50 for this
        else if (startup_count < 0)
        {//Set to -30 for this
            canvas.position -= new Vector3(0, 0.03f, 0) * camera_size * y_modifier;
            startup_count++;
        }
        else
        {
            if (current_paragraph < paragraphs.Count && count / 5 <= paragraphs[current_paragraph].Length)
            {
                if (count % 5 == 0)
                {
                    words.text = paragraphs[current_paragraph].Substring(0, count / 5);
                    if (current_paragraph > 0)
                    {
                        for (i = 0; i <= 210; i += 35)
                        {
                            if (paragraphs[current_paragraph - 1].Length <= i)
                            {
                                break;
                            }
                        }
                        if (paragraphs[current_paragraph].Length + i <= 210 && speaker_names[current_paragraph] == speaker_names[current_paragraph - 1])
                        {
                            words.text = paragraphs[current_paragraph - 1] + "\n" + paragraphs[current_paragraph].Substring(0, count / 5);
                        }
                    }
                }
                if (count / 5 == paragraphs[current_paragraph].Length)
                {
                    if (autoread)
                    {
                        options.text = " Read \n  \n - Auto \n \n Skip";
                    }
                    else
                    {
                        options.text = " Next \n  \n + Auto \n \n Skip";
                    }
                }
            }
            if (count < 10000)
            {
                count++;
            }
            if (cooldown == 0)
            {
                if (Input.GetKey(buttons[0]) && current_paragraph < paragraphs.Count)
                {
                    if (text_menu_button == 1)
                    {
                        pointer_pos.transform.position += new Vector3(0, -2.4f * size, 0);
                        text_menu_button = 3;
                    }
                    else
                    {
                        pointer_pos.transform.position += new Vector3(0, 1.2f * size, 0);
                        text_menu_button--;
                    }
                    cooldown = 15;
                }
                else if (Input.GetKey(buttons[1]) && current_paragraph < paragraphs.Count)
                {
                    if (text_menu_button == 3)
                    {
                        pointer_pos.transform.position += new Vector3(0, 2.4f * size, 0);
                        text_menu_button = 1;
                    }
                    else
                    {
                        pointer_pos.transform.position += new Vector3(0, -1.2f * size, 0);
                        text_menu_button++;
                    }
                    cooldown = 15;
                }
            }
            if (Input.GetKeyDown(buttons[9]))
            {
                if (text_menu_button == 1)
                {
                    if (count / 5 >= paragraphs[current_paragraph].Length)
                    {
                        if (autoread)
                        {
                            options.text = " Read \n  \n - Auto \n \n Skip";
                        }
                        else
                        {
                            options.text = " Read \n  \n + Auto \n \n Skip";
                        }
                        count = 0;
                        current_paragraph++;
                        speaker.text = speaker_names[current_paragraph];
                    }
                    else
                    {
                        count = paragraphs[current_paragraph].Length * 5;
                    }
                }
                else if (text_menu_button == 2)
                {
                    autoread = !autoread;
                    if (count / 10 >= paragraphs[current_paragraph].Length)
                    {
                        if (autoread)
                        {
                            options.text = " Next \n  \n - Auto \n \n Skip";
                        }
                        else
                        {
                            options.text = " Next \n  \n + Auto \n \n Skip";
                        }
                    }
                    else
                    {
                        if (autoread)
                        {
                            options.text = " Read \n  \n - Auto \n \n Skip";
                        }
                        else
                        {
                            options.text = " Read \n  \n + Auto \n \n Skip";
                        }
                    }
                }
                else
                {
                    if (!multi_next)
                    {
                        finish_count = 50;
                    }
                    else
                    {
                        if (next_file != null)
                        {
                            Instantiate(next_file, canvas.position, Quaternion.identity);
                        }
                        Destroy(canvas.gameObject);
                    }
                }
            }
            if (current_paragraph < paragraphs.Count && autoread && count > paragraphs[current_paragraph].Length * 5 + 60)
            {
                current_paragraph++;
                if (current_paragraph < speaker_names.Count)
                {
                    speaker.text = speaker_names[current_paragraph];
                }
                count = 0;
            }
            if (!Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1]))
            {
                cooldown = 0;
            }
            if (current_paragraph == paragraphs.Count - 1 && count / 5 >= paragraphs[current_paragraph].Length)
            {
                if (text_menu_button == 1)
                {
                    pointer_pos.transform.position -= new Vector3(0, 2.4f * size, 0);
                }
                else if (text_menu_button == 2)
                {
                    pointer_pos.transform.position -= new Vector3(0, 1.2f * size, 0);
                }
                text_menu_button = 3;
                if (multi_next)
                {
                    if (autoread)
                    {
                        options.text = "  \n  \n  \n \n Reply";
                    }
                    else
                    {
                        options.text = "  \n  \n  \n \n Reply";
                    }
                }
                else
                {

                    if (autoread)
                    {
                        options.text = "  \n  \n  \n \n Finish";
                    }
                    else
                    {
                        options.text = "  \n  \n  \n \n Finish";
                    }

                }
            }
        }
    }
}
