﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class MultiTextImporter : MonoBehaviour
{
    public List<string> buttons = new List<string>();
    public string speaker_name;
    public Text options;
    public int text_menu_button = 1;
    public int count;
    public Transform my_pos;
    public float size = 1;
    public GameObject next_file1;
    public GameObject next_file2;
    public GameObject next_file3;
    public GameObject next_file4;
    public GameObject next_file5;
    private int next_counter;
    private int cooldown = -1;
    public float y_modifier = 1;
    public int start_count;
    public Transform canvas;
    private float camera_size;
    void Start()//This script manages a text box that allows for multiple options and branching dialogue
    {
        FindObjectOfType<Move>().allow_attack = false;
        FindObjectOfType<Move>().allow_movement = false;
        buttons = FindObjectOfType<Keybinds>().buttons;
        if (next_file1 != null)
        {
            options.text = " 1 \n  \n  \n \n ";
        }
        if (next_file2 != null)
        {
            options.text = " 1 \n 2 \n  \n \n ";
        }
        if (next_file3 != null)
        {
            options.text = " 1 \n 2 \n 3 \n \n ";
        }
        if (next_file4 != null)
        {
            options.text = " 1 \n 2 \n 3 \n 4 \n ";
        }
        if (next_file5 != null)
        {
            options.text = " 1 \n 2 \n 3 \n 4 \n 5";
        }
        Move move = FindObjectOfType<Move>();
        move.allow_movement = false;
        move.allow_attack = false;
        camera_size = FindObjectOfType<Camera>().orthographicSize;
        canvas.position = new Vector3(0, -0.6f, 10) * camera_size + FindObjectOfType<Camera>().transform.position;
        size *= camera_size * 0.125f;
        canvas.localScale = new Vector3(0.25f, 0.25f, 0) * camera_size * y_modifier;
        if(start_count == 0)
        {
            canvas.position += new Vector3(0, 0.9f, 0) * camera_size * y_modifier;
        }
        if(start_count == 80)//0 if preceded by options, 30 if default 
        {
            canvas.position -= new Vector3(0, 1.5f, 0) * camera_size * y_modifier;
        }
    }
    void Update()
    {
        if (start_count > 0)
        {
            start_count--;
            canvas.position += new Vector3(0, 0.03f, 0) * camera_size * y_modifier;
        }
        else
        {
            if (cooldown == 0)
            {
                if (next_file5 != null)
                {
                    if (Input.GetKey(buttons[0])) //Like the normal text box's options pointer, but with 5 buttons
                    {
                        if (text_menu_button == 1)
                        {
                            my_pos.position += new Vector3(0, -2.4f * size, 0);
                            text_menu_button = 5;
                        }
                        else
                        {
                            my_pos.position += new Vector3(0, 0.6f * size, 0);
                            text_menu_button--;
                        }
                        cooldown = 15;
                    }
                    else if (Input.GetKey(buttons[1]))
                    {
                        if (text_menu_button == 5)
                        {
                            my_pos.position += new Vector3(0, 2.4f * size, 0);
                            text_menu_button = 1;
                        }
                        else
                        {
                            my_pos.position += new Vector3(0, -0.6f * size, 0);
                            text_menu_button++;
                        }
                        cooldown = 15;
                    }
                }
                else if (next_file4 != null)
                {
                    if (Input.GetKey(buttons[0]))//Like the normal text box's options pointer, but with 4 buttons
                    {
                        if (text_menu_button == 1)
                        {
                            my_pos.position += new Vector3(0, -1.8f * size, 0);
                            text_menu_button = 4;
                        }
                        else
                        {
                            my_pos.position += new Vector3(0, 0.6f * size, 0);
                            text_menu_button--;
                        }
                        cooldown = 15;
                    }
                    else if (Input.GetKey(buttons[1]))
                    {
                        if (text_menu_button == 4)
                        {
                            my_pos.position += new Vector3(0, 1.8f * size, 0);
                            text_menu_button = 1;
                        }
                        else
                        {
                            my_pos.position += new Vector3(0, -0.6f * size, 0);
                            text_menu_button++;
                        }
                        cooldown = 15;
                    }
                }
                else if (next_file3 != null)//Like the normal text box's options pointer
                {
                    if (Input.GetKey(buttons[0]))
                    {
                        if (text_menu_button == 1)
                        {
                            my_pos.position += new Vector3(0, -1.2f * size, 0);
                            text_menu_button = 3;
                        }
                        else
                        {
                            my_pos.position += new Vector3(0, 0.6f * size, 0);
                            text_menu_button--;
                        }
                        cooldown = 15;
                    }
                    else if (Input.GetKey(buttons[1]))
                    {
                        if (text_menu_button == 3)
                        {
                            my_pos.position += new Vector3(0, 1.2f * size, 0);
                            text_menu_button = 1;
                        }
                        else
                        {
                            my_pos.position += new Vector3(0, -0.6f * size, 0);
                            text_menu_button++;
                        }
                        cooldown = 15;
                    }
                }
                else if (next_file2 != null)//Like the normal text box's options pointer, but with 2 buttons
                {
                    if (Input.GetKey(buttons[0]))
                    {
                        if (text_menu_button == 2)
                        {
                            my_pos.position += new Vector3(0, 0.6f * size, 0);
                            text_menu_button = 1;
                        }
                        else if (text_menu_button == 1)
                        {
                            my_pos.position += new Vector3(0, -0.6f * size, 0);
                            text_menu_button = 2;
                        }
                        cooldown = 15;
                    }
                    else if (Input.GetKey(buttons[1]))
                    {
                        if (text_menu_button == 1)
                        {
                            my_pos.position += new Vector3(0, -0.6f * size, 0);
                            text_menu_button = 2;
                        }
                        else if (text_menu_button == 2)
                        {
                            my_pos.position += new Vector3(0, 0.6f * size, 0);
                            text_menu_button = 1;
                        }
                        cooldown = 15;
                    }
                }
            }
            if (!Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1]) && !Input.GetKey(buttons[9]))
            {
                cooldown = 0;
            }
            if (cooldown != 0)
            {
                cooldown--;
            }
            if (Input.GetKeyDown(buttons[9]))
            {
                next_counter = 1;
            }
            if (next_counter > 0)
            {
                next_counter++;
            }
            if (next_counter == 5)
            {//Destroys this text box and loads the appropriate one according to the button being pressed
                if (text_menu_button == 1)
                {
                    Instantiate(next_file1, canvas.transform.position, Quaternion.identity);
                    Destroy(canvas.gameObject);
                }
                else if (text_menu_button == 2)
                {
                    my_pos.position += new Vector3(0, -0.6f * size, 0);
                    Instantiate(next_file2, canvas.transform.position, Quaternion.identity);
                    Destroy(canvas.gameObject);
                }
                else if (text_menu_button == 3)
                {
                    my_pos.position += new Vector3(0, -1.2f * size, 0);
                    Instantiate(next_file3, canvas.transform.position, Quaternion.identity);
                    Destroy(canvas.gameObject);
                }
                else if (text_menu_button == 4)
                {
                    my_pos.transform.position += new Vector3(0, -1.8f * size, 0);
                    Instantiate(next_file4, canvas.transform.position, Quaternion.identity);
                    Destroy(canvas.gameObject);
                }
                else if (text_menu_button == 5)
                {
                    my_pos.transform.position += new Vector3(0, -2.4f * size, 0);
                    Instantiate(next_file5, canvas.transform.position, Quaternion.identity);
                    Destroy(canvas.gameObject);
                }
            }
        }
    }
}

