﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Display_text : MonoBehaviour {
    public List<string> buttons = new List<string>();
    public TextAsset text_file;
    public Text words;
    public Transform canvas;
    public string[] text_Lines;
    public string speaker_name;
    public Text speaker_box;
    public Text options;
    public int currentLine = 0;
    public int text_menu_button = 1;
    public int count;
    private string sstring;
    public Transform my_pos;
    private float camera_size;
    public float size;
    private bool autoread;
    private int speaker_line;
    public GameObject next_file;
    public float y_modifier = 1;
    private int cooldown = -1;
    public int startup_count = 0;
    void Start () {//This script is for line by line text boxes
        buttons = FindObjectOfType<Keybinds>().buttons;
        camera_size = FindObjectOfType<Camera>().orthographicSize;
        size *= camera_size * 0.125f * y_modifier;
        canvas.localScale = new Vector3(0.25f, 0.25f, 0) * camera_size * y_modifier;
        if(startup_count != 0)
        {
            startup_count = 50;
            canvas.position -= new Vector3(1, 1, 1) * camera_size * y_modifier;
        }
    }
    void Update()
    {
        if(startup_count > 0)
        {
            canvas.position += new Vector3(0.2f, 0.2f, 0) * camera_size * y_modifier;
            startup_count--;
        }
        if(text_file == null && next_file != null)
        {//Destroys this textbox and creates the next one if there is a next one
            Position_checker text_stuff = FindObjectOfType<Position_checker>();
            Instantiate(next_file,text_stuff.transform.position,Quaternion.identity);
            Destroy(text_stuff.gameObject);
        }
        if (text_file != null)
        {
            text_Lines = text_file.text.Split('\n'); //Splits the text file into its number of lines
            Move move = FindObjectOfType<Move>();
            if (move != null)
            {
                move.allow_movement = false;
                move.allow_attack = false; //Stops the player from moving or attackig when there is a text box
            }
            if (speaker_name.Length > 0)
            {
                speaker_box.text = speaker_name; //Shows the speaker's name in the name segment of the text box
            }
            if (currentLine < text_Lines.Length)
            {//Checks if there are any lines of text remaining in the file
                if (count / 10 < text_Lines[currentLine].Length)
                {
                    if (count % 10 == 0)
                    {//Adds a new character to the current line every few frames
                        sstring = text_Lines[currentLine].Substring(0, count / 10);
                    }
                    count += 2;
                }
                if (autoread && count / 10 >= text_Lines[currentLine].Length)
                {//Starts a new line of text once this one is completed if autoread is on
                    if (currentLine != text_Lines.Length - 1)
                    {
                        currentLine++;
                        speaker_line++;
                        count = 0;//Resets the amount of characters for the next line
                        sstring = "";
                    }
                    else
                    {//Sets the count to stop increasing and trying to add characters that aren't there
                        count = text_Lines[currentLine].Length * 10;
                    }
                }
            }
            if (speaker_line == 0)
            {//Prints one partial line of text on the first line
                words.text = sstring;
            }
            if (speaker_line == 1)
            {//Prints one full line and the partial line on the second line
                words.text = text_Lines[currentLine - 1] + '\n' + sstring;
            }
            if (speaker_line == 2)
            {//Prints two full lines and the partial line on the third line
                words.text = text_Lines[currentLine - 2] + '\n' + text_Lines[currentLine - 1] + '\n' + sstring;
            }
            if (speaker_line == 3)
            {//Prints three full lines and the partial line on the fourth line
                words.text = text_Lines[currentLine - 3] + '\n' + text_Lines[currentLine - 2] + '\n' + text_Lines[currentLine - 1] + '\n' + sstring;
            }
            if (speaker_line >= 4)
            {//Prints four full lines and the partial line on the fifth line 
                words.text = text_Lines[currentLine - 4] + '\n' + text_Lines[currentLine - 3] + '\n' + text_Lines[currentLine - 2] + '\n' + text_Lines[currentLine - 1] + '\n' + sstring;
            }//Alternatively prints the most recent four lines and the incomplete line if there are more than five lines
            if (cooldown == 0)
            {
                if (currentLine < text_Lines.Length - 1)
                {//Checks if the last line has been reached, which would mean this menu is no longer needed
                    if (Input.GetKey(buttons[0]))
                    {
                        if (text_menu_button == 1)
                        {//Cycles the pointer round to the bottom if it is at the top
                            my_pos.transform.position += new Vector3(0, -2.4f * size, 0);
                            text_menu_button = 3;
                        }
                        else
                        {//Moves the pointer one space down otherwise
                            my_pos.transform.position += new Vector3(0, 1.2f * size, 0);//Sets the pointer to its new position
                            text_menu_button--;
                        }
                        cooldown = 15;
                    }
                    else if (Input.GetKey(buttons[1]))
                    {
                        if (text_menu_button == 3)
                        {//Cycles the pointer round to the top if it is at the bottom
                            my_pos.transform.position += new Vector3(0, 2.4f * size, 0);
                            text_menu_button = 1;
                        }
                        else
                        {//Moves the pointer one space up otherwise
                            my_pos.transform.position += new Vector3(0, -1.2f * size, 0);
                            text_menu_button++;
                        }
                        cooldown = 15;
                    }
                }
            }
            if (!Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1]) && !Input.GetKey(buttons[9]))
            {
                cooldown = 0;
            }
            if (cooldown > 0)
            {
                cooldown--;
            }
            else if (currentLine == text_Lines.Length - 1)
            {//Sets the button to the skip button if it is the end of the text file
                if (text_menu_button == 1)
                {
                    my_pos.transform.position += new Vector3(0, -2.4f * size, 0);
                }
                if (text_menu_button == 2)
                {
                    my_pos.transform.position += new Vector3(0, -1.2f * size, 0);
                }
                text_menu_button = 3;
                if (next_file == null)//Changes the options menu to only an equivalent of the skip button
                {//Changes the appearance of the skip button and makes it the only button depending whether there will be a new file
                    options.text = "\n\n\n\n Close";
                }
                else
                {
                    options.text = "\n\n\n\n Cont.";
                }
            }
            if (cooldown == 0)
            {
                if (Input.GetKeyDown(buttons[9]) && (currentLine == text_Lines.Length - 1 || text_menu_button == 3))
                {
                    if (move != null)
                    {
                        move.allow_movement = true;//Allows attacking and movement when the text box is gone
                        if (FindObjectOfType<Log>().boss == true)
                        {
                            move.allow_attack = true;//(If there is a new text box, it will immediately be disabled again)
                        }
                    }
                    if (next_file != null)
                    {//Checks if there is a text box that follows this one
                        Position_checker text_stuff = FindObjectOfType<Position_checker>();//The text box is the only object with this script
                        Instantiate(next_file, text_stuff.transform.position, Quaternion.identity);
                        Destroy(text_stuff.gameObject); //Destroys this text box
                        my_pos.position += new Vector3(0, 2.4f * size, 0); //Resets the position of the pointer
                        text_menu_button = 1;
                    }
                    else
                    {
                        Position_checker text_stuff = FindObjectOfType<Position_checker>();
                        Destroy(text_stuff.gameObject);//Destroys this text box and doesn't replace it
                    }
                }
                if (Input.GetKeyDown(buttons[9]))
                {
                    if (text_menu_button == 1)
                    {//Starts the next line if the Next button is selected
                        currentLine++;
                        speaker_line++;
                        count = 0;
                    }
                    if (text_menu_button == 2)
                    {//Toggles new lines starting automatically if the Auto button is selected
                        if (!autoread)
                        {
                            autoread = true;
                            options.text = " Next \n  \n - Auto \n \n Skip";
                        }//Toggles the appearance of the options to show whether Auto is on or off
                        else if (autoread)
                        {
                            autoread = false;
                            options.text = " Next \n  \n + Auto \n \n Skip";
                        }
                    }
                }
            }
            if (currentLine >= text_Lines.Length)
            {//Prevents the text box from trying to read lines that aren't there
                speaker_line = currentLine - text_Lines.Length + 1;
                currentLine = text_Lines.Length - 1;
            }
        }
    }
}
