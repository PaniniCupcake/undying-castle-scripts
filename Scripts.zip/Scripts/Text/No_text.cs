﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class No_text : MonoBehaviour
{
    void Update()
    {
        if (GameObject.FindWithTag("Book") != null)
        {
            Destroy(GameObject.FindWithTag("Book"));
        }
        if (FindObjectOfType<Interact>() != null)
        {
            FindObjectOfType<Interact>().cooldown = 5;
            Destroy(gameObject);
            Move move = FindObjectOfType<Move>();
            move.allow_movement = true;
            if (FindObjectOfType<Log>().boss == true)
            {
                move.allow_attack = true;
            }
        }
    }
}
