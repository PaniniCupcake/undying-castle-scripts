﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pedestal : MonoBehaviour
{
    public bool interacting;
    public GameObject book_blue;
    public GameObject book_purple;
    public GameObject book_yellow;
    public GameObject book_red;
    public int book_exists = 0;
    private bool saved = false;
    public int cooldown = 35;
    void Update()
    {
        if (interacting)
        {
            if (!saved)
            {
                Log log = FindObjectOfType<Log>();
                log.player_x_pos = GameObject.Find("Player").transform.position.x;
                log.player_y_pos = GameObject.Find("Player").transform.position.y;
                Keybinds keybinds = FindObjectOfType<Keybinds>();
                Save_system.Save(log, keybinds, false);
                saved = true;
            }
            if(book_exists != 1 && GameObject.FindWithTag("Scene_selector") != null)
            {
                if (GameObject.FindWithTag("Book") != null)
                {
                    Destroy(GameObject.FindWithTag("Book").gameObject);
                }
                Instantiate(book_blue, transform.position + new Vector3(0, 0.28f, 0), Quaternion.identity);
                book_exists = 1;
                cooldown = 60;
            }
            else if (book_exists != 2 && GameObject.FindWithTag("Puzzle_loader") != null)
            {
                if (GameObject.FindWithTag("Book") != null)
                {
                    Destroy(GameObject.FindWithTag("Book").gameObject);
                }
                Instantiate(book_yellow, transform.position + new Vector3(0, 0.28f, 0), Quaternion.identity);
                book_exists = 2;
                cooldown = 35;
            }
            else if(book_exists != 3 && GameObject.FindWithTag("Boss_loader") != null)
            {
                if (GameObject.FindWithTag("Book") != null)
                {
                    Destroy(GameObject.FindWithTag("Book").gameObject);
                }
                Instantiate(book_red, transform.position + new Vector3(0, 0.28f, 0), Quaternion.identity);
                book_exists = 3;
                cooldown = 35;
            }
            else if(book_exists != 4 && GameObject.FindWithTag("Librarian chat") != null)
            {
                if (GameObject.FindWithTag("Book") != null)
                {
                    Destroy(GameObject.FindWithTag("Book").gameObject);
                }
                Instantiate(book_purple, transform.position + new Vector3(0, 0.28f, 0), Quaternion.identity);
                book_exists = 4;
                cooldown = 35;
            }
            else if (GameObject.FindWithTag("Text canvas") != null)
            {
                if (GameObject.FindWithTag("Book") != null)
                {
                    Destroy(GameObject.FindWithTag("Book").gameObject);
                }
                book_exists = 0;
                cooldown = 35;
            }
            else if(book_exists == 0)
            {
                if (cooldown == 0)
                {
                    if (GameObject.FindWithTag("Book") != null)
                    {
                        Destroy(GameObject.FindWithTag("Book").gameObject);
                    }
                    interacting = false;
                    saved = false;
                }
                else
                {
                    cooldown--;
                }
            }
        }
    }
}
