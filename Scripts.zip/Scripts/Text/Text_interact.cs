﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Text_interact : MonoBehaviour {
    public bool text_start;
    public int text_count = 0;
    private int i;
    public List<int> text_position = new List<int>();
    public List<int> text_update = new List<int>();
    public List<GameObject> Text_variants = new List<GameObject>();
    private void Start()
    {
        text_count = 0;
    }
    void Update () {
        if (text_start)
        {
            if (text_count == 0)
            {
                Log log = FindObjectOfType<Log>();
                for (i = text_position.Count - 1; i >= 0; i--)
                {
                    if (log.text_trees[Mathf.FloorToInt(text_position[i] / 10)][text_position[i] % 10])
                    {
                        Instantiate(Text_variants[i], new Vector3(0, 0, 0), Quaternion.identity);
                        log.text_trees[Mathf.FloorToInt(text_update[i] / 10)][text_update[i] % 10] = true;
                        break;
                    }
                }
                
                text_count++;
            }
            else
            {
                text_start = false;
                text_count = 0;
            }
        }
    }
}
