﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interact : MonoBehaviour {
    public GameObject current_interactable = null;
    public int cooldown;
    public List<string> buttons = new List<string>();
    void OnTriggerEnter2D(Collider2D other)
    {//Checks if the player has come in range of an interactable object
        if(other.CompareTag("Interactable"))
        {
            current_interactable = other.gameObject;
        }
    }
    void OnTriggerExit2D(Collider2D other)
    {//Checks if the player has left range of an interactable object
        if(other.gameObject == current_interactable)
        {
            current_interactable = null;
        }
    }
    private void Start()
    {
        buttons = FindObjectOfType<Keybinds>().buttons;
    }
    void Update () {
		if(Input.GetKeyDown(buttons[4]) && current_interactable!= null && cooldown == 0) //Starts the interaction if the player is in range of something interactable
        {
            Text_interact textint = current_interactable.GetComponent<Text_interact>();
            Pedestal pedestal = current_interactable.GetComponent<Pedestal>();
            if (textint != null) //Checks if interacting with the object creates text
            {
                if (pedestal == null || !pedestal.interacting)
                {
                    var tbox = GameObject.FindWithTag("Text");
                    if (tbox == null) //Makes sure multiple text boxes aren't loaded
                    {
                        textint.text_start = true;
                    }  
                }
            }
            if(pedestal != null && !pedestal.interacting && pedestal.book_exists == 0 && GameObject.FindWithTag("Book") == null)
            {
                pedestal.interacting = true;
            }
            Scene_unlocker unlocker = current_interactable.GetComponent<Scene_unlocker>();
            if(unlocker != null)
            {
                FindObjectOfType<Log>().scenes_unlocked[unlocker.scene_unlocked] = true;
            }
            Boss_beaten beaten = current_interactable.GetComponent<Boss_beaten>();
            if (beaten != null)
            {
                FindObjectOfType<Log>().bosses_completed[beaten.boss] = true;
            }
            cooldown = 25;
        }
        if(GameObject.FindWithTag("Text canvas") != null)
        {
            cooldown = 25;
        }
        if(cooldown > 0)
        {
            cooldown--;
        }
	}
}
