﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Player_health : MonoBehaviour {
    public int health = 10;
    public int invuln = 0;
    private bool flashing = false;
    public int killable = 0;//Doesn't allow the player to lose health if this is enabled
    public int count=0;
    private int previous_health=10;
    public Animator animator;
    public List<GameObject> candles = new List<GameObject>();
    private int i;
    public bool vulnerable;
    public bool dying;
    public GameObject orb;
    public int candle = 0;
    public bool regen;
    public List<GameObject> caps = new List<GameObject>();
    private void Start()
    {
        for(i = 0;i<10;i++)
        {
            candles.Add(GameObject.Find("Health"+i));
        }
        for(i=0;i < 3;i++)
        {
            caps.Add(null);
        }
    }
    void FixedUpdate () {
        if(invuln > 0)
        {
            invuln--;//Prevents the player from taking more damage for a brief period after taking damage
        }
        if (health < previous_health && killable != 2 && invuln == 0)
        {
            if (caps[0] == null)
            {
                if (!flashing)
                {
                    FindObjectOfType<Move>().ranged_attacks = false;
                    flashing = true;
                    count = 0;
                    candles[candle].GetComponent<Animator>().SetBool("Dying", true);
                    orb.GetComponent<Animator>().SetBool("Flash", true);
                    invuln = 100;
                    if (vulnerable && candle != 9)
                    {
                        candles[candle + 1].GetComponent<Animator>().SetBool("Dying", true);
                    }
                }
                if (count % 10 == 0)
                {
                    GetComponent<SpriteRenderer>().color = new Color(0.8f, 0.8f, 1, 1);
                }
                if (count % 10 == 5)
                {
                    GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 1);
                }
                if (count == 99)
                {
                    candles[candle].GetComponent<Animator>().SetBool("Dead", true);
                    if (vulnerable && candle != 9)
                    {
                        candles[candle + 1].GetComponent<Animator>().SetBool("Dead", true);
                        previous_health--;
                        candle++;
                    }
                    flashing = false;
                    previous_health--;
                    health = previous_health; //Prevents the player from moving more than 1 health at a time
                    candle++;
                    orb.GetComponent<Animator>().SetBool("Flash", false);
                    GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 1);
                    if (health == 0)
                    {
                        dying = true;
                    }
                    if (killable == 1)
                    {
                        killable = 2;
                    }
                }
                else
                {
                    count++;
                } 
            }
            else
            {
                health = previous_health;
                for (i = 2; i >= 0; i--)
                {
                    if (caps[i] != null)
                    {
                        caps[i].GetComponent<Candle_cap>().count = 100;
                        caps[i].GetComponent<Animator>().SetBool("Destroyed", true);
                        break;
                    }
                }
                invuln = 100;
            }

        }
        else if(regen)
        {
            if (health != 10)
            {
                candle--;
                candles[candle].GetComponent<Animator>().SetBool("Dying", false);
                candles[candle].GetComponent<Animator>().SetBool("Dead", false);
                invuln = 100;
                health++;
                previous_health++;
            }
            regen = false;
        }
        else
        {
            if(killable == 1)
            {
                killable = 2;
            }
        }
        if (dying)
        {
            if(count == 99)
            {
                orb.GetComponent<Animator>().SetBool("Ded", true);
                FindObjectOfType<Move>().GetComponent<Animator>().SetFloat("Magnitude", 0);
                FindObjectOfType<Move>().GetComponent<Animator>().SetFloat("Direction", 2);
                FindObjectOfType<Move>().rb.velocity = new Vector3(0,0,0);
                FindObjectOfType<Move>().enabled = false;
            }
            if(count == 120)
            { GetComponent<SpriteRenderer>().color = new Color(0.8f, 0.8f, 1, 0);
                GetComponent<BoxCollider2D>().enabled = false;
}
            if(count >= 150)
            {
                orb.transform.Rotate(0, 0, 15);
            }
            if(count == 200)
            {
                GetComponent<Move>().rb.velocity = new Vector3(0, 5, 0);
            }
            if (count == 300)
            {
                SceneManager.LoadScene("GameOver"); //Loads the game over menu
            }
            else { count++; }
        }
    }
    public void Irresistable_damage(int amount)
    {
        for(i = candle;i< candle + amount;i++)
        {
            candles[i].GetComponent<Animator>().SetBool("Dying", true);
            candles[i].GetComponent<Animator>().SetBool("Dead", true);
        }
        candle += amount;
        if(candle > 9)
        {
            candle = 9;
        }
        health -= amount;
        if(health < 0)
        {
            health = 0;
        }
        previous_health = health;
    }
}
