﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Base_damage : MonoBehaviour {
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Base_damaging"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln==0&&player_health.health>0)
            {
                player_health.health--;
            } //Damages the player if anything base damaging hits their foot hitbox
        }
    }
}
