﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Vertical_sword : MonoBehaviour {
    private int count;
	void Update () {
		if(count == 10)
        {
            Destroy(gameObject);
            //Destroys the sword aftera few frames
        }
        count++;
	}
}


