﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player_follow : MonoBehaviour {
    public Transform playerPos;
	void Start () {
        
    }
    void Update()
    {//Moves the player's hitbox with the player
        transform.position = playerPos.position + new Vector3(0.031f, 0.02f, 0);
    }
}
