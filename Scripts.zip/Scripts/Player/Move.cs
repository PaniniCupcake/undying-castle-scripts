﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move : MonoBehaviour {
    public float direction = 1;
    public Rigidbody2D rb;
    private int attacking;
    public bool allow_movement;
    private bool horizontal;
    private bool vertical;
    public GameObject vertical_attack;
    public GameObject horizontal_attack;
    public bool allow_attack;
    public bool being_moved;
    public int xspeed;
    public int yspeed;
    private Vector3 movement;
    private int priority; //0 for none 1 for vertical 2 for horizontal
    public List<string> buttons = new List<string>();
    public GameObject fire_sword;
    public bool ranged_attacks;
    public int ranged_attacks_used;
    private void Start()
    {
        buttons = FindObjectOfType<Keybinds>().buttons;
        rb = GetComponent<Rigidbody2D>();
    }
    public Animator animator;
    void Update()
    {
        if (allow_movement == true && !being_moved)
        {
            if(Input.GetKey(buttons[0]) && Input.GetKey(buttons[1]))
            {
                if(yspeed > 0)
                {
                    yspeed--;
                }
                else if (yspeed < 0)
                {
                    yspeed ++;
                }
            }
            else if(Input.GetKey(buttons[0]))
            {
                if(yspeed < 0)
                {
                    yspeed = 0;
                }
                if (yspeed < 10)
                {
                    yspeed++;
                }
            }
            else if (Input.GetKey(buttons[1]))
            {
                if (yspeed > 0)
                {
                    yspeed = 0;
                }
                if (yspeed > -10)
                {
                    yspeed --;
                }
            }
            else
            {
                if (yspeed > 0)
                {
                    yspeed --;
                }
                else if (yspeed < 0)
                {
                    yspeed ++;
                }
            }
            if (Input.GetKey(buttons[2]) && Input.GetKey(buttons[3]))
            {
                if (xspeed > 0)
                {
                    xspeed --;
                }
                else if (xspeed < 0)
                {
                    xspeed ++;
                }
            }
            else if (Input.GetKey(buttons[3]))
            {
                if (xspeed < 0)
                {
                    xspeed = 0;
                }
                if (xspeed < 10)
                {
                    xspeed ++;
                }
            }
            else if (Input.GetKey(buttons[2]))
            {
                if (xspeed > 0)
                {
                    xspeed = 0;
                }
                if (xspeed > -10)
                {
                    xspeed --;
                }
            }
            else
            {
                if (xspeed > 0)
                {
                    xspeed --;
                }
                else if (xspeed < 0)
                {
                    xspeed ++;
                }
            }
            movement = new Vector3(xspeed * 0.22f, yspeed * 0.22f,0);
            if (!Input.GetKey(buttons[7])) //Moves the player according to key pressed
            {
                animator.SetBool("Fast", false);
                rb.velocity = movement;
            }
            else //Moves the player 1.5 times as fast if they are holding shift
            {
                animator.SetBool("Fast", true);
                rb.velocity = movement * 1.5f;
            }
            animator.SetFloat("Magnitude", movement.magnitude);
            if ((Input.GetKeyDown(buttons[2]) && !Input.GetKeyDown(buttons[3])) || (!Input.GetKeyDown(buttons[2]) && Input.GetKeyDown(buttons[3])))
            {
                priority = 2; //Determines that the player has most recently moved horizontally
            }
            if ((Input.GetKeyDown(buttons[0])&& !Input.GetKeyDown(buttons[1])) || (!Input.GetKeyDown(buttons[0]) && Input.GetKeyDown(buttons[1])))
            {
                priority = 1; //Determines that the player has most recently moved vertically
            }
            horizontal = true;
            vertical = true;
            if(xspeed == 0)
            {
                horizontal = false;
            }
            if(yspeed == 0)
            {
                vertical = false;
            }
            if ((!Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1])) || yspeed == 0)
            {
                vertical = false; //Checks if the player is still moving vertically
            }
            if ((!Input.GetKey(buttons[2]) && !Input.GetKey(buttons[3])) || xspeed == 0)
            {
                horizontal = false;//Checks if the player is still moving horizontally
                if (vertical)
                {
                    priority = 1; //Sets animator to vertical if they are still moving vertically
                }
                else
                {
                    priority = 0;
                }
            }
            if((!Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1])) || yspeed == 0)
            {
                if (horizontal)
                {
                    priority = 2;//Sets animator to horizontal if they are still moving horizontally
                }
                else
                {
                    priority = 0;
                }
            }
            if (priority == 2) //Determines whether the player is moving left or right
            {
                if (Input.GetKey(buttons[2]) && !Input.GetKey(buttons[3]))
                {
                    direction = 3;
                }
                else if (Input.GetKey(buttons[3]) && !Input.GetKey(buttons[2]))
                {
                    direction = 4;
                }
            }
            else if (priority == 1) //Determines whether the player is moving up or down
            {
                if (Input.GetKey(buttons[1]) && !Input.GetKey(buttons[0]))
                {
                    direction = 2;
                }
                else if (Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1]))
                {
                    direction = 1;
                }
            }
        }
        else if(!allow_movement)
        {
            rb.velocity = new Vector3(0, 0, 0);
            animator.SetFloat("Magnitude", 0);
            animator.SetBool("Fast", false);
        }
        animator.SetFloat("Direction", direction);
        if (allow_attack)
        {
            if (Input.GetKey(buttons[6]) && attacking == 0)
            {//Attacks if space is pressed, and doesn't allow it if they have attacked recently
                animator.SetBool("Attacking", true);
                attacking = -1;
                allow_movement = false; //Prevents the player from moving and attacking
                rb.velocity = new Vector3(0, 0, 0);
            }
            if(attacking > 0)
            {
                attacking--;
            }
        }
    }
    public void Attack_start()
    {
        if (direction == 1)
        {//Instantiates the damaging hitbox of the attack in the correct position
            Instantiate(vertical_attack, new Vector3(transform.position.x - 0.06f, transform.position.y + 0.35f, 0), Quaternion.identity);
            if (ranged_attacks && ranged_attacks_used < 15)
            {
                Magic_sword sword = Instantiate(fire_sword, new Vector3(transform.position.x - 0.15f, transform.position.y + 0.19f, 0), Quaternion.identity).GetComponent<Magic_sword>();
                if (ranged_attacks_used % 3 == 0)
                {
                    sword.consumed = true;
                }
                ranged_attacks_used++;
            }
        }
        else if (direction == 2)
        {
            Instantiate(vertical_attack, new Vector3(transform.position.x + 0.24f, transform.position.y - 0.5f, 0), Quaternion.identity);
            if (ranged_attacks && ranged_attacks_used < 15)
            {
                Magic_sword sword = Instantiate(fire_sword, new Vector3(transform.position.x + 0.15f, transform.position.y - 0.23f, 0), Quaternion.Euler(0, 0, 180)).GetComponent<Magic_sword>();
                if (ranged_attacks_used % 3 == 0)
                {
                    sword.consumed = true;
                }
                ranged_attacks_used++;
            }
        }
        else if (direction == 3)
        {
            Instantiate(horizontal_attack, new Vector3(transform.position.x - 0.32f, transform.position.y + 0.08f, 0), Quaternion.identity);
            if (ranged_attacks && ranged_attacks_used < 15)
            {
                Magic_sword sword = Instantiate(fire_sword, new Vector3(transform.position.x - 0.25f, transform.position.y + 0.01f, 0), Quaternion.Euler(0, 0, 90)).GetComponent<Magic_sword>();
                if (ranged_attacks_used % 3 == 0)
                {
                    sword.consumed = true;
                }
                ranged_attacks_used++;
            }
        }
        else if (direction == 4)
        {
            Instantiate(horizontal_attack, new Vector3(transform.position.x + 0.32f, transform.position.y + 0.08f, 0), Quaternion.identity);
            if (ranged_attacks && ranged_attacks_used < 15)
            {
                Magic_sword sword = Instantiate(fire_sword, new Vector3(transform.position.x + 0.25f, transform.position.y + 0.01f, 0), Quaternion.Euler(0, 0, 270)).GetComponent<Magic_sword>();
                if (ranged_attacks_used % 3 == 0)
                {
                    sword.consumed = true;
                }
                ranged_attacks_used++;
            }
        }
    }
    public void Attack_end()
    {
        animator.SetBool("Attacking", false);
        if(FindObjectOfType<Powerup>() != null && !FindObjectOfType<Powerup>().active)
        {
            allow_movement = true;
        }
        allow_movement = true;
        attacking = 5;
    }
}
    

