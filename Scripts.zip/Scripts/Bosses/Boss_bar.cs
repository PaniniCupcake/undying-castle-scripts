﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_bar : MonoBehaviour
{
    public GameObject emblem;
    public Sprite annoyed;
    public Sprite enraged;
    public int annoyed_phase;
    public int enraged_phase;
    public List<GameObject> bars = new List<GameObject>();
    public List<int> phase_lengths = new List<int>();
    private int count = -2;
    public int current_bar = 0;
    private int i;
    public int phase_progress = 1;
    void Start()
    {
        for (i = 0; i < 87; i++)
        {
            bars.Add(GameObject.Find("Bossbar_green (" + i + ")"));
        }
    }
    public void Progress(int completed,int phase)
    {
        int completed_buffer = new int();
        if (completed < 115)
        {
            completed_buffer = completed + 10;
        }
        else
        {
            completed_buffer = 125;
        }
        if(completed_buffer * 10000/ 125> 10000/phase_lengths[phase] * phase_progress && count == -2)
        {
            count = 20;
            phase_progress++;
        }
        if(completed == 125)
        {
            phase_progress = 1;
            if (phase== annoyed_phase)
            {
                emblem.GetComponent<SpriteRenderer>().sprite = annoyed;
            }
            if (phase== enraged_phase)
            {
                emblem.GetComponent<SpriteRenderer>().sprite = enraged;
            }
        }
    }
    void FixedUpdate()
    {
        if (count >= 0)
        {
            bars[current_bar].transform.localScale -= new Vector3(0, 0.1f, 0);
            bars[current_bar].GetComponent<SpriteRenderer>().color -= new Color(0, 0, 0, 0.05f);
            count--;
        }
        if(count == -1)
        {
            current_bar++;
            count = -2;
        }
    }
}
