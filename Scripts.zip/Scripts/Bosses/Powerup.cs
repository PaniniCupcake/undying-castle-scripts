﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Powerup : MonoBehaviour
{
    public List<GameObject> swords = new List<GameObject>();
    public List<GameObject> hearts = new List<GameObject>();
    public List<GameObject> caps = new List<GameObject>();
    public GameObject cap_spawn;
    public Transform boss_text;
    private int boss_count;
    public List<int> available = new List<int>();
    public List<Transform> holders = new List<Transform>();
    private int i;
    public float scale;
    public int selection;
    public List<string> buttons = new List<string>();
    private int cooldown;
    public Vector3 pointer_pos_start;
    public GameObject pointer;
    public int powerup_active; // -1 means selection, 0 = mid_phase, 1 swords 2 regen 3 caps
    public int finishing = -1;
    public float holder_x;
    public bool active;
    private void Start()
    {
        Log log = FindObjectOfType<Log>();
        if (!log.bosses_completed[0])
        {
            Destroy(holders[1].gameObject);
            holders[1] = null;
            holders[2].position -= new Vector3(0, 2.5f, 0);
            holders[3].position -= new Vector3(0, 2.5f, 0);
        }
        if (!log.bosses_completed[1])
        {
            Destroy(holders[2].gameObject);
            holders[2] = null;
            holders[3].position -= new Vector3(0, 2.5f, 0);
        }
        if (!log.bosses_completed[2])
        { 
            Destroy(holders[3].gameObject);
            holders[3] = null;
        }
        for (i = 0; i < 4; i++)
        {
            if (holders[i] != null)
            {
                available.Add(i);
            }
        }
        buttons = FindObjectOfType<Keybinds>().buttons;
    }
    public void New_phase()
    {
        Player_health health = FindObjectOfType<Player_health>();
        health.killable = 1;
        Move move = FindObjectOfType<Move>();
        move.allow_attack = false;
        move.allow_movement = false;
        move.ranged_attacks = false;
        move.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 1);
        for (i = 0; i < 3; i++)
        {
            if (health.caps[i] != null && health.caps[i].GetComponent<Candle_cap>().count < 0)
            {
                health.caps[i].GetComponent<Candle_cap>().count = 50;
                health.Irresistable_damage(1);
            }
        }
        health.vulnerable = false;
        for (i = 0; i < 10; i++)
        {
            health.candles[i].GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 1);
        }
    }
    public void Update()
    {
        if (active)
        {
            if(boss_count < 53)
            {
                boss_text.position += new Vector3(0, 0.2f, 0);
                boss_count++;
                holders[0].transform.position = new Vector3(holder_x - 0.5f, holders[0].transform.position.y, 0);
            }
            else if (finishing == -1)
            {
                for (i = 0; i < available.Count; i++)
                {
                    holders[available[i]].transform.position = new Vector3(holder_x, holders[available[i]].transform.position.y, 0);
                }
                if (cooldown == 0)
                {
                    if (Input.GetKey(buttons[0]))
                    {
                        selection++;
                        if (selection >= available.Count)
                        {
                            selection = 0;
                        }
                        if (available[selection] == 0)
                        {
                            pointer.transform.position = new Vector3(pointer_pos_start.x - 0.5f * scale, pointer_pos_start.y, 0);
                        }
                        if (available[selection] == 1)
                        {
                            if (swords.Count == 0)
                            {
                                selection = 2;
                            }
                            else
                            {
                                pointer.transform.position = new Vector3(pointer_pos_start.x + ((swords.Count - 1) * 1.6f - 0.5f) * scale, pointer_pos_start.y + scale * 2.5f * selection, 0);
                            }
                        }
                        if (available[selection] == 2)
                        {
                            if (hearts.Count == 0)
                            {
                                selection = 3;
                            }
                            else
                            {
                                pointer.transform.position = new Vector3(pointer_pos_start.x + ((hearts.Count - 1) * 1.6f - 0.5f) * scale, pointer_pos_start.y + scale * 2.5f * selection, 0);
                            }
                        }
                        if (available[selection] == 3)
                        {
                            if (caps.Count == 0)
                            {
                                selection = 0;
                                pointer.transform.position = new Vector3(pointer_pos_start.x - 0.5f * scale, pointer_pos_start.y, 0);
                            }
                            else
                            {
                                pointer.transform.position = new Vector3(pointer_pos_start.x + ((caps.Count - 1) * 1.6f - 0.5f) * scale, pointer_pos_start.y + scale * 2.5f * selection, 0);
                            }
                        }
                        cooldown = 15;
                    }
                    else if (Input.GetKey(buttons[1]))
                    {
                        selection--;
                        if (selection < 0)
                        {
                            selection = available.Count - 1;
                        }
                        if (available[selection] == 3)
                        {
                            if (caps.Count == 0)
                            {
                                selection = 2;
                            }
                            else
                            {
                                pointer.transform.position = new Vector3(pointer_pos_start.x + ((caps.Count - 1) * 1.6f - 0.5f) * scale, pointer_pos_start.y + scale * 2.5f * selection, 0);
                            }
                        }
                        if (available[selection] == 2)
                        {
                            if (hearts.Count == 0)
                            {
                                selection = 1;
                            }
                            else
                            {
                                pointer.transform.position = new Vector3(pointer_pos_start.x + ((hearts.Count - 1) * 1.6f - 0.5f) * scale, pointer_pos_start.y + scale * 2.5f * selection, 0);
                            }
                        }
                        if (available[selection] == 1)
                        {
                            if (swords.Count == 0)
                            {
                                selection = 0;
                            }
                            else
                            {
                                pointer.transform.position = new Vector3(pointer_pos_start.x + ((swords.Count - 1) * 1.6f - 0.5f) * scale, pointer_pos_start.y + scale * 2.5f * selection, 0);
                            }
                        }
                        if (available[selection] == 0)
                        {
                            pointer.transform.position = new Vector3(pointer_pos_start.x - 0.5f, pointer_pos_start.y, 0);
                        }
                        cooldown = 15;
                    }
                }
                else
                {
                    cooldown--;
                    if (!Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1]))
                    {
                        cooldown = 0;
                    }
                }
                holders[available[selection]].transform.position = new Vector3(holder_x - 0.5f * scale, holders[available[selection]].transform.position.y, 0);
                if (Input.GetKeyDown(buttons[9]))
                {
                    finishing = 50;
                    if (available[selection] == 1)
                    {
                        Move move = FindObjectOfType<Move>();
                        move.GetComponent<SpriteRenderer>().color -= new Color(0f, 0.3f, 0.3f, 0);
                        move.ranged_attacks = true;
                        if(move.ranged_attacks_used % 3 == 1)
                        {
                            move.ranged_attacks_used += 2;
                        }
                        if(move.ranged_attacks_used % 3 == 2)

                        {
                            move.ranged_attacks_used++;
                        }
                    }
                    if (available[selection] == 2)
                    {
                        Player_health health = FindObjectOfType<Player_health>();
                        health.regen = true;
                        health.invuln = 100;
                        health.vulnerable = true;
                        for (i = 0; i < 10; i++)
                        {
                            health.candles[i].GetComponent<SpriteRenderer>().color = new Color(1, 0.25f, 0.25f, 1);
                        }
                    }
                    if (available[selection] == 3)
                    {
                        Player_health health = FindObjectOfType<Player_health>();
                        for (i = 0; i < 3; i++)
                        {
                            if (health.candle + i < 10)
                            {
                                health.caps[i] = (Instantiate(cap_spawn, health.candles[health.candle + i].transform.position + new Vector3(0, 3.3f, 0), Quaternion.identity));
                            }
                        }
                    }
                }
            }
            else
            {
                boss_text.position -= new Vector3(0, 0.2f, 0);
                finishing--;
            }
            if (finishing >= 25)
            {
                pointer.GetComponent<SpriteRenderer>().color -= new Color(0, 0, 0, 0.04f);
                if (available[selection] == 2)
                {
                    hearts[hearts.Count - 1].GetComponent<SpriteRenderer>().color -= new Color(0.04f, 0.04f, 0, 0);
                }
                if (available[selection] == 3)
                {
                    caps[caps.Count - 1].GetComponent<SpriteRenderer>().color -= new Color(0.04f, 0.04f, 0, 0);
                }
            }
            else if (finishing >= 0)
            {
                pointer.GetComponent<SpriteRenderer>().color += new Color(0, 0, 0, 0.04f);
                if (available[selection] == 2)
                {
                    hearts[hearts.Count - 1].GetComponent<SpriteRenderer>().color -= new Color(0, 0, 0, 0.04f);
                }
                if (available[selection] == 3)
                {
                    caps[caps.Count - 1].GetComponent<SpriteRenderer>().color -= new Color(0, 0, 0, 0.04f);
                }
            }
            if (finishing == 25)
            {
                for (i = 0; i < available.Count; i++)
                {
                    holders[available[i]].transform.position = new Vector3(holder_x, holders[available[i]].transform.position.y, 0);
                }
                pointer.transform.position = pointer_pos_start;
            }
            if (finishing == 0)
            {
                if (available[selection] == 2)
                {
                    Destroy(hearts[hearts.Count - 1]);
                    hearts.Remove(hearts[hearts.Count - 1]);
                }
                if (available[selection] == 3)
                {
                    Destroy(caps[caps.Count - 1]);
                    caps.Remove(caps[caps.Count - 1]);
                }
                pointer.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 1);
                cooldown = 0;
                finishing = -1;
                selection = 0;
                FindObjectOfType<Move>().allow_attack = true;
                FindObjectOfType<Move>().allow_movement = true;
                FindObjectOfType<Player_health>().killable = 0;
                boss_count = 0;
                boss_text.transform.position = new Vector3(0, -17.9f, 0);
                active = false;
            }
        }
    }
}