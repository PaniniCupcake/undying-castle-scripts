﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hurtbox : MonoBehaviour
{
    private int count = 0;
    public int destroy_time;
    void FixedUpdate()
    {
        if(count == destroy_time)
        {
            Destroy(gameObject);
        }
        count++;
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player_main_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
                player_health.invuln = 100;
            }
        }
    }
}
