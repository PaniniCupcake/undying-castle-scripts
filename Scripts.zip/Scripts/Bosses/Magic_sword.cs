﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Magic_sword : MonoBehaviour
{
    public int count = 0;
    public Rigidbody2D rb;
    private Vector3 speed;
    public Animator animator;
    public bool consumed;
    private List<GameObject> swords = new List<GameObject>();
    void Start()
    {
        swords = FindObjectOfType<Powerup>().swords;
        if (transform.rotation.eulerAngles.z == 0)
        {
            speed = new Vector3(0, 4, 0);
        }
        else if (transform.rotation.eulerAngles.z == 90)
        {
            speed = new Vector3(-4, 0, 0);
        }
        else if (transform.rotation.eulerAngles.z == 180)
        {
            speed = new Vector3(0,-4, 0);
        }
        else if (transform.rotation.eulerAngles.z == 270)
        {
            speed = new Vector3(4, 0, 0);
        }
    }
    void FixedUpdate()
    {
        if(count == 10)
        {
            rb.velocity = speed;
        }
        if(consumed)
        {
            if(count < 25)
            {
                swords[swords.Count - 1].GetComponent<SpriteRenderer>().color -= new Color(0.04f, 0.04f, 0, 0);
            }
            else if(count < 50)
            {
                swords[swords.Count - 1].GetComponent<SpriteRenderer>().color -= new Color(0, 0, 0, 0.04f);
            }
            else if(count == 50)
            {
                Destroy(swords[swords.Count - 1]);
                swords.Remove(swords[swords.Count - 1]);
            }
        }
        if(count == 200)
        {
            animator.SetBool("Disappear", true);
            GetComponent<BoxCollider2D>().enabled = false;
        }
        if(count == 210)
        {
            Destroy(gameObject);
        }
        count++;
    }
}
