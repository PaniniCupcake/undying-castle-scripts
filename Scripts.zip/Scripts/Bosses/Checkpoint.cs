﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Checkpoint : MonoBehaviour
{
    private int count;
    private float accel;
    private Vector3 start_pos;
    private void Start()
    {
        start_pos = transform.position;
    }
    void Update()
    {
        if (count >= 0)
        {
            if (count >= 113)
            {
                transform.position += new Vector3(0, -0.5f, 0);
            }
            else if (count >= 90 && count < 100)
            {
                transform.position += new Vector3(0, -0.15f - accel, 0);
                accel += 0.01f;
            }
            else if (count >= 102 && count < 112)
            {
                transform.position += new Vector3(0, 0.25f - accel, 0);
                accel -= 0.01f;
            }
            else if (count >= 0 && count < 50)
            {
                transform.position += new Vector3(0, 0.5f, 0);
            }
            if(count == 0)
            {
                transform.position = start_pos;
            }
            count--;
        }
    }
    public void Display_checkpoint()
    {
        accel = 0.1f;
        count = 153;
    }
}
