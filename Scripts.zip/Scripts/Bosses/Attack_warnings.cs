﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Attack_warnings : MonoBehaviour
{
    public List<int> phase_selection = new List<int>();
    public List<int> phase_type = new List<int>();
    public List<float> size_of_attacks = new List<float>();
    public List<Sprite> mini_bar = new List<Sprite>();
    public List<GameObject> attack_boxes = new List<GameObject>();
    public List<GameObject> attack_type_boxes = new List<GameObject>();
    public List<Sprite> attacks = new List<Sprite>();
    public GameObject mini_boss_bar;
    public Sprite physical;
    public Sprite magical;
    public Sprite ground;
    public Sprite attack_sub;
    public Sprite attack_type;
    private int step;
    private float attack_pointer;
    private float attack_type_pointer;
    public float number_of_attacks;
    private float j;
    private int i;
    public int count = -1;
    public float accel;
    public int attack_phase = 1;
    private void FixedUpdate()
    {
        if (count >= 0)
        {
            if (count >= 63)
            {
                transform.position += new Vector3(0, 0.5f, 0);
            }
            else if (count >= 22)
            {
                transform.position += new Vector3(0, -0.5f, 0);
            }
            else if(count >= 0 && count < 10)
            {
                transform.position += new Vector3(0, -0.15f - accel, 0);
                accel += 0.01f;
            }
            else if (count >= 12 && count < 22)
            {
                transform.position += new Vector3(0, 0.25f - accel, 0);
                accel -= 0.01f;
            }
            if (count == 60)
            {
                Change2(attack_phase);
            }
            count--;
        }
    }
    public void Change(int phase)
    {
        count = 103;
        attack_phase = phase;
        accel = 0.1f;
    }
    public void Change2(int phase)
    {
        attack_phase--;
        for(i = 0; i < 8;i++)
        {
            attack_boxes[i].GetComponent<SpriteRenderer>().sprite = attack_sub;
            attack_boxes[i].transform.localScale = new Vector3(1, 1, 0);
            attack_type_boxes[i].GetComponent<SpriteRenderer>().sprite = attack_type;
        }
        step = 0;
        for (j = 0; j < number_of_attacks; j++)
        {
            i = Mathf.RoundToInt(j);
            attack_pointer = Mathf.Pow(10,j);
            attack_type_pointer = Mathf.Pow(1000,j);
            if (Mathf.FloorToInt( phase_selection[attack_phase]/ attack_pointer) %10 == 1)
            {
                attack_boxes[step].GetComponent<SpriteRenderer>().sprite = attacks[i];
                attack_boxes[step].transform.localScale = size_of_attacks[i] * new Vector3(1, 1, 0);
                if (phase_type[i] == 0)
                {
                    attack_type_boxes[step].GetComponent<SpriteRenderer>().sprite = physical;
                }
                else if (phase_type[i] == 1)
                {
                    attack_type_boxes[step].GetComponent<SpriteRenderer>().sprite = magical;
                }
                else
                {
                    attack_type_boxes[step].GetComponent<SpriteRenderer>().sprite = ground;
                }
                step++;
            }
        }
    }
}