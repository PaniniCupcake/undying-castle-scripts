﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Magic_damage : MonoBehaviour
{
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player_magic_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
                player_health.invuln = 100;
            }
        }
    }
}
