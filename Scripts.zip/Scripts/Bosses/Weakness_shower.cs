﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weakness_shower : MonoBehaviour
{
    public List<Sprite> sprites = new List<Sprite>();
    public List<float> sizes = new List<float>();
    public GameObject sub;
    private int count = -1;
    private float accel;
    public int index;
    void FixedUpdate()
    {
        if (count >= 64)
        {
            transform.position += new Vector3(0, 0.5f, 0);
        }
        else if(count >= 0 && count < 63)
        {
            if (count >= 22)
            {
                transform.position += new Vector3(0, -0.5f, 0);
            }
            else if (count >= 0 && count < 10)
            {
                transform.position += new Vector3(0, -0.15f - accel, 0);
                accel += 0.01f;
            }
            else if (count >= 12 && count < 22)
            {
                transform.position += new Vector3(0, 0.25f - accel, 0);
                accel -= 0.01f;
            }
            count--;
        }
    }
    public void Display_weakness()
    {
        sub.GetComponent<SpriteRenderer>().sprite = sprites[index];
        sub.transform.localScale = sizes[index] * new Vector3(1, 1, 0);
        index++;
        count = 62;
        accel = 0.1f;
    }
    public void Recede()
    {
        if(count == -1)
        {
            count = 104;
        }    }
}
