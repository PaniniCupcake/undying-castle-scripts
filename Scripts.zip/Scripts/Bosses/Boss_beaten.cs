﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_beaten : MonoBehaviour
{
    public int boss;
}
