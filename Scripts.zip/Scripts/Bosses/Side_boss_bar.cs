﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Side_boss_bar : MonoBehaviour
{
    public List<Sprite> frames = new List<Sprite>();
    public Sprite red_bar;
    public Sprite blue_bar;
    public Sprite green_bar;
    public List<GameObject> bars = new List<GameObject>();
    private List<int> removal_counts = new List<int>();
    private int i;
    private float j;
    public int count = -1;
    private bool removing_bars = false;
    public int bars_removed;
    public float accel;
    public List<int> colours = new List<int>();
    private Sprite current_colour;
    public int phase = 0;
    public Boss_bar main_bar;
    private int filler;
    void Start()
    {
        for(i = 0;i<125;i++)
        {
            bars.Add(GameObject.Find("Bossbar_green_wide (" + i + ")"));
            removal_counts.Add(-2);
        }
    }
    public void Sectionally_move(int divisions,int count_used)//put the length of attack here, increase whenever count increases
    {
        for (j = (125 * 10000 / divisions * count_used); j <= 125*10000 / divisions * (count_used + 1); j+=10000)
        {
            filler = Mathf.RoundToInt(j / 10000);
            if(filler < 0)
            {
                filler = 0;
            }
            if(filler >= 125)
            {
                filler = 124;
            }
            if (removal_counts[filler] == -2)
            {
                removal_counts[filler] = 40;
                removing_bars = true;
            }
        }
    }
    public void Bar_reset()
    {
        accel = 0.1f;
        count = 103;
        for (i = 0; i < 125; i++)
        {
            removal_counts[i] = -2;
        }
        phase++;
    }
    private void FixedUpdate()
    {
        if (removing_bars)
        {
            removing_bars = false;
            for (i = 0; i < 125; i++)
            {
                if (removal_counts[i] >= 0)
                {
                    bars[i].transform.localScale -= new Vector3(0.05f, 0, 0);
                    bars[i].GetComponent<SpriteRenderer>().color -= new Color(0, 0, 0, 0.025f);
                    removal_counts[i]--;
                    removing_bars = true;
                }
                if(removal_counts[i] == -1)
                {
                    bars_removed = i + 1;
                    main_bar.Progress(bars_removed, phase);
                }
            }
        }
        if (count >= 0)
        {
            if (count >= 63)
            {
                transform.position += new Vector3(0, 0.5f, 0);
            }
            else if (count >= 22)
            {
                transform.position += new Vector3(0, -0.5f, 0);
            }
            else if (count >= 0 && count < 10)
            {
                transform.position += new Vector3(0, -0.15f - accel, 0);
                accel += 0.01f;
            }
            else if (count >= 12 && count < 22)
            {
                transform.position += new Vector3(0, 0.25f - accel, 0);
                accel -= 0.01f;
            }
            if (count == 60 && phase != 0)
            {
                GetComponent<SpriteRenderer>().sprite = frames[phase];
                if(colours[phase] == 0)
                {
                    current_colour = green_bar;
                }
                else if(colours[phase] == 1)
                {
                    current_colour = red_bar;
                }
                else
                {
                    current_colour = blue_bar;
                }
                for(i = 0;i<125;i++)
                {
                    bars[i].GetComponent<SpriteRenderer>().sprite = current_colour;
                    bars[i].transform.localScale = new Vector3(1, 1, 1);
                    bars[i].GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 1);
                }
                bars_removed = 0;
            }
            count--;
        }
    }
}
