﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Librarian_dissapear : MonoBehaviour
{
    private int blip = 0;
    void Update()
    {
        Background_darkness bground = FindObjectOfType<Background_darkness>();
        if (blip == 25)
        {
            Move move = FindObjectOfType<Move>();
            move.allow_movement = true;
            bground.GetComponent<SpriteRenderer>().sortingLayerName = "Super_background";
            FindObjectOfType<Log>().puzzles_completed[0][0] = true;
            Log log = FindObjectOfType<Log>();
            log.player_x_pos = GameObject.Find("Player").transform.position.x;
            log.player_y_pos = GameObject.Find("Player").transform.position.y;
            Keybinds keybinds = FindObjectOfType<Keybinds>();
            Destroy(GameObject.Find("Librarian"));
            Save_system.Save(log, keybinds, false);
            Destroy(gameObject);
        }
        else
        {
            bground.GetComponent<SpriteRenderer>().sortingLayerName = "Death_layer";
            blip++;
            Move move = FindObjectOfType<Move>();
            move.allow_movement = false;
        }
    }
}

