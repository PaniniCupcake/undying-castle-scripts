﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Candle_cap : MonoBehaviour
{
    public int count = -1;
    void FixedUpdate()
    {
        if(count < 0 && count > -50)
        {
            transform.position -= new Vector3(0,0.04f,0);
            count--;
        }
        if (count > 50)
        {
            count--;
        }
        else if (count > 0)
        {
            transform.position += new Vector3(0, 0.04f, 0);
            count--;
        }
        if(count == 1)
        {
            Destroy(gameObject);
        }
    }
}
