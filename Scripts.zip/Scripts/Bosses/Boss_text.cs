﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Boss_text : MonoBehaviour
{
    public int index;
    public List<string> names = new List<string>();
    public List<string> paragraphs = new List<string>();
    public Text paragraph;
    public Text charname;
    public void Next_paragraph()
    {
        charname.text = names[index];
        paragraph.text = paragraphs[index];
        index++;
    }
}
