﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene_unlocker : MonoBehaviour
{
    public int scene_unlocked;
}
