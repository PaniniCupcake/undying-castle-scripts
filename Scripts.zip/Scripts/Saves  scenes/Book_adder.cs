﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Book_adder : MonoBehaviour
{
    public GameObject blue;
    public GameObject yellow;
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.GetComponent<Book_pedestal>() != null)
        {
            Instantiate(blue, collision.transform.position + new Vector3(0, 0.28f, 0), Quaternion.identity);
            Destroy(gameObject);
        }
    }
    private void Update()
    {
        Destroy(gameObject);
    }
}
