﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Log : MonoBehaviour
{
    public bool boss;
    public string previous_scene;
    public string scene;
    public float player_x_pos;
    public float player_y_pos;
    public List<List<bool>> puzzles_completed = new List<List<bool>>();
    public List<bool> bosses_completed = new List<bool>();//1 = executioner, 2 = preacher, 3 = geomancer, 4 = tower, 5 = angel, 6 = keep, 7 = king
    public List<bool> scenes_unlocked = new List<bool>();
    private int i;
    private int j;
    public int scene_selector_page;
    public bool first_attempt = true;
    public List<bool> endings = new List<bool>();
    public List<List<int>> boss_checkpoints = new List<List<int>>(); //0 for phase checkpoint, 1 for health, 2 for swords, 3 for regen, 4 for shields, 5,6,7 for weakpoints destroyed
    public int current_boss;//Same as completed
    public List<List<bool>> text_trees = new List<List<bool>>();
    void Start()
    {
        for (i = 0; i < 64; i++)
        {
            endings.Add(false);
        }
        scenes_unlocked.Add(true);
        DontDestroyOnLoad(gameObject);
        for(i=0;i<7;i++)
        {
            List<bool> filler_list = new List<bool>();
            for (j = 0;j<5;j++)
            {
                filler_list.Add(false);
            }
            puzzles_completed.Add(filler_list);
            bosses_completed.Add(false);
            scenes_unlocked.Add(false);
        }
        for (i = 0; i < 100; i++)
        {
            List<bool> filler_list = new List<bool>();
            for (j = 0; j < 20; j++)
            {
                filler_list.Add(false);
            }
            text_trees.Add(filler_list);
        }
        text_trees[0][0] = true;
        for (i = 0;i<5;i++)
        {
            scenes_unlocked.Add(false);
        }
        for(i = 0;i<2;i++)
        {
            List<int> filler_list2 = new List<int>();
            for(j=0;j<8;j++)
            {
                filler_list2.Add(0);
            }
            boss_checkpoints.Add(filler_list2);
        }
    }
}
