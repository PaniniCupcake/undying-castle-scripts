﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Game_end : MonoBehaviour
{
    public float ending = 0;
    public int end;
    private int i;
    void Start()
    {
        End();
    }
    public void End()
    {
        Log log = FindObjectOfType<Log>();
        for(i = 0;i < 7;i++)
        {
            if(log.bosses_completed[i])
            {
                ending += Mathf.Pow(2f,ending);
            }
        }
        end = Mathf.RoundToInt(ending);
        log.endings[end] = true;
        Destroy(gameObject);
    }
}
