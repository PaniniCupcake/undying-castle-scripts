﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Book_pedestal : MonoBehaviour
{
    public bool puzzle;
    public bool boss;
    public bool interacting;
    public GameObject book1;
    public GameObject book2;
    public GameObject book3;
    public int book_exists;
    private int delay;
    private int cooldown;
    public List<string> buttons = new List<string>();
    private bool saved = true;
    private void Start()
    {
        buttons = FindObjectOfType<Keybinds>().buttons;
    }
    void Update()
    {
        if(interacting)
        {
            if(saved)
            {
                Log log = FindObjectOfType<Log>();
                log.player_x_pos = GameObject.Find("Player").transform.position.x;
                log.player_y_pos = GameObject.Find("Player").transform.position.y;
                Keybinds keybinds = FindObjectOfType<Keybinds>();
                Save_system.Save(log, keybinds,false);
            }
            if(GameObject.FindWithTag("Book") == null)
            {
                book_exists = 0;
            }
            if (delay == 0)
            {
                delay = 5;
            }
            if(delay > 1)
            {
                delay--;
            }
            if(Input.GetKeyDown(buttons[4])&&book_exists == 0 && book_exists == 0 && delay < 2)
            {
                if(FindObjectOfType<MultiTextImporter>() != null)
                {
                    if(FindObjectOfType<MultiTextImporter>().text_menu_button == 1)
                    {
                        Instantiate(book1, transform.position + new Vector3(0,0.28f,0),Quaternion.identity);
                        book_exists = 1;
                        delay = 0;
                    }
                    else if (FindObjectOfType<MultiTextImporter>().text_menu_button == 2)
                    {
                        Instantiate(book2, transform.position + new Vector3(0, 0.28f, 0), Quaternion.identity);
                        book_exists = 2;
                        delay = 0;
                    }
                    else if (puzzle)
                    {
                        FindObjectOfType<Log>().first_attempt = true;
                        Instantiate(book3, transform.position + new Vector3(0, 0.28f, 0), Quaternion.identity);
                        book_exists = 3;
                        delay = 0;
                    }
                    else if (boss)
                    {
                        Instantiate(book3, transform.position + new Vector3(0, 0.28f, 0), Quaternion.identity);
                        book_exists = 4;
                        delay = 0;
                    }
                }
            }
            if(FindObjectOfType<MultiTextImporter>() == null && FindObjectOfType<Text_importer>() == null && delay == 1)
            {
                if(cooldown == 0)
                {
                    cooldown = 100;
                }
                if (cooldown == 1)
                {
                    saved = true;
                    interacting = false;
                    delay = 0;
                    cooldown = 0;
                    book_exists = 0;
                    if (GameObject.FindWithTag("Book") != null)
                    {
                        Destroy(GameObject.FindWithTag("Book").gameObject);
                    }
                }
                else if(cooldown > 1)
                {
                    cooldown--;
                }
            }
            else
            {
                cooldown = 0;
            }
        }
    }
}
