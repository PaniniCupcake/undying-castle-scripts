﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Scene_setup : MonoBehaviour
{
    public string scene; //The current scene
    public bool boss;
    void Start()
    {
        if (boss)
        {
            FindObjectOfType<Log>().previous_scene = scene; //Informs the log what the boss scene is called
            FindObjectOfType<Log>().boss = true; //Informs the log that this is a boss screen
        }
        else
        {
            if (FindObjectOfType<Log>().scene == scene)
            { //Positions the player into their previous position if they are still in the scene
                GameObject.Find("Player").transform.position = new Vector3(FindObjectOfType<Log>().player_x_pos, FindObjectOfType<Log>().player_y_pos, 0);
            }
            FindObjectOfType<Log>().scene = scene;//Informs the log what the scene is called
        }
        Destroy(gameObject);
    }
}
