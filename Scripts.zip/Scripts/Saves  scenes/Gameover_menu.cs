﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Gameover_menu : MonoBehaviour {
    public int gameover_menu_button = 0;
    public string scene;
    private int cooldown = 25;
    private bool phase_selection;
    private bool three_bars = true;
    public GameObject bar_2;
    public GameObject bar_3;
    public GameObject long_filler;
    public GameObject filler_1;
    public GameObject filler_2;
    public int finish_count = 0;
    public List<string> buttons = new List<string>();
    public List<GameObject> numbers = new List<GameObject>();
    public List<Sprite> numbersprites = new List<Sprite>();
    private Log log;
    private int i;
    void Start () {
        log = FindObjectOfType<Log>();
        scene = log.previous_scene;
        buttons = FindObjectOfType<Keybinds>().buttons;
        if(log.current_boss < 3)
        {
            three_bars = false;
            bar_2.transform.position = new Vector3(-1.8f, 2.1f, 0);
            Destroy(bar_3);
        }
        if (!log.bosses_completed[0])
        {
            numbers[1].transform.position = new Vector3(10, 10, 0);
            numbers[2].transform.position += new Vector3(0,0.1f, 0);
            numbers[3].transform.position += new Vector3(0, 0.1f, 0);
        }
        if (!log.bosses_completed[1])
        {
            Destroy(numbers[2].gameObject);
            numbers[2] = null;
            numbers[3].transform.position += new Vector3(0, 0.1f, 0);
        }
        if (!log.bosses_completed[2])
        {
            Destroy(numbers[3].gameObject);
            numbers[3] = null;
        }
    }//-1.8,1.84
    void Update()
    {
        if (finish_count == 0)
        {
            if (cooldown == 0)
            {
                if (!phase_selection)
                {
                    if (Input.GetKey(buttons[0]))
                    {
                        if (gameover_menu_button == 0)
                        {//Cycles the pointer round to the bottom if it is at the top
                            transform.position += new Vector3(0, -0.3f, 0);
                            gameover_menu_button = 3;
                        }
                        else
                        {//Moves the pointer one space up otherwise
                            transform.position += new Vector3(0, 0.1f, 0);
                            gameover_menu_button--;
                        }
                        cooldown = 25;
                    }
                    else if (Input.GetKey(buttons[1]))
                    {//Cycles the pointer round to the top if it is at the bottom
                        if (gameover_menu_button == 3)
                        {
                            transform.position += new Vector3(0, 0.3f, 0);
                            gameover_menu_button = 0;
                        }//Moves the pointer one space down otherwise
                        else
                        {
                            transform.position += new Vector3(0, -0.1f, 0);
                            gameover_menu_button++;
                        }
                        cooldown = 25;
                    }
                    if (Input.GetKeyDown(buttons[9]))
                    {
                        if (gameover_menu_button == 0)
                        {
                            if (log.boss_checkpoints[0][0] == 0 && log.boss_checkpoints[1][0] == 0)
                            {
                                finish_count = 50;
                            }
                            else
                            {
                                transform.position = new Vector3(-2.13f, 2.1f, 0);
                                if (log.boss_checkpoints[1][0] == 1)
                                {
                                    gameover_menu_button = 2;
                                    transform.position += new Vector3(0.66f, 0, 0);
                                    Number_change(1);
                                    filler_1.transform.position = new Vector3(-2, 2.1f, 0);
                                    filler_2.transform.position = new Vector3(-1.67f, 2.1f, 0);
                                }
                                else if (log.boss_checkpoints[0][0] == 1 && three_bars)
                                {
                                    filler_1.transform.position = new Vector3(-2, 2.1f, 0);
                                    gameover_menu_button = 1;
                                    transform.position += new Vector3(0.33f, 0, 0);
                                    Number_change(0);
                                }
                                else if (log.boss_checkpoints[0][0] == 1)
                                {
                                    long_filler.transform.position = new Vector3(-1.835f, 2.1f, 0);
                                    gameover_menu_button = 1;
                                    transform.position += new Vector3(0.66f, 0, 0);
                                    Number_change(0);
                                }
                                phase_selection = true;
                                FindObjectOfType<Camera>().transform.position = new Vector3(-1.8f, 1.84f, -10);
                            }
                        }
                        else if(gameover_menu_button == 1)
                        {

                        }
                        else if (gameover_menu_button == 2)
                        {
                            finish_count = 50;
                        }
                        else if (gameover_menu_button == 3)
                        {
                            Time.timeScale = 1;
                            Time.fixedDeltaTime = 0.02f;
                            Application.Quit();
                        }
                    }
                }
                else
                {
                    if (Input.GetKey(buttons[2]))
                    {
                        if (three_bars)
                        {
                            if (gameover_menu_button > 0)
                            {
                                gameover_menu_button--;
                                transform.position -= new Vector3(0.33f, 0, 0);
                            }
                            if(gameover_menu_button == 0)
                            {
                                filler_1.transform.position = new Vector3(10, 10, 0);
                                filler_2.transform.position = new Vector3(10, 10, 0);
                                for (i = 0;i < 4;i++)
                                {
                                    numbers[i].GetComponent<SpriteRenderer>().sprite = numbersprites[10];
                                }
                            }
                            else if (gameover_menu_button == 1)
                            {
                                Number_change(0);
                                filler_2.transform.position = new Vector3(10, 10, 0);
                            }
                        }
                        else
                        {
                            if (gameover_menu_button == 1)
                            {
                                gameover_menu_button--;
                                transform.position -= new Vector3(0.66f, 0, 0);
                            }
                            if (gameover_menu_button == 0)
                            {
                                long_filler.transform.position = new Vector3(10, 10, 0);
                            }
                        }
                        cooldown = 25;
                    }
                    if (Input.GetKey(buttons[3]))
                    {
                        if (three_bars)
                        {
                            if ((gameover_menu_button < 2 && log.boss_checkpoints[1][0] == 1)||gameover_menu_button < 1)
                            {
                                gameover_menu_button++;
                                transform.position += new Vector3(0.33f, 0, 0);
                            }
                            if (gameover_menu_button == 1)
                            {
                                filler_1.transform.position = new Vector3(-2, 2.1f, 0);
                                Number_change(0);
                            }
                            else if (gameover_menu_button == 2)
                            {
                                filler_1.transform.position = new Vector3(-2, 2.1f, 0);
                                filler_2.transform.position = new Vector3(-1.67f, 2.1f, 0);
                                Number_change(1);
                            }
                        }
                        else
                        {
                            if (gameover_menu_button == 0)
                            {
                                gameover_menu_button++;
                                transform.position += new Vector3(0.66f, 0, 0);
                            }
                            if (gameover_menu_button == 1)
                            {
                                long_filler.transform.position = new Vector3(-1.835f, 2.1f, 0);
                                Number_change(0);
                                Number_change(0);
                            }
                        }
                        cooldown = 25;
                    }
                    if (Input.GetKeyDown(buttons[9]))
                    {
                        if (gameover_menu_button == 0)
                        {
                            FindObjectOfType<Log>().boss_checkpoints[0][0] = 0;
                            FindObjectOfType<Log>().boss_checkpoints[1][0] = 0;
                        }
                        if (gameover_menu_button == 1)
                        {
                            FindObjectOfType<Log>().boss_checkpoints[1][0] = 0;
                        }
                        finish_count = 50;
                    }
                }
            }
            if (!Input.GetKey(buttons[0]) && !Input.GetKey(buttons[1]) && !Input.GetKey(buttons[9]) && !Input.GetKey(buttons[3]) && !Input.GetKey(buttons[2]))
            {
                cooldown = 0;
            }
            if (cooldown > 0)
            {
                cooldown--;
            }
        }
        else
        {
            if (finish_count == 50)
            {
                transform.position = new Vector3(0.4f, 2.8f, 0);
                FindObjectOfType<Camera>().transform.position = new Vector3(0.4f, 2.8f, -10);
            }
            if (!phase_selection && gameover_menu_button == 1)
            {
                transform.position += new Vector3(0, 0.01f, 0);
            }
            else
            {
                transform.position -= new Vector3(0, 0.01f, 0);
            }
            if (finish_count == 1)
            {
                if(!phase_selection && gameover_menu_button == 1)
                {

                }
                else if(!phase_selection && gameover_menu_button == 2)
                {
                    SceneManager.LoadScene(FindObjectOfType<Log>().scene);
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                }
                else
                {
                    SceneManager.LoadScene(scene);
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                }
            }
            finish_count--;
        }
    }
    private void Number_change(int index)
    {
        numbers[0].GetComponent<SpriteRenderer>().sprite = numbersprites[log.boss_checkpoints[index][1]];
        numbers[1].GetComponent<SpriteRenderer>().sprite = numbersprites[log.boss_checkpoints[index][2]];
        numbers[2].GetComponent<SpriteRenderer>().sprite = numbersprites[log.boss_checkpoints[index][3]];
        numbers[3].GetComponent<SpriteRenderer>().sprite = numbersprites[log.boss_checkpoints[index][4]];
    }
}
