﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class Scene_selector : MonoBehaviour
{
    public List<string> buttons = new List<string>();
    public int scene;
    public int page_turn;
    private int turn_count;
    private int opacity;
    public int page;
    public int option = 2;
    public int options;
    private int cooldown;
    public Transform pointer;
    public List<bool> available_pages = new List<bool>();
    public bool first_load;
    private int count;
    public float pos_dif;
    public float size_dif;
    private int loading;
    private bool loaded;
    private int i;
    //Scenes: 0: library, 1: Barracks, 2: Workshop, 3: Testing grounds, 4: Temple, 5: Lava caves, 6: Volcano, 7: School, 8: Caves
    // 9: Gatehouse, 10: Keep, 11: Tower
    private void Start()
    {
        first_load = FindObjectOfType<Log>().first_attempt;
        buttons = FindObjectOfType<Keybinds>().buttons;
        pos_dif = GameObject.Find("Blue book").transform.position.y - FindObjectOfType<Camera>().transform.position.y + 0.02f;
        size_dif = GameObject.Find("Blue book").transform.localScale.y - 0.0175f;
        if (first_load)
        { //Starts a starting animation if the menu has only just been loaded
            GameObject.Find("Blue book").transform.localScale = new Vector3(0.0175f, 0.0175f, 0);
            GameObject.Find("Blue book").transform.position = new Vector3(transform.position.x, FindObjectOfType<Camera>().transform.position.y + 0.02f, 0);
        }
        Log log = FindObjectOfType<Log>();
        List<bool> available_scenes = log.GetComponent<Log>().scenes_unlocked;
        page = log.scene_selector_page;
        available_pages[0] = true;
        if (available_scenes[1]) //Checks if the first option in each page is available, and allows that page to be used if they are
        {
            available_pages[1] = true;
        }
        if (available_scenes[4])
        {
            available_pages[2] = true;
        }
        if (available_scenes[7])
        {
            available_pages[3] = true;
        }
        if (available_scenes[9])
        {
            available_pages[4] = true;
        }
        if (available_scenes[10])
        {
            available_pages[5] = true;
        }
        if (page == 0) //Fills in the text boxes with the correct words
        {
            options = 1;
            GameObject.Find("Middle_title").GetComponent<Text>().text = "The Library";
            GameObject.Find("Middle_main").GetComponent<Text>().text = "The fourth city of the fire god's kingdom contains a huge library within its castle's walls. It is so central to the life there that librarian of it is a royally decreed title.";
        }
        if (page == 1 && available_scenes[1])
        {
            options = 1;
            GameObject.Find("Middle_title").GetComponent<Text>().text = "The Barracks";
            GameObject.Find("Middle_main").GetComponent<Text>().text = "In the West of the castle, the royal barracks are located. It is where the strongest of the kingdom's warrior are trained, and is also the home of its primary courthouse and prison";
        }
        if (page == 1 && available_scenes[2])
        {
            options = 2;
            GameObject.Find("Bottom_title").GetComponent<Text>().text = "The Workshop";
            GameObject.Find("Bottom_main").GetComponent<Text>().text = "The caves beneath the barracks have been converted under the control of multiple successive mechanics into a convoluted underground workshop";
        }
        if (page == 1 && available_scenes[3])
        {
            options = 3;
            GameObject.Find("Top_title").GetComponent<Text>().text = "Testing grounds";
            GameObject.Find("Top_main").GetComponent<Text>().text = "The barracks house a large, empty room that the mechanic uses to gauge the effectiveness of their larger -and more powerful- contraptions.";
        }

        if (page == 2 && available_scenes[4])
        {
            options = 1;
            GameObject.Find("Middle_title").GetComponent<Text>().text = "The Temple";
            GameObject.Find("Middle_main").GetComponent<Text>().text = "The site for the castle was chosen due to the towering volcano located within it. Over many generations, a huge temple has been built around it, nearly reaching its peak.";
        }
        if (page == 2 && available_scenes[5])
        {
            options = 2;
            GameObject.Find("Bottom_title").GetComponent<Text>().text = "Magma caves";
            GameObject.Find("Bottom_main").GetComponent<Text>().text = "The temple's caves are mostly untouched, due to the majority of construction efforts being directed to the above ground structure.";
        }
        if (page == 2 && available_scenes[6])
        {
            options = 3;
            GameObject.Find("Top_title").GetComponent<Text>().text = "Volcano";
            GameObject.Find("Top_main").GetComponent<Text>().text = "The volcano is filled nearly to the brim with magma. Particularly zealous worshippers will enter it to attempt to worship the Core Angel.";
        }
        if (page == 3 && available_scenes[7])
        {
            options = 1;
            GameObject.Find("Middle_title").GetComponent<Text>().text = "Magic school";
            GameObject.Find("Middle_main").GetComponent<Text>().text = "Magical ability is considered a valuable talent within the kingdom. As such, a school for it is housed by the castle. An observatory has been built on the top as part of the Headmaster's pet project.";
        }
        if (page == 3 && available_scenes[8])
        {
            options = 2;
            GameObject.Find("Bottom_title").GetComponent<Text>().text = "Crystal caves";
            GameObject.Find("Bottom_main").GetComponent<Text>().text = "The caves that riddle the planet's surface are preserved, being considered important for study by the school. Some would consider it unwise to leave them unguarded...";
        }
        if (page == 4)
        {
            options = 1;
            GameObject.Find("Middle_title").GetComponent<Text>().text = "The Gatehouse";
            GameObject.Find("Middle_main").GetComponent<Text>().text = "The castle's gatehouse is its only entrance. Though small in proportion to the massive castle, it has withstood every assault thrown at it.";
        }
        if (page == 5 && available_scenes[10])
        {
            options = 1;
            GameObject.Find("Middle_title").GetComponent<Text>().text = "The Keep";
            GameObject.Find("Middle_main").GetComponent<Text>().text = "The keep is the strongest structure in the castle. It is home to many of the high ranked individuals in the kingdom. The King resides within its throne room.";
        }
        if (page == 5 && available_scenes[11])
        {
            options = -2;
            GameObject.Find("Top_title").GetComponent<Text>().text = "The Tower";
            GameObject.Find("Top_main").GetComponent<Text>().text = "Capping the keep, the tower stretches high above it. It is the point of origin of the spell, and the location of its caster.";
        }
        GetComponent<Animator>().SetFloat("Blend", page);
        if ((page == 1 && available_scenes[3]) || (page == 2 && available_scenes[6]) || (page == 5 && available_scenes[11]))
        { 
            GameObject.Find("Top_border").GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, opacity * 0.01f);
            GameObject.Find("Top_title").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
            GameObject.Find("Top_main").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
        }
        if ((page == 1 && available_scenes[2]) || (page == 2 && available_scenes[5]) || (page == 3 && available_scenes[8]))
        {
            GameObject.Find("Bottom_border").GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, opacity * 0.01f);
            GameObject.Find("Bottom_title").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
            GameObject.Find("Bottom_main").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
        }//Makes the first and last options on the page start to fade in if they have been unlocked
        GameObject.Find("Pointer").GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, opacity * 0.01f);
        GameObject.Find("Middle_border").GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, opacity * 0.01f);
        GameObject.Find("Middle_title").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
        GameObject.Find("Middle_main").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
        GetComponent<SpriteRenderer>().color = new Color(opacity * 0.01f, opacity * 0.01f, 1f, opacity * 0.01f);
        //Makes everything else start to fade in
    }
    void Update()
    {
        if (first_load)
        {
            if (count < 100)
            {
                count++;
                GameObject.Find("Blue book").transform.position += new Vector3(0, 0.01f, 0) * pos_dif;
                GameObject.Find("Blue book").transform.localScale += new Vector3(0.01f, 0.01f, 0) * size_dif;
            }
            else
            {
                SceneManager.LoadScene("Scene selector");
                count = 0;
                first_load = false;
                FindObjectOfType<Log>().first_attempt = false;
            } //Plays an animation if the book is being opened.
        }
        else
        {
            if (opacity < 100)
            {
                opacity++;
                List<bool> available_scenes = FindObjectOfType<Log>().scenes_unlocked;
                if ((page == 1 && available_scenes[3]) || (page == 2 && available_scenes[6]) || (page == 5 && available_scenes[11]))
                {
                    GameObject.Find("Top_border").GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, opacity * 0.01f);
                    GameObject.Find("Top_title").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
                    GameObject.Find("Top_main").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
                }
                if ((page == 1 && available_scenes[2]) || (page == 2 && available_scenes[5]) || (page == 3 && available_scenes[8]))
                {
                    GameObject.Find("Bottom_border").GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, opacity * 0.01f);
                    GameObject.Find("Bottom_title").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
                    GameObject.Find("Bottom_main").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
                }
                GameObject.Find("Pointer").GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, opacity * 0.01f);
                GameObject.Find("Middle_border").GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, opacity * 0.01f);
                GameObject.Find("Middle_title").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
                GameObject.Find("Middle_main").GetComponent<Text>().color = new Color(0, 0, 0, opacity * 0.01f);
                GetComponent<SpriteRenderer>().color = new Color(opacity * 0.01f, opacity * 0.01f, 1f, opacity * 0.01f);
            } //Fades in the unlocked options 
            if (!Input.GetKey(buttons[1]) && !Input.GetKey(buttons[0]))
            {
                cooldown = 0; //Allows the player to remove the keys and press them down again to navigate faster
            }
            if (opacity > 25 && cooldown == 0) //Only allows the selection of options if the scene has not only just loaded and the pointer has not just been moved
            {
                if (Input.GetKeyDown(buttons[9]))
                {
                    loading = 1; //Informs the scene to play an animation
                }
                if (loaded)
                { //Loads the correct scene once the animation is finished
                    FindObjectOfType<Log>().first_attempt = true;
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                    if (FindObjectOfType<Pause_menu>() != null)
                    {
                        FindObjectOfType<Pause_menu>().menu_exists = false;
                    }
                    if (page == 0)
                    {
                        SceneManager.LoadScene("Start library");
                    }
                    if (page == 1)
                    {
                        if (option == 1)
                        {
                            SceneManager.LoadScene("Tower boss");
                        }
                        if (option == 2)
                        {
                            SceneManager.LoadScene("Training grounds");
                        }
                        if (option == 3)
                        {
                            SceneManager.LoadScene("Workshop");
                        }
                    }
                    if (page == 2)
                    {
                        if (option == 1)
                        {
                            SceneManager.LoadScene("Angel boss");
                        }
                        if (option == 2)
                        {
                            SceneManager.LoadScene("Temple");
                        }
                        if (option == 3)
                        {
                            SceneManager.LoadScene("Lava caves");
                        }
                    }
                    if (page == 3)
                    {
                        if (option == 1)
                        {
                            SceneManager.LoadScene("Cave");
                        }
                        if (option == 2)
                        {
                            SceneManager.LoadScene("Geomancy school");
                        }
                    }
                    if (page == 4)
                    {
                        SceneManager.LoadScene("Gatehouse boss");
                    }
                    if (page == 5)
                    {
                        if (option == 1)
                        {
                            SceneManager.LoadScene("Tower");
                        }
                        if (option == 2)
                        {
                            SceneManager.LoadScene("Boss room");
                        }
                    }
                }
                if (options == 2) //Only allows the pointer to move to options that have been unlocked
                {
                    if (Input.GetKey(buttons[0]))
                    {
                        if (option == 2)
                        {
                            pointer.position -= new Vector3(0, 4.1f, 0);
                            option = 3;
                        }
                        else
                        {
                            pointer.position += new Vector3(0, 4.1f, 0);
                            option--;
                        }
                        cooldown = 15;
                    }
                    if (Input.GetKey(buttons[1]))
                    {
                        if (option == 3)
                        {
                            pointer.position += new Vector3(0, 4.1f, 0);
                            option = 2;
                        }
                        else
                        {
                            pointer.position -= new Vector3(0, 4.1f, 0);
                            option++;
                        }
                        cooldown = 15;
                    }
                }
                if (options == 3)
                {
                    if (Input.GetKey(buttons[0]))
                    {
                        if (option == 1)
                        {
                            pointer.position -= new Vector3(0, 4.1f * 2, 0);
                            option = 3;
                        }
                        else
                        {
                            pointer.position += new Vector3(0, 4.1f, 0);
                            option--;
                        }
                        cooldown = 15;
                    }
                    if (Input.GetKey(buttons[1]))
                    {
                        if (option == 3)
                        {
                            pointer.position += new Vector3(0, 4.1f * 2, 0);
                            option = 1;
                        }
                        else
                        {
                            pointer.position -= new Vector3(0, 4.1f, 0);
                            option++;
                        }
                        cooldown = 15;
                    }
                }
                if (options == -2)
                {
                    if (Input.GetKey(buttons[0]))
                    {
                        if (option == 1)
                        {
                            pointer.position -= new Vector3(0, 4.1f, 0);
                            option = 2;
                        }
                        else
                        {
                            pointer.position += new Vector3(0, 4.1f, 0);
                            option--;
                        }
                        cooldown = 15;
                    }
                    if (Input.GetKey(buttons[1]))
                    {
                        if (option == 2)
                        {
                            pointer.position += new Vector3(0, 4.1f, 0);
                            option = 1;
                        }
                        else
                        {
                            pointer.position -= new Vector3(0, 4.1f, 0);
                            option++;
                        }
                        cooldown = 15;
                    }
                }
                if (Input.GetKey(buttons[2]))
                {
                    if (page != 0) //Turns the page to the previous page if it is available
                    {
                        for (i = page - 1; i >= 0; i--)
                        {
                            if (available_pages[i])
                            { //Loads the scene of the previous page after an animation
                                FindObjectOfType<Log>().scene_selector_page = i;
                                page_turn = 2;
                                break;
                            }
                        }
                    }
                    cooldown = 15;
                }
                if (Input.GetKey(buttons[3]))
                {
                    if (page != 5)
                    {
                        for (i = page + 1; i <= 5; i++)
                        {
                            if (available_pages[i])
                            {//Loads the scene of the next page after an animation
                                FindObjectOfType<Log>().scene_selector_page = i;
                                page_turn = 1;
                                break;
                            }
                        }
                    }
                    cooldown = 15;
                }
            }
        if (loading > 0)
        {
            if (loading <= 110)
            { //Plays the animation of the book shrinking
                loading++;
                
                    if (GameObject.Find("Blue book").transform.localScale.y > 0)
                    {
                        GameObject.Find("Blue book").transform.position += new Vector3(0, -0.01f, 0) * pos_dif;
                        GameObject.Find("Blue book").transform.localScale += new Vector3(-0.01f, -0.01f, 0) * size_dif;
                    }
                    else
                    {
                        FindObjectOfType<Background_darkness>().GetComponent<SpriteRenderer>().sortingLayerName = "Death layer";
                    }
                }
            else
            {
                loaded = true;
            }
        }
        if (cooldown > 0)
        {
            cooldown--;
        }
        if (page_turn == 1)
        { //Plays an animation of the page turning by rotating the page around the middle of the book
            if (turn_count < 100 && turn_count >= 55)
            {
                GameObject.Find("Page").transform.RotateAround(new Vector3(-0.04f, 0, 0), new Vector3(0, 1, 0), 4f);
            }
            if (turn_count == 78)
            {
                GameObject.Find("Icon").GetComponent<SpriteRenderer>().sortingOrder = 0;
                GameObject.Find("Blue_left_page_2").GetComponent<SpriteRenderer>().sortingOrder = 5;
                GameObject.Find("Unlined_page").GetComponent<SpriteRenderer>().sortingOrder = 4;
            }
            if (turn_count == 100)
            {
                SceneManager.LoadScene("Scene selector");
                Time.timeScale = 1;
                Time.fixedDeltaTime = 0.02f;
            }
            turn_count++;
        }
        else if (page_turn == 2)
        {
            if (turn_count < 100 && turn_count >= 55)
            {
                GameObject.Find("Blue_left_page").transform.RotateAround(new Vector3(-0.04f, 0, 0), new Vector3(0, 1, 0), -4f);
            }
            if (turn_count == 78)
            {
                GameObject.Find("Page_2").GetComponent<SpriteRenderer>().sortingOrder = 5;
                GameObject.Find("Unlined_page_2").GetComponent<SpriteRenderer>().sortingOrder = 4;
            }
            if (turn_count == 100)
            {
                SceneManager.LoadScene("Scene selector");
                Time.timeScale = 1;
                Time.fixedDeltaTime = 0.02f;
            }
            turn_count++;
        }
    }
}
}
