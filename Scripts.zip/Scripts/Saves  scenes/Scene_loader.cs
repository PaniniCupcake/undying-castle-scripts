﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Scene_loader : MonoBehaviour
{
    public string scene;
    private int count;
    void Update()
    {
        if (count == 60)
        {
            FindObjectOfType<Log>().player_x_pos = GameObject.Find("Player").transform.position.x;
            FindObjectOfType<Log>().player_y_pos = GameObject.Find("Player").transform.position.y; //Records the player's current position
            if (FindObjectOfType<Pause_menu>() != null)
            {
                FindObjectOfType<Pause_menu>().menu_exists = false; //Destroys the pause menu if the player has somehow loaded it 
            }
            SceneManager.LoadScene(scene); //Loads the new scene
            Time.timeScale = 1;
            Time.fixedDeltaTime = 0.02f;
        }
        if (count == 30)
        {
            FindObjectOfType<Background_darkness>().GetComponent<SpriteRenderer>().sortingLayerName = "Death_layer"; //Cuts the screen to only black
            if (GameObject.FindWithTag("Book") != null)
            {
                GameObject.FindWithTag("Book").GetComponent<SpriteRenderer>().sortingLayerName = "Death_layer"; //Makes only the book visible
            }
        }
        if (FindObjectOfType<Camera_follow>() != null)
        {
            FindObjectOfType<Camera_follow>().following = false; //Makes the camera aim at any books that may be in existence
        }
        count++;
    }
}
