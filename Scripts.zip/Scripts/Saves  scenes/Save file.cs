﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[System.Serializable]
public class Save_file
{
    public string previous_scene;
    public string scene;
    public int page;
    public float player_x_pos;
    public float player_y_pos;
    public bool[,] puzzles_completed = new bool[7,5];
    public bool[] bosses_completed = new bool[7];
    public bool[] scenes_unlocked = new bool[12];
    public string[] buttons = new string[10];
    public bool[] endings = new bool[64];
    public int[,] boss_checkpoints = new int[2,8]; // dont forgeat to make 2d
    public int current_boss;
    public bool[,] text_trees = new bool[100, 20];
    public Save_file(Log log, Keybinds keybinds,bool keys_only)
    {
        int i = new int();
        int j = new int();
        if (!keys_only)
        {
            previous_scene = log.previous_scene; //Stores all the data that was in the log 
            scene = log.scene;
            player_x_pos = log.player_x_pos;
            player_y_pos = log.player_y_pos; 
            page = log.scene_selector_page;
            current_boss = log.current_boss;
            for (i = 0; i < 7; i++)
            {
                for (j = 0; j < 5; j++)
                {
                    puzzles_completed[i, j] = log.puzzles_completed[i][j]; //Converts the lists in the log to arrays
                }
            }
            for (i = 0; i < 7; i++)
            {
                bosses_completed[i] = log.bosses_completed[i];
            }
            for (i = 0; i < 12; i++)
            {
                scenes_unlocked[i] = log.scenes_unlocked[i];
            }
            for(i = 0; i < 64;i++)
            {
                endings[i] = log.endings[i];
            }
            for(i = 0; i < 8;i++)
            {
                boss_checkpoints[0, i] = log.boss_checkpoints[0][i];
                boss_checkpoints[1, i] = log.boss_checkpoints[1][i];
            }
            for (i = 0; i < 100; i++)
            {
                for (j = 0; j < 20; j++)
                {
                    text_trees[i,j] = log.text_trees[i][j];
                }
            }
        }
        for (i = 0; i < 10; i++)
        {
            buttons[i] = keybinds.buttons[i];
        }
    }
}
