﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Start_menu_pointer : MonoBehaviour
{
    public List<string> buttons = new List<string>();
    public int menu_button = 1;
    private int cooldown = 10;
    public GameObject the_log;
    public GameObject key_log;
    public int counter = 0;
    private bool new_game;
    public GameObject text;
    public GameObject pause_menu;
    public List<bool> endings = new List<bool>();
    private void Awake()
    {
        if (FindObjectOfType<Log>() == null)
        {
            Instantiate(the_log, new Vector3(0, 0, 0), Quaternion.identity);
        }
        if(FindObjectOfType<Keybinds>() == null)
        {
            Instantiate(key_log,new Vector3(0, 0, 0), Quaternion.identity);
        }
        buttons = FindObjectOfType<Keybinds>().buttons;
    }
    void Update()
    {
        if(counter > 10)
        {
            if (counter == 20)
            {
                if (new_game)
                {
                    SceneManager.LoadScene("Start library");
                    Log log = FindObjectOfType<Log>();
                    Keybinds keybinds = FindObjectOfType<Keybinds>();
                    Save_system.Save(log, keybinds, false);
                }
                else
                {
                    SceneManager.LoadScene(FindObjectOfType<Log>().scene);
                }
            }
            counter++;
        }
        else if(counter < 10)
        {
            counter++;
            if(counter == 10)
            {
                Log log = FindObjectOfType<Log>();
                Keybinds keybinds = FindObjectOfType<Keybinds>();
                Save_file save = Save_system.Load(log, keybinds);
                int i = new int();
                for (i = 0; i < 10; i++)
                {
                    keybinds.buttons[i] = save.buttons[i];
                }
            }
        }
        if (cooldown == 0 && FindObjectOfType<Display_text>() == null && FindObjectOfType<Pause>() == null)
        {
            if (Input.GetKeyDown(buttons[0]))
            {
                if (menu_button == 1)
                {
                    transform.position += new Vector3(0, -0.96f, 0);
                    menu_button = 5;
                }
                else
                {
                    transform.position += new Vector3(0, 0.24f, 0);
                    menu_button--;
                }
                cooldown = 15;
            }
            else if (Input.GetKeyDown(buttons[1]))
            {
                if (menu_button == 5)
                {
                    transform.position += new Vector3(0, 0.96f, 0);
                    menu_button = 1;
                }
                else
                {
                    transform.position += new Vector3(0, -0.24f, 0);
                    menu_button++;
                }
                cooldown = 15;
            }
            if (Input.GetKeyDown(buttons[9]))
            {
                if (menu_button == 1)
                {
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                    Log log = FindObjectOfType<Log>();
                    Keybinds keybinds = FindObjectOfType<Keybinds>();
                    Save_file save = Save_system.Load(log,keybinds);
                    log.previous_scene = save.previous_scene;
                    log.scene = save.scene;
                    log.player_x_pos = save.player_x_pos;
                    log.player_y_pos = save.player_y_pos;
                    log.scene_selector_page = save.page;
                    int i = new int();
                    int j = new int();
                    for (i = 0; i < 6; i++)
                    {
                        for (j = 0; j < 5; j++)
                        {
                            log.puzzles_completed[i][j] = save.puzzles_completed[i,j];
                        }
                    }
                    for (i = 0; i < 7; i++)
                    {
                        log.bosses_completed[i] = save.bosses_completed[i];
                    }
                    for (i = 0; i < 12; i++)
                    {
                        log.scenes_unlocked[i] = save.scenes_unlocked[i];
                    }
                    for (i = 0; i < 10; i++)
                    {
                        keybinds.buttons[i] = save.buttons[i];
                    }
                    log.current_boss = save.current_boss;
                    for (i = 0; i < 8; i++)
                    {
                        log.boss_checkpoints[0][i] = save.boss_checkpoints[0,i];
                        log.boss_checkpoints[1][i] = save.boss_checkpoints[1,i];
                    }
                    for (i = 0; i < 100; i++)
                    {
                        for (j = 0; j < 20; j++)
                        {
                            log.text_trees[i][j] = save.text_trees[i,j];
                        }
                    }
                    new_game = false;
                    counter = 11;
                }
                else if (menu_button == 2)
                {
                    Time.timeScale = 1;
                    Time.fixedDeltaTime = 0.02f;
                    Log log = FindObjectOfType<Log>();
                    endings = log.endings;
                    Destroy(log.gameObject);
                    Instantiate(the_log, new Vector3(0, 0, 0), Quaternion.identity).GetComponent<Log>().endings = endings;
                    Save_system.Save(log, FindObjectOfType<Keybinds>(), false);
                    counter = 11;
                    new_game = true;
                }
                else if(menu_button == 3)
                {
                    Instantiate(text, new Vector3(0, -3, 10) + FindObjectOfType<Camera>().transform.position, Quaternion.identity).transform.localScale = new Vector3(0.25f, 0.25f, 0) *  FindObjectOfType<Camera>().orthographicSize;
                }
                else if(menu_button == 4)
                {
                    FindObjectOfType<Pause_menu>().pause = true;
                }
                else if (menu_button == 5)
                {
                    Log log = FindObjectOfType<Log>();
                    Keybinds keybinds = FindObjectOfType<Keybinds>();
                    Save_file save = Save_system.Load(log, keybinds);
                    log.previous_scene = save.previous_scene;
                    log.scene = save.scene;
                    log.player_x_pos = save.player_x_pos;
                    log.player_y_pos = save.player_y_pos;
                    int i = new int();
                    int j = new int();
                    for (i = 0; i < 6; i++)
                    {
                        for (j = 0; j < 5; j++)
                        {
                            log.puzzles_completed[i][j] = save.puzzles_completed[i, j];
                        }
                    }
                    for (i = 0; i < 7; i++)
                    {
                        log.bosses_completed[i] = save.bosses_completed[i];
                    }
                    for (i = 0; i < 12; i++)
                    {
                        log.scenes_unlocked[i] = save.scenes_unlocked[i];
                    }
                    for (i = 0; i < 10; i++)
                    {
                        keybinds.buttons[i] = save.buttons[i];
                    }
                    log.current_boss = save.current_boss;
                    for (i = 0; i < 8; i++)
                    {
                        log.boss_checkpoints[0][i] = save.boss_checkpoints[0, i];
                        log.boss_checkpoints[1][i] = save.boss_checkpoints[1, i];
                    }
                    Save_system.Save(log, keybinds,false);
                    Application.Quit();
                }
            }
        }
        if (Input.GetAxis("Vertical") == 0)
        {
            cooldown = 0;
        }
        if (cooldown > 0)
        {
            cooldown--;
        }
    }
}
