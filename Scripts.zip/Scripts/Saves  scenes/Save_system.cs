﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
public static class Save_system
{
    public static void Save (Log log, Keybinds keybinds, bool keys_only)
    {//Saves the game and creates / overwrites a save file for it
        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + "/save_file";
        FileStream stream = new FileStream(path, FileMode.Create); 
        Save_file save = new Save_file(log, keybinds,keys_only);
        formatter.Serialize(stream, save);
        stream.Close();
    }
    public static Save_file Load(Log log, Keybinds keybinds)
    {
        string path = Application.persistentDataPath + "/save_file";
        if(File.Exists(path))
        {//Gets the data from the existing file if it exists
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);
            Save_file save = formatter.Deserialize(stream) as Save_file;
            stream.Close();
            return save; //Returns the data stored in the save file
        }
        else
        {//Creates a new empty save file for the game if one doesn't exist
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Create);
            Save_file save = new Save_file(log, keybinds, false);
            formatter.Serialize(stream, save); 
            stream.Close();
            return save;//Returns the data stored in the save file
        }
    }
}
