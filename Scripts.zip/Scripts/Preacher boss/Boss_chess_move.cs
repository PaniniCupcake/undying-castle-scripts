﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss_chess_move : MonoBehaviour
{
    private int count;
    private int count2;
    public int mod;
    public int interval;
    public Rigidbody2D rb;
    public int health = 3;
    public Animator animator;
    private int damage_cooldown;
    public string hurtbox;
    public Sprite on;
    public Sprite off;
    void FixedUpdate()
    {
        if(count < 108)
        {
            transform.position += new Vector3(0,0.02f, 0);//Moves the object into vertical position 
            gameObject.GetComponent<CircleCollider2D>().enabled = false;//Prevents walls from stopping its movement
        }
        else if(count < 216)
        {
            transform.position += new Vector3(0.02f * mod, 0, 0);//Moves the object into horizontal position
        }
        else if(count == 216)
        {
            gameObject.GetComponent<CircleCollider2D>().enabled = true;//Lets the object start being stopped from walls once it is in position
        }
        else
        {
            if ((count - 225) % 400 == interval || (count - 225) % 400  == interval + 100)
            {//Moves the black piece then white piece twice in alternation
                Transform player_pos = GameObject.Find("Player").transform;
                GameObject hbox = GameObject.Find(hurtbox);
                hbox.tag = "Base_damaging";
                GetComponent<SpriteRenderer>().sprite = on;
                float x_dif = player_pos.position.x - transform.position.x;
                float y_dif = player_pos.position.y - transform.position.y;
                if (Mathf.Abs(y_dif) > Mathf.Abs(x_dif))
                {
                    rb.velocity = new Vector3(x_dif / (Mathf.Abs(y_dif)/4), y_dif / (Mathf.Abs(y_dif)/4), 0.0f);
                }
                else
                {
                    rb.velocity = new Vector3(x_dif / (Mathf.Abs(x_dif)/4), y_dif / (Mathf.Abs(x_dif)/4), 0.0f);
                }
            }
            else if((count - 225) == interval + 50|| (count - 225) == interval + 150)
            {//Stops the object's movement after it has moved for a few frames after it has started moving
                GetComponent<SpriteRenderer>().sprite = off;
                rb.velocity = new Vector3(0,0,0);
                GameObject hbox = GameObject.Find(hurtbox);//Stops the object from hurting the player while it isn't moving
                hbox.tag = "Untagged";
            }
        }
        count++;
        if(health <= 0)
        {
            rb.velocity = new Vector3(0, 0, 0);
            GameObject hbox = GameObject.Find(hurtbox);//Stops the object from hurting the player and moving when it is being destroyed
            hbox.tag = "Untagged";
            animator.SetBool("Destroyed", true);
            if (count2 == 50)
            { 
                Destroy(gameObject);
            } //Allows the animation to play before the object itself is destroyed
            count2++;
        }
        if (damage_cooldown > 0)
        {
            damage_cooldown--;
        }
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player_attack"))
        {
            if (damage_cooldown == 0) //Stops the object from taking damage twice from the same attack
            {
                if (health > 0)
                {//Damages the object if the player's attack hits it
                    health -= 1; 
                    damage_cooldown = 20;
                    FindObjectOfType<Preacher_attack_pattern>().Boss_bar_move(); //Informs the boss bar that the object has taken damage
                }
            }
        }
    }
}
