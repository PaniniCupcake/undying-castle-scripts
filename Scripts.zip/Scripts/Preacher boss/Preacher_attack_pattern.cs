﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class Preacher_attack_pattern : MonoBehaviour
{
    public int count;
    public int count2;
    public Transform player_pos;
    public GameObject aiming_orb;
    public GameObject homing_orb;
    public GameObject moving_orb_left;
    public GameObject moving_orb_right;
    public GameObject single_laser_orb;
    public GameObject single_laser_orb_off;
    public GameObject quadruple_laser_orb_area_deny;
    public GameObject quadruple_laser_orb;
    public GameObject white_king;
    public GameObject black_king;
    public GameObject homing_laser_single;
    public GameObject quadruple_laser_orb_off;
    public GameObject delayed_aiming_orb;
    public GameObject pedestal;
    public Transform player;
    public Animator animator;
    public GameObject loss_text;
    public GameObject boss_bar_part;
    public float bar_position = 34.12f;
    public int attack_phase;
    public bool transitioning;
    public int cooldown = -1;
    private float i;
    public int health;
    private bool damageable;
    private int acceleration;
    void FixedUpdate()
    {
        if (attack_phase == 1)
        {
            if(count % 130 == 0 && count!=0)
            {
                Boss_bar_move();//Moves the boss bar as the attack progresses
            }
            if (count >= 650)
            {
                transitioning = true;
                count = 651;
                if (cooldown == -1)
                {
                    Boss_bar_move();
                    cooldown = 150;
                }
            }
            else
            {
                count++;
            }
            if (count % 100 == 0)
            {//Creates orbs that move towards the player around it in a diamond shape
                animator.SetFloat("Direction", 3);
                Instantiate(aiming_orb, new Vector3(player.position.x + 3, player.position.y, 0), Quaternion.identity);
                Instantiate(aiming_orb, new Vector3(player.position.x + 1.5f, player.position.y + 1.5f, 0), Quaternion.identity);
                Instantiate(aiming_orb, new Vector3(player.position.x - 3, player.position.y, 0), Quaternion.identity);
                Instantiate(aiming_orb, new Vector3(player.position.x, player.position.y + 3, 0), Quaternion.identity);
                Instantiate(aiming_orb, new Vector3(player.position.x, player.position.y - 3, 0), Quaternion.identity);
                Instantiate(aiming_orb, new Vector3(player.position.x + 1.5f, player.position.y - 1.5f, 0), Quaternion.identity);
                Instantiate(aiming_orb, new Vector3(player.position.x - 1.5f, player.position.y + 1.5f, 0), Quaternion.identity);
                Instantiate(aiming_orb, new Vector3(player.position.x - 1.5f, player.position.y - 1.5f, 0), Quaternion.identity);
            }
            if (count % 100 == 50)
            {
                animator.SetFloat("Direction", 0);
            }
        }
        if (attack_phase == 2)
        {
            if (count % 100 == 50)
            {
                animator.SetFloat("Direction", 0);
            }
            if (count % 100 == 0)
            {
                for (i = 7.25f; i >= 0.22f; i -= 0.5f)
                {//Instantiates orbs in a pattern along the left and right of the arena that move to the other side
                    if (count2 % 6 <= 2)
                    {
                        Instantiate(moving_orb_left, new Vector3(36.42f, i, 0), Quaternion.identity);
                    }
                    else
                    {
                        Instantiate(moving_orb_right, new Vector3(28.39f, i, 0), Quaternion.identity);
                    }
                    count2++;
                }
                animator.SetFloat("Direction", 3);
                count2 = 0;
            }
            if(count % 120 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count >= 600)
            {
                transitioning = true;
                count = 601;
                if (cooldown == -1)
                {
                    Boss_bar_move();
                    cooldown = 150;
                }
            }
            else
            {
                count++;
            }
        }
        if (attack_phase == 3)
        {
            if (count == 0)
            {
                animator.SetFloat("Direction", 1);
                var orb = Instantiate(single_laser_orb_off, new Vector3(28.39f, 3.24f, 0), Quaternion.identity);
                orb.GetComponent<Moving_orb>().x_mod = 2;
            }
            if (FindObjectOfType<Moving_orb>() != null && FindObjectOfType<Moving_orb>().transform.position.x >= 32.4f)
            {
                animator.SetFloat("Direction", 0);
                Instantiate(single_laser_orb, FindObjectOfType<Moving_orb>().transform.position, FindObjectOfType<Moving_orb>().transform.rotation);
                Destroy(FindObjectOfType<Moving_orb>().gameObject);
            }
            count++;
            if(count % 200 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count >= 1000)
            {
                transitioning = true;
                Destroy(GameObject.Find("Laser_orb_single(Clone)"));
                if (cooldown == -1)
                {
                    Boss_bar_move();
                    cooldown = 50;
                }
                count = 1001;
            }
        }
        if (attack_phase == 4)
        {
            if (count == 0)
            {
                animator.SetFloat("Direction", 3);
                var orb = Instantiate(single_laser_orb_off, new Vector3(28.39f, 3.24f, 0), Quaternion.identity);
                orb.GetComponent<Moving_orb>().x_mod = 2;
                var orb2 = Instantiate(single_laser_orb_off, new Vector3(36.42f, 3.24f, 0), Quaternion.identity);
                orb2.GetComponent<Moving_orb>().x_mod = -2;
            }
            if (count == 50)
            {
                animator.SetFloat("Direction", 0);
                Moving_orb orb = FindObjectOfType<Moving_orb>();
                Instantiate(single_laser_orb, orb.transform.position, orb.transform.rotation);
                Destroy(orb.gameObject);
            }
            if (count == 51)
            {
                animator.SetFloat("Direction", 0);
                Moving_orb orb = FindObjectOfType<Moving_orb>();
                Instantiate(single_laser_orb, orb.transform.position, orb.transform.rotation);
                FindObjectOfType<Spinning_laser_orb>().rotate_speed = 1;
                Destroy(orb.gameObject);
            }
            count++;
            if (count % 200 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count >= 1000)
            {
                transitioning = true;
                Destroy(GameObject.Find("Laser_orb_single(Clone)"));
                if (cooldown == -1)
                {
                    Boss_bar_move();
                    cooldown = 50;
                }
                count = 1001;
            }
            if (count == 999)
            {
                Destroy(GameObject.Find("Laser_orb_single(Clone)"));
            }
        }
        if (attack_phase == 5)
        {
            if (count % 30 == 0)
            {
                var orb = Instantiate(moving_orb_right, new Vector3(28.39f, player_pos.position.y), Quaternion.identity);
                orb.GetComponent<Moving_orb>().x_mod = 4;
                animator.SetFloat("Direction", 1);
            }
            if (count % 30 == 15)
            {
                var orb = Instantiate(moving_orb_right, new Vector3(36.42f, player_pos.position.y), Quaternion.identity);
                orb.GetComponent<Moving_orb>().x_mod = -4;
                animator.SetFloat("Direction", 2);
            }
            if(count % 150 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count >= 750)
            {
                if (cooldown == -1)
                {
                    cooldown = 150;
                    Boss_bar_move();
                }
                count = 751;
                transitioning = true;
            }
            else
            {
                count++;
            }
        }
        if (attack_phase == 6)
        {
            if (count == 0)
            {
                Instantiate(quadruple_laser_orb_area_deny, transform.position + new Vector3(0, 10, 0), Quaternion.identity);
                count++;
                animator.SetFloat("Direction", 3);
            }
            if (count == 320)
            {
                Instantiate(white_king, new Vector3(27.3f, 3.12f, 0), Quaternion.identity);
                Instantiate(black_king, new Vector3(37.5f, 3.12f, 0), Quaternion.identity);
            }
            if(count == 428)
            {
                animator.SetFloat("Direction", 0);
            }
            if (count == 600)
            {
                Destroy(GameObject.Find("Laser_orb_quadruple_descend(Clone)"));
            }
            count++;
            if (count > 400 && GameObject.Find("White_king(Clone)") == null && GameObject.Find("Black_king(Clone)") == null)
            {
                transitioning = true;
                if (cooldown == -1)
                {
                    animator.SetFloat("Direction", 1);
                    cooldown = 100;
                    Boss_bar_move();
                }
            }
        }
        if (attack_phase == 7)
        {
            if (count % 400 == 0)
            {
                Instantiate(quadruple_laser_orb, new Vector3(22.3f, 3.12f, 0), Quaternion.identity);
                animator.SetFloat("Direction", 1);
            }
            if (count % 400 == 200)
            {
                animator.SetFloat("Direction", 2);
                var laser_orb = Instantiate(quadruple_laser_orb, new Vector3(42.5f, 3.12f, 0), Quaternion.identity);
                laser_orb.GetComponent<Moving_orb>().x_mod = -4;
            }
            if (count % 200 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count >= 1000)
            {
                if (cooldown == -1)
                {
                    cooldown = 150;
                    Boss_bar_move();
                }
                count = 1001;
                transitioning = true;
            }
            else
            {
                count++;
            }
        }
        if (attack_phase == 8)
        {
            if (count >= 650)
            {
                transitioning = true;
                count = 651;
                if (cooldown == -1)
                {
                    cooldown = 150;
                    Boss_bar_move();
                }
            }
            else
            {
                count++;
            }
            if (count % 130 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            
            if (count % 100 == 0)
            {
                animator.SetFloat("Direction", 3);
                Instantiate(homing_orb, new Vector3(player.position.x + 3, player.position.y, 0), Quaternion.identity);
                Instantiate(homing_orb, new Vector3(player.position.x + 1.5f, player.position.y + 1.5f, 0), Quaternion.identity);
                Instantiate(homing_orb, new Vector3(player.position.x - 3, player.position.y, 0), Quaternion.identity);
                Instantiate(homing_orb, new Vector3(player.position.x, player.position.y + 3, 0), Quaternion.identity);
                Instantiate(homing_orb, new Vector3(player.position.x, player.position.y - 3, 0), Quaternion.identity);
                Instantiate(homing_orb, new Vector3(player.position.x + 1.5f, player.position.y - 1.5f, 0), Quaternion.identity);
                Instantiate(homing_orb, new Vector3(player.position.x - 1.5f, player.position.y + 1.5f, 0), Quaternion.identity);
                Instantiate(homing_orb, new Vector3(player.position.x - 1.5f, player.position.y - 1.5f, 0), Quaternion.identity);
            }
            if (count % 100 == 50)
            {
                animator.SetFloat("Direction", 0);
            }
        }
        if (attack_phase == 9)
        {
            if (count % 30 == 0)
            {
                var orb = Instantiate(homing_orb, new Vector3(28.39f, player_pos.position.y), Quaternion.identity);
                animator.SetFloat("Direction", 1);
            }
            if (count % 30 == 15)
            {
                animator.SetFloat("Direction", 2);
                var orb = Instantiate(homing_orb, new Vector3(36.42f, player_pos.position.y), Quaternion.identity);
            }
            if (count % 150 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count >= 750)
            {
                if (cooldown == -1)
                {
                    cooldown = 150;
                    Boss_bar_move();
                }
                count = 751;
                transitioning = true;
            }
            else
            {
                count++;
            }
        }
        if (attack_phase == 10)
        {
            if (count == 0)
            {
                animator.SetFloat("Direction", 1);
                var orb = Instantiate(quadruple_laser_orb_off, new Vector3(28.39f, 3.24f, 0), Quaternion.identity);
                orb.GetComponent<Moving_orb>().x_mod = 2;
            }
            if (FindObjectOfType<Moving_orb>() != null && FindObjectOfType<Moving_orb>().transform.position.x >= 32.4f)
            {
                animator.SetFloat("Direction", 0);
                Instantiate(homing_laser_single, FindObjectOfType<Moving_orb>().transform.position, FindObjectOfType<Moving_orb>().transform.rotation);
                Destroy(FindObjectOfType<Moving_orb>().gameObject);
            }
            count++;
            if(FindObjectOfType<Moving_orb>() == null && transitioning == false)
            {
                count2++;
                if (count2 % 120 == 0 && count2 != 0)
                {
                    Boss_bar_move();
                }
            }
            if (count > 400 && GameObject.Find("Laser_orb_quadruple_homing(Clone)") == null)
            {
                transitioning = true;
                if (cooldown == -1)
                {
                    Boss_bar_move();
                    cooldown = 50;
                }
            }
        }
        if(attack_phase == 11)
        {
            if (count % 100 == 50)
            {
                animator.SetFloat("Direction", 0);
            }
            if (count % 100 == 0)
            {
                for (i = 7.25f; i >= 0.22f; i -= 0.5f)
                {
                    if (count2 % 6 <= 2)
                    {
                        Instantiate(moving_orb_left, new Vector3(36.42f, i, 0), Quaternion.identity);
                    }
                    else
                    {
                        Instantiate(moving_orb_right, new Vector3(28.39f, i, 0), Quaternion.identity);
                    }
                    count2++;
                }
                count2 = 0;
                for (i = 28.39f;i <= 36.42;i += 0.5f)
                {
                    if (count2 % 6 <= 2)
                    {
                        var orb = Instantiate(moving_orb_right, new Vector3(i, 7.75f, 0), Quaternion.identity);
                        orb.GetComponent<Moving_orb>().y_mod = -2;
                        orb.GetComponent<Moving_orb>().x_mod = 0;
                    }
                    else
                    {
                        var orb = Instantiate(moving_orb_right, new Vector3(i, -0.28f, 0), Quaternion.identity);
                        orb.GetComponent<Moving_orb>().y_mod = 2;
                        orb.GetComponent<Moving_orb>().x_mod = 0;
                    }
                    count2++;
                }
                animator.SetFloat("Direction", 3);
                count2 = 0;
            }
            if(count % 120 == 0 && count != 0)
            {
                Boss_bar_move();
            }
            if (count >= 600)
            {
                transitioning = true;
                count = 601;
                if (cooldown == -1)
                {
                    Boss_bar_move();
                    cooldown = 300;
                }
            }
            else
            {
                count++;
            }
        }
        if(attack_phase == 12)
        {
            if (count % 100 == 50 || count % 100 == 125)
            {
                animator.SetFloat("Direction", 0);
            }
            if (count % 150 == 0)
            {
                for (i = 7.25f; i >= 0.22f; i -= 0.5f)
                {
                    Instantiate(delayed_aiming_orb, new Vector3(36.42f, i, 0), Quaternion.identity);
                    Instantiate(delayed_aiming_orb, new Vector3(28.39f, i, 0), Quaternion.identity);
                }
                animator.SetFloat("Direction", 3);
            }
            if(count % 150 == 75)
            {
                for (i = 28.39f; i <= 36.42; i += 0.5f)
                {
                    Instantiate(delayed_aiming_orb, new Vector3(i, 7.75f, 0), Quaternion.identity);
                    Instantiate(delayed_aiming_orb, new Vector3(i, -0.28f, 0), Quaternion.identity);
                }
                animator.SetFloat("Direction", 3);
            }
            if (count % 120 == 0&& count != 0)
            {
                Boss_bar_move();
            }
            if (count >= 600)
            {
                transitioning = true;
                count = 601;
                if (cooldown == -1)
                {
                    Boss_bar_move();
                    cooldown = 150;
                }
            }
            else
            {
                count++;
            }
        }
        if(attack_phase == 13)
        {
            if(count == 0)
            {
                Instantiate(quadruple_laser_orb_area_deny, transform.position + new Vector3(0, 10, 0), Quaternion.identity);
                acceleration = 3;
                animator.SetFloat("Direction", 3);
                health = 1;
            }
            if(count >= 280 && acceleration >= 3)
            {
                if (count % 200 == 0|| count % 200 == 100)
                {
                    var orb = Instantiate(moving_orb_right, new Vector3(32.4f, 6.75f, 0), Quaternion.identity);
                    orb.GetComponent<Moving_orb>().y_mod = -2 - acceleration;
                    orb.GetComponent<Moving_orb>().x_mod = 0;
                    orb.GetComponent<Moving_orb>().delay = 50 - acceleration;
                }
                if (count % 200 == 25||count % 200 == 125)
                {
                    var orb2 = Instantiate(moving_orb_right, new Vector3(31.9f, 6.75f, 0), Quaternion.identity);
                    orb2.GetComponent<Moving_orb>().y_mod = -2 - acceleration;
                    orb2.GetComponent<Moving_orb>().x_mod = 0;
                    orb2.GetComponent<Moving_orb>().delay = 50 - acceleration;
                    var orb = Instantiate(moving_orb_right, new Vector3(32.9f, 6.75f, 0), Quaternion.identity);
                    orb.GetComponent<Moving_orb>().y_mod = -2 - acceleration;
                    orb.GetComponent<Moving_orb>().x_mod = 0;
                    orb.GetComponent<Moving_orb>().delay = 50 - acceleration;
                }
                if(count % 200 == 50)
                {
                    var orb = Instantiate(moving_orb_right, new Vector3(31.9f, 6.75f, 0), Quaternion.identity);
                    orb.GetComponent<Moving_orb>().y_mod = -2 - acceleration;
                    orb.GetComponent<Moving_orb>().x_mod = 0;
                    orb.GetComponent<Moving_orb>().delay = 50 - acceleration;
                }
                if (count % 200 == 75)
                {
                    var orb2 = Instantiate(moving_orb_right, new Vector3(32.4f, 6.75f, 0), Quaternion.identity);
                    orb2.GetComponent<Moving_orb>().y_mod = -2 - acceleration;
                    orb2.GetComponent<Moving_orb>().x_mod = 0;
                    orb2.GetComponent<Moving_orb>().delay = 50 - acceleration;
                    var orb = Instantiate(moving_orb_right, new Vector3(32.9f, 6.75f, 0), Quaternion.identity);
                    orb.GetComponent<Moving_orb>().y_mod = -2 - acceleration;
                    orb.GetComponent<Moving_orb>().x_mod = 0;
                    orb.GetComponent<Moving_orb>().delay = 50 - acceleration;
                }
                if(count % 200 == 150)
                {
                    var orb = Instantiate(moving_orb_right, new Vector3(32.9f, 6.75f, 0), Quaternion.identity);
                    orb.GetComponent<Moving_orb>().y_mod = -2 - acceleration;
                    orb.GetComponent<Moving_orb>().x_mod = 0;
                    orb.GetComponent<Moving_orb>().delay = 50 - acceleration;
                }
                if (count % 200 == 175)
                {
                    var orb2 = Instantiate(moving_orb_right, new Vector3(31.9f, 6.75f, 0), Quaternion.identity);
                    orb2.GetComponent<Moving_orb>().y_mod = -2 - acceleration;
                    orb2.GetComponent<Moving_orb>().x_mod = 0;
                    orb2.GetComponent<Moving_orb>().delay = 50 - acceleration;
                    var orb = Instantiate(moving_orb_right, new Vector3(32.4f, 6.75f, 0), Quaternion.identity);
                    orb.GetComponent<Moving_orb>().y_mod = -2 - acceleration;
                    orb.GetComponent<Moving_orb>().x_mod = 0;
                    orb.GetComponent<Moving_orb>().delay = 50 - acceleration;
                }
                if (count % 50 == 25)
                {
                    acceleration++;
                    if (acceleration % 7 == 0)
                    {
                        Boss_bar_move();
                    }
                }
            }
            if (acceleration == 35)
            {
                FindObjectOfType<Player_health>().killable = 1;
                acceleration = -1;
                health = 1;
                Destroy(GameObject.Find("Laser_orb_quadruple_descend(Clone)"));
                damageable = true;
                animator.SetBool("Floating", false);
                Instantiate(loss_text, new Vector3(32.4f, 0.89f, 0), Quaternion.identity);
                Boss_bar_move();
            }
            if (health == 0)
            {
                if(cooldown == -1)
                { 
                    transitioning = true;
                    cooldown = 45;
                    Instantiate(boss_bar_part, new Vector3(bar_position - 0.02f, 7.62f, 0), Quaternion.identity);
                    Boss_bar_move();
                    Instantiate(boss_bar_part, new Vector3(bar_position - 0.02f, 7.62f, 0), Quaternion.identity);
                    Boss_bar_move();
                    Instantiate(boss_bar_part, new Vector3(bar_position - 0.02f, 7.62f, 0), Quaternion.identity);
                    Boss_bar_move();
                    Instantiate(boss_bar_part, new Vector3(bar_position - 0.02f, 7.62f, 0), Quaternion.identity);
                    Boss_bar_move();
                    Instantiate(boss_bar_part, new Vector3(bar_position - 0.02f, 7.62f, 0), Quaternion.identity);
                    Boss_bar_move();
                    Instantiate(boss_bar_part, new Vector3(bar_position - 0.02f, 7.62f, 0), Quaternion.identity);
                    Boss_bar_move();
                    Instantiate(boss_bar_part, new Vector3(bar_position - 0.02f, 7.62f, 0), Quaternion.identity);
                    Boss_bar_move();
                    Boss_bar_move();
                    animator.SetBool("Defeated", true);
                    transitioning = true;
                }
            }
            count++;
        }
        if(attack_phase == 14)
        {
            Instantiate(pedestal, transform.position - new Vector3(0,0.2f,0), Quaternion.identity);
            Destroy(gameObject);
        }
        if (transitioning)
        {
            if (cooldown == 0)
            {
                attack_phase++;
                transitioning = false;
                count = 0;
                count2 = 0;
                cooldown = -1;
            }
            else { cooldown--; }
        }
        if(GameObject.Find("Laser_orb_quadruple_descend(Clone)")!= null && GameObject.Find("Laser_orb_quadruple_descend(Clone)").transform.position.y + 0.2f < player.position.y)
        {
            SceneManager.LoadScene("GameOver");
        }
    }
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player_attack"))
        {
            if (damageable)
            {
                health -= 1;
                damageable = false;
            }
        }
    }
    public void Boss_bar_move()
    {
        Instantiate(boss_bar_part, new Vector3(bar_position,7.62f,0), Quaternion.identity);
        bar_position -= 0.04f;
    }
}
