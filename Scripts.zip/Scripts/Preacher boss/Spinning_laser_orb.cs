﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spinning_laser_orb : MonoBehaviour
{
    public float rotate_speed;
    void FixedUpdate()
    {
        transform.Rotate(0, 0, rotate_speed);
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_magic_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
                //Damages the player when it hits their magic hitbox
            }
        }
    }
}
