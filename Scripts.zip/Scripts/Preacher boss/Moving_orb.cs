﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moving_orb : MonoBehaviour
{
    public float y_mod;
    public float x_mod;
    public int delay;
    private int count;
    public Rigidbody2D rb;
    public int destroy_time;
    void FixedUpdate()
    {
        if (count == delay)
        {
            rb.velocity = new Vector3(x_mod, y_mod, 0.0f); //Moves the object in a specific direction
        }
        if (count == destroy_time)
        {
            Destroy(gameObject);
        }
        transform.Rotate(0, 0, 1);
        count++;
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_magic_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
        }
    }
}
