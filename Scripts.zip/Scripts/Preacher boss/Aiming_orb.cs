﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Aiming_orb : MonoBehaviour
{
    public Rigidbody2D rb;
    private float x_dif;
    private float y_dif;
    public int delay;
    private int count;
    public int destroy_time;
    private void Start()
    {
        var target = FindObjectOfType<Move>().transform;
        x_dif = target.position.x - transform.position.x;
        y_dif = target.position.y - transform.position.y; //Finds where the target was when the orb was created
        
    }
    void FixedUpdate()
    {
        if (count == delay)
        {//Moves the orb towards where the player was
            rb.velocity = new Vector3(x_dif, y_dif, 0.0f);
        }
        if (count == destroy_time)
        {
            Destroy(gameObject); //Destroys the object after a period of time
        }
        transform.Rotate(0, 0, 1);//Spins the orb around to look nice
        count++;
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_magic_hitbox"))
        { 
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
            Destroy(gameObject);//Damages the player and is destroyed once it hits them
        }
    }
}
