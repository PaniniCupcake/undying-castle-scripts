﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Preacher_setup : MonoBehaviour
{
    public int start_phase;
    public Animator animator;
    void Start()
    {
        FindObjectOfType<Log>().boss = true;
    }
    void FixedUpdate()
    {
        GameObject text_stuff = GameObject.FindWithTag("Text");
        if(text_stuff == null)
        {//Starts the boss fight when the text boss is destroyed
            Preacher_attack_pattern attacks = gameObject.GetComponent<Preacher_attack_pattern>();
            attacks.attack_phase = start_phase;
            animator.SetBool("Floating", true);
            GameObject boss_frame = GameObject.Find("Boss_frame");
            boss_frame.GetComponent<SpriteRenderer>().sortingLayerName = "Magic"; //Reveals the boss bar when the boss fight starts
            GameObject boss_bar = GameObject.Find("Boss_bar");
            boss_bar.GetComponent<SpriteRenderer>().sortingLayerName = "Magic";
            Destroy(this);
        }
    }
}
