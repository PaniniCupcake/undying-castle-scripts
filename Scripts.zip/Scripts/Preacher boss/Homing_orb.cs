﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Homing_orb : MonoBehaviour
{
    public Rigidbody2D rb;
    private float x_dif;
    private float y_dif;
    public int delay;
    private int count;
    public int homing_period;
    public int homing_interval;
    public int destroy_time;
    public bool destroyable;
    void FixedUpdate()
    {
        if (count >= delay && count <= homing_period && count % homing_interval == 0)
        {
            var target = FindObjectOfType<Move>().transform;
            x_dif = target.position.x - transform.position.x;
            y_dif = target.position.y - transform.position.y;
                rb.velocity = 0.7f * new Vector3(x_dif, y_dif, 0.0f); //Adjusts the object's movement to move closer to the player in bursts
        }
        if(count == destroy_time)
        {
            Destroy(gameObject);
        }
        transform.Rotate(0, 0, -2);
        count++;
    }
    void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag("Player_magic_hitbox"))
        {
            GameObject player = GameObject.Find("Player");
            Player_health player_health = player.GetComponent<Player_health>();
            if (player_health.invuln == 0 && player_health.health > 0)
            {
                player_health.health--;
            }
            if (destroyable)
            {
                Destroy(gameObject);
            }
        }
    }
}
