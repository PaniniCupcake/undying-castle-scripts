﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate_around : MonoBehaviour
{
    public Vector3 target;
    public Vector3 axis;
    public float rotation_amount;
    public int rotation_interval;
    private int count;
    public Transform target_object;
    void Update()
    {
        if(count == rotation_interval)
        {
            if(target_object != null)
            {
                target = target_object.transform.position;
            }
            transform.RotateAround(target, axis, rotation_amount);
            count = 0;
        }
        count++;
    }
}
