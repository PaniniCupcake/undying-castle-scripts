﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Doorway_enter : MonoBehaviour
{
    private bool entering;
    private int blip = 0;
    public Doorway door;
    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Doorway"))
        {//Checks if the player is touching a doorway and sends them through it if they are
            door = other.GetComponent<Doorway>();
            if (door.accesible >= 1)
            {
                entering = true;
            }
        }
    }
    private void FixedUpdate()
    {
        if (entering)
        {
            Background_darkness bground = FindObjectOfType<Background_darkness>();
            if (blip == 10)
            {//Cuts the screen to black while the player is being transported
                bground.GetComponent<SpriteRenderer>().sortingLayerName = "Super_background";
                transform.position = door.exit.position + new Vector3(0,0.28f,0); //Sets the player's location to the doorway's exit location
                entering = false;
                blip = 0;
            }
            else
            {//Shows the screen again
                bground.GetComponent<SpriteRenderer>().sortingLayerName = "Death_layer";
                blip++;
            }
        }
    }
}
