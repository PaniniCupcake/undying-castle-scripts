﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class relative_position : MonoBehaviour
{
    public Transform offsetted;
    public float x_offset;
    public float y_offset;
    void FixedUpdate()
    {
        //Moves the object at an offset relative to another one
        transform.position = offsetted.position + new Vector3(x_offset, y_offset, 0);
    }
}
