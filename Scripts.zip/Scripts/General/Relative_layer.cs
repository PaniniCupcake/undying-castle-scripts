﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Relative_layer : MonoBehaviour
{
    public GameObject relative_object;
    public int modifier;
    void Update()
    {
        GetComponent<SpriteRenderer>().sortingOrder = relative_object.GetComponent<SpriteRenderer>().sortingOrder + modifier; 
    }
}
