﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Deactivate : MonoBehaviour
{
    public int duration = 200;
    private int count;
    void OnEnable()
    {
        count = 0;
    }
    void FixedUpdate()
    {
        if(count == duration)
        {
            gameObject.SetActive(false);
        }
        count++;
    }
}
