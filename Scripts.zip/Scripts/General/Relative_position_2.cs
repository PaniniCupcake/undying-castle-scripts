﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Relative_position_2 : MonoBehaviour
{
    public string other;
    private float x_dif;
    private float y_dif;
    private Transform target;
    void OnEnable()
    {
        target = GameObject.Find(other).transform;
        x_dif = target.position.x - transform.position.x;
        y_dif = target.position.y - transform.position.y;
    }
    void Update()
    {
        transform.position = target.position + new Vector3(x_dif,y_dif,0);
    }
}
