﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Position_checker : MonoBehaviour {
    public float xpos;
    public float ypos;
	void Update () {
        xpos = transform.position.x;
        ypos = transform.position.y;
	}
}
