﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Move_things : MonoBehaviour
{
    public List<bool> animate = new List<bool>();
    public List<float> h_directions = new List<float>();
    public List<float> v_directions = new List<float>();
    public List<int> intervals = new List<int>();
    public GameObject moved;
    public Vector3 start_pos;
    public int instantiate_gap;
    private int count;
    void FixedUpdate()
    {
        if(moved != null)
        {
            if(count == instantiate_gap)
            {
                Instantiate(moved, start_pos, Quaternion.identity).GetComponent<Moved>().mover = this;
                count = 0;
            }
            count++;
        }
    }
}
