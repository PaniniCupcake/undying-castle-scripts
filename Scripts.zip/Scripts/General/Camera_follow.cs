﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camera_follow : MonoBehaviour {
    public Transform target;
    public Vector3 offset;
    public bool following = true;
    private int cooldown;
    void Start () {
        offset = new Vector3(0, 0, -10);
	}
	void Update () {
        if (following && cooldown == 0)
        {
            transform.position = target.position + offset;
        }
        if (!following)
        {
            Vector3 book = GameObject.FindWithTag("Book").transform.position;
            if (cooldown == 10)
            {
                transform.position = book + new Vector3(0, 0, -10);
            }
            else
            {
                float x_dif = book.x - transform.position.x;
                float y_dif = book.y - transform.position.y;
                transform.position += new Vector3(x_dif, y_dif, 0) * 0.1f;
                cooldown++;
            }
        }
        else if(cooldown != 0)
        {
            float x_dif = target.position.x - transform.position.x;
            float y_dif = target.position.y - transform.position.y;
            transform.position += new Vector3(x_dif, y_dif, 0) * 0.1f;
            cooldown--;
        }
        //Makes the camera be in the same place as the player
    }
}
