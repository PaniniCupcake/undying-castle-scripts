﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Layer_orderer : MonoBehaviour {
    public float offset; //Accounts for the difference in height of the centre of objects
    public int upper_gap;//Allows multiple overlapping layers to remain appearing above or below each other
    public int lower_gap;
    public GameObject player;
    void Update() {
        player = GameObject.Find("Player");//Tells the object where the player is
        if (player.transform.position.y > transform.position.y - offset)
        {//Moves the object a number of layers above the player 
            gameObject.GetComponent<SpriteRenderer>().sortingOrder = player.GetComponent<SpriteRenderer>().sortingOrder + 1 + upper_gap;
        }
        if (player.transform.position.y <= transform.position.y - offset)
        {//Moves the object a number of layers above
            gameObject.GetComponent<SpriteRenderer>().sortingOrder = player.GetComponent<SpriteRenderer>().sortingOrder - 1 - lower_gap;
        }
        
    }
}
