﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Doorway : MonoBehaviour
{
    public Transform exit; //Informs the doorway_enter script where the doorways exit is
    public List<bool> puzzles_needed;
    public int puzzle_no;
    public int accesible = 1;
    private bool access; //0 library, 1 barracks, 2 temple, 3 school, 4 workshop, 5 lava, 6 caves
    private int i;
    private void FixedUpdate()
    {
        if (accesible == 0)
        {
            access = true;
            for(i=0;i<5; i++)
            {
                if(FindObjectOfType<Log>().puzzles_completed[puzzle_no][i] == false && puzzles_needed[i])
                {
                    access = false;
                    break;
                }
            }
            if (!access)
            {
                gameObject.GetComponent<Renderer>().material.color = Color.red;
            }
            else
            {
                accesible = 1;
            }
        }
        if(accesible == 1)
        {
            gameObject.GetComponent<Renderer>().material.color = Color.black;
            accesible++;
        }
    }
}
