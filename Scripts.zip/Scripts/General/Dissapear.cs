﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dissapear : MonoBehaviour
{
    public int limit;
    private int count;
    void Update()
    {
        if(count == limit)
        {
            Destroy(gameObject);
        }
        count++;
    }
}
