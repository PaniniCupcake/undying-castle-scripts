﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move_amount : MonoBehaviour
{
    public float x_mod;
    public float y_mod;
    private int count = 0;
    public int move_start;
    public int move_stop;
    void FixedUpdate()
    {
        if(move_start <= count && move_stop >= count)
        {//Moves the object a certain amount for a certain period of time
            transform.position += new Vector3(x_mod, y_mod, 0);
        }
        count++;
    }
}
