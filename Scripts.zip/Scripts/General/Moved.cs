﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moved : MonoBehaviour
{
    public int count;
    public Move_things mover;
    public int interval;
    private List<float> h_directions = new List<float>();
    private List<float> v_directions = new List<float>();
    public int initial_interval;
    private List<int> intervals = new List<int>();
    public int index;
    private List<bool> animate = new List<bool>();
    public Animator animator;
    public int repeat = 0;
    public int slowdown;
    private int slowdown_counter;
    private void Start()
    {
        h_directions = mover.h_directions;
        v_directions = mover.v_directions;
        intervals = mover.intervals;
        interval = initial_interval;
        animate = mover.animate;
    }
    void FixedUpdate()
    { //If interval is -9999, stop moving. If interval is -10000, destroy. If interval is -10001,restart. Else if negative, repeat.
        if (slowdown_counter == slowdown)
        {
            if (count == interval || repeat > 1)
            {
                if (h_directions[index] > 100000 || h_directions[index] < -100000)
                {
                    transform.position = new Vector3(h_directions[index], v_directions[index], 0) / 100000;
                }
                else
                {
                    transform.position += new Vector3(h_directions[index], v_directions[index], 0);
                }
                if (repeat < 2)
                {
                    interval = intervals[index];
                    if (interval < 1)
                    {
                        repeat = -interval + 1;
                    }
                    else
                    {
                        index++;
                    }
                }
                count = 0;
            }
            if (interval == -9999)
            {
                Destroy(this);
            }
            if (interval == -10000)
            {
                Destroy(gameObject);
            }
            if(interval == -10001)
            {
                index = 0;
                interval = 0;
                repeat = 0;
            }
            if (repeat == 1)
            {
                repeat = 0;
                interval = 0;
                index++;
            }
            else if (repeat == 0)
            {
                count++;
            }
            else
            {
                repeat--;
            }
            slowdown_counter = 0;
            if (animator != null && animate[index] == true)
            {
                animator.SetBool("Moving", true);
            }
            else if (animator != null && animate[index] == false)
            {
                animator.SetBool("Moving", false);
            }
        }
        else
        {
            slowdown_counter++;
        }
    }
}
