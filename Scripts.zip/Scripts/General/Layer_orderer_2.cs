﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Layer_orderer_2 : MonoBehaviour
{
    public int addition;
    void Update()
    { //Finds the object's y position and makes its layer lower the higher it is
        gameObject.GetComponent<SpriteRenderer>().sortingOrder = Mathf.RoundToInt(2000 - transform.position.y * 100) + addition;
    }
}
