﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stalled_appear : MonoBehaviour
{
    private int count;
    public int delay;
    public bool counting;
    void FixedUpdate()
    {
        if (counting)
        {//Checks if the object becoming visible has been triggered
            if (count >= delay)
            {//Makes the object visible on the default layer
                gameObject.GetComponent<SpriteRenderer>().sortingLayerName = "Default";
            }
            count++;
        }
        else
        {
            count = 0;
        }
    }
}
